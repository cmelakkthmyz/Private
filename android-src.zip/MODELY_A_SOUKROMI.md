# Modely a soukromí MediaLupy 0.6

- Rozpoznávání obsahu: zabalený ML Kit image-labeling 17.0.9.
- OCR: zabalený ML Kit text-recognition 16.0.1.
- Detekce obličejů: zabalený ML Kit face-detection 16.1.7.
- Podobnost obličejů: experimentální MobileFaceNet z předaného projektu 0.5.
- Runtime: com.google.ai.edge.litert:litert:1.4.0 (Apache-2.0 podle POM závislosti).
  Používá existující Interpreter API. Dokumentace přechodu:
  https://developers.google.com/edge/litert/migration

Soubor modelu je již přiložen v `app/src/main/assets/mobile_face_net.tflite`,
velikost 5 233 552 B. Tento běh model nestahoval ani netrénoval.
SHA-256: `be4bc7cfc53f7bc336d0f28b1ab92535f618c913a422b683210750f6b5354854`.

Předchozí projekt uvádí jako původ modelu:
https://github.com/Andrew-Hardianto/capacitor-face-recognition-tflite
commit `558614e8aa9454379042e4a5f1995a56025ced84`.
Převzaté váhy nemají v tomto archivu samostatně doložené redistribuční oprávnění;
sestavení zůstává experimentální pro osobní testování. Před veřejným vydáním je
potřeba vyřešit licenci konkrétních vah a měření přesnosti. Neupravovali jsme
prahy podobnosti ani netvrdíme zlepšení rozpoznávací přesnosti.

Žádný vlastní server ani oprávnění INTERNET; biometrické vektory a jména jsou
uložené interně v aplikaci s vypnutým zálohováním. Uživatel může smazat jeden
biometrický profil nebo celý index osob. Odstranění alba zachovává příznak již
analyzovaného souboru, aby další dávka automaticky neobnovila smazané vzory.
Úplné smazání indexu osob resetuje analýzu a odvolá uložený souhlas.

Pro SAF aplikace neprovádí automatické stahování/analýzu cloudových médií.
Připojené poskytovatele dokumentů ovládá systém Android a jejich vlastní připojení.
