# MediaLupa 0.6.1 – Průzkumník pro Android

Navazuje na Android MediaLupu 0.5. Windows může sloužit jako vývojový počítač;
tento projekt vytváří instalační APK pro telefon. Samostatný program EXE nevytváří.

## Instalace a použití

1. Stáhni a otevři `MediaLupa_0_6_Pruzkumnik.apk` na telefonu s Androidem 10 nebo novějším.
2. Pokud to systém vyžádá, povol instalaci z aplikace, přes kterou APK otevíráš.
3. Přes **Přidat → Načíst média z telefonu** uděl oprávnění ke svým fotografiím/videím.
4. **Nástroje → Rozpoznat obsah** spustí offline štítky a volitelně OCR.
5. **Najít osoby** nabídne souhlas s lokálním ukládáním vzorů a vytvoří návrhy alb.
   Podržením alba ho přejmenuješ, sloučíš nebo smažeš jeho uložené vzory.

Balíček `cz.medialupa.explorer`, versionCode 7, má stejný přiložený vývojový podpis
jako zdroje 0.5. Při shodném podpisu se instaluje jako aktualizace se zachováním
indexu. Verzi 0.5 před aktualizací neodinstalovávej. Starší balíčky `cz.medialupa.test`
jsou samostatné aplikace; jejich index se nepřenáší. Pokud systém odmítne aktualizaci
kvůli podpisu, původní aplikaci nejprve nemaž: její odinstalace by smazala uložená jména a index.

## Oprava v 0.6.1

- Při omezeném přístupu (například „Vybrat fotografie“ v Androidu 14+) katalog
  **neodstraňuje dříve indexované soubory**, jejich AI štítky ani uživatelsky
  pojmenované obličejové galerie. Zmizelé soubory se čistí pouze při prokazatelně
  plném přístupu k odpovídající kolekci fotografií nebo videí.
- Přidán regresní test přechodu z omezeného přístupu na plný přístup.
- Část knihovny nepřístupná kvůli oprávněním se označí jako neúplná.

## Co přináší 0.6

- Tlačítko **Zastavit** také při načítání knihovny a hledání duplicit.
- Přerušený nebo neúplný průchod neodstraňuje dosud nenalezené položky katalogu.
  Opětovné spuštění prochází zdroj od začátku, ale zachová analýzu nezměněných souborů.
- SHA-256 znovu používá již uložené kontrolní součty a kontrolu lze přerušit i uvnitř souboru.
- Oddělená oprávnění k fotkám a videím: odmítnutí jedné kolekce neblokuje druhou.
- Neúplný průchod připojenou složkou zůstane označen i ve výsledné zprávě.
- Obnova analýzy nečitelných souborů přes **Zkusit znovu nečitelné soubory**.
- Odstranění položky katalogu nebo změna souboru odstraní neplatné obličejové vzory
  a přepočítá skupiny. Aktualizace databáze opraví i osiřelé vzory z 0.5.
- Lze smazat jednotlivé album osoby; ostatní alba a originály zůstanou zachované.
- Přerušené video při hledání obličejů nezůstane označené jako kompletně zpracované.
- Oprava českých štítků: části slov jako „cat“ v „cathedral“ nevytvářejí štítek kočky.
- Runtime obličejového modelu převeden na přibalený LiteRT 1.4.0; model a zpracování zůstávají lokální.

## Dosavadní rozhraní a funkce

Český Průzkumník, strom složek, klikací cesty, mřížka/seznam, náhledy,
prohlížeč s lupou a otáčením náhledu, video přehrávač, tematická alba,
hledání podle názvu, přeložených štítků a OCR, přesné duplicity a pojmenovatelná alba osob.
Soubory se nepřesouvají a originály se neupravují ani nemažou.

Aplikace nemá oprávnění INTERNET. Cloudové složky zpřístupňuje systémový výběr
Android SAF, jen když ho daný poskytovatel podporuje. Načítají se jejich metadata;
automatická AI, obličeje a SHA-256 pracují pouze s médii telefonu. Ruční otevření
souboru přes poskytovatele může vyžadovat jeho internetové připojení.

## Praktická omezení

- Hledání podle obsahu používá štítky ML Kit a český slovník; univerzální multimodální
  model a libovolné porozumění celé větě nejsou implementované.
- Obličejové skupiny jsou experimentální návrhy, jejich přesnost nebyla změřena na
  reprezentativním souboru lidí. Sloučení a oddělení opravuje uživatel.
- AI/obličeje běží v omezených dávkách z otevřené aplikace. Další dávku spustíš znovu.
  Automatická služba na pozadí a sledování změn zde nejsou.
- SAF načte nejvýše 10 000 souborů na zdroj a označí limit jako neúplný průchod.
  Pro větší knihovnu připoj menší podsložky. Fotografie a videa telefonu tímto limitem načítání omezené nejsou.
- Prohlížeč dostává nejvýše 201 okolních médií, seznam postupně zobrazuje až 10 000 výsledků.
- Obrázky pro prohlížeč se dekódují na náhled do 2560 px. Otočení mění jen náhled.
- OCR videa zůstává z prvního vzorkovaného snímku; obsah/obličeje používají až tři snímky.
- Kodeky, výkon AI a skutečné poskytovatele souborů je třeba ověřit na telefonu.

## Sestavení

Dřívější verze 0.6 byla sestavena a testována pomocí JDK 21, Gradle 9.6.1,
AGP 9.3.1, compile SDK 36 / build tools 36.0.0. Změna 0.6.1 dosud
**neprošla úplným Android buildem**: při lokální kontrole nebylo dostupné
Android SDK ani stažení Gradle z internetu.
Zdrojová a cílová kompatibilita Java je 17, min SDK 29 a target SDK 35.

```bash
./gradlew :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
```

Na Windows použij `gradlew.bat`. Nastav Android SDK přes `ANDROID_HOME` nebo vlastní
`local.properties`. Výstup: `app/build/outputs/apk/debug/app-debug.apk`.
Testy UI tvoří ukázkové procedurální obrázky; nepoužívají osobní fotografie.
Workflow `.github/workflows/medialupa-apk.yml` po spuštění na GitHubu sestaví APK a nahraje artefakty po
ručním spuštění v uživatelově repozitáři. V tomto běhu se na GitHub nic neposílalo.

Přiložený `signing/medialupa-preview.jks` je veřejný testovací klíč
(alias `androiddebugkey`, heslo `android`), ne produkční podpis.
Licence ikon: `LUCIDE_LICENSE.txt`; model a další závislosti: `MODELY_A_SOUKROMI.md`.
