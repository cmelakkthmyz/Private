# MediaLupa 0.5

Průzkumník složek a lokální prohlížeč médií. Přehled a omezení jsou v README.md.

Změny zdrojů: MainActivity, nové ExplorerModels, Ui, ThumbnailLoader, MediaPreviewPanel, MediaViewerActivity a ZoomImageView; nové vektorové ikony a systémový tmavý motiv; adaptéry mřížky/seznamu; rozšíření vyhledávacího dotazu o zdroj, cestu a album; srozumitelné označení připojené složky. Schéma databáze zůstává ve verzi 3. Aplikace používá samostatný instalační identifikátor, aby nevynucovala odstranění staré testovací verze podepsané jiným klíčem.
