# MediaLupa Android 0.6.1 – změny

- Fix: Android 14+ režim „vybrané fotografie“ nepředstavuje celou knihovnu.
  Dříve byla přesto volána `dropUnseen`, která mohla odstranit metadata
  nepřístupných médií včetně přiřazení osob.
- `ContentIndexer` nyní povolí odstranění nenalezených položek pouze při
  plném oprávnění ke konkrétní kolekci. Výběr fotek a povolení videí
  jsou posuzovány odděleně.
- Test: `limitedPhotoSelectionCannotDeletePreviouslyIndexedFaceAlbums`.
- Verze aplikace: `versionCode=7`, `versionName=0.6.1-pruzkumnik`.

Ověření: Zdrojová a ZIP kontrola lokálně; zdejší prostředí nemá Android SDK
ani dostupné Gradle distribuce, proto není možné deklarovat průchod Android
unit testů nebo sestavení APK.
