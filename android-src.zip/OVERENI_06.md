# Ověření MediaLupy 0.6

Datum sestavení: 3. listopadu 2026 (Europe/Prague).

- `:app:testDebugUnitTest`: 18 testů, 0 chyb/selhání, žádný přeskočený.
- `:app:assembleDebug`: úspěch.
- `:app:lintDebug`: 0 chyb; 127 upozornění (mj. natvrdo zapsané české texty,
  doporučení Android API a starší rozhraní). Projekt není bez upozornění.
- `apksigner verify`: podpis APK platný, schéma v2.
- `zipalign -c -P 16 4`: úspěch.
- Balíček `cz.medialupa.explorer`, versionCode 6, versionName `0.6.0-pruzkumnik`,
  minimum API 29, target API 35, compile API 36.
- Výsledný manifest neobsahuje oprávnění INTERNET, zálohování aplikace je vypnuté.
- UI ověřeno na API 35 v Robolectric, rozměry telefonu a široké obrazovky.
  Ukázkové obrázky jsou procedurální testovací data.
- Kontrola nativních ELF knihoven: 64bitové knihovny předchozího sestavení stejné
  sady závislostí měly LOAD zarovnání alespoň 16 KB; 32bitové knihovny ML Kit mají
  4 KB. Skutečná funkčnost na 16KB zařízení se tím nedokazuje a nebyla testována.
- Fyzický telefon, skutečná inference ML Kit/MobileFaceNet, přesnost seskupování
  osob, zvuk/kodeky a konkrétní cloudový poskytovatel nebyly otestovány.
- Nový multimodální model ani trénování na uživatelských fotografiích nepřibyly.
- Stav dalších funkcí: STAV_A_DALSI_VYVOJ_06.md. Rozsah a limity: README.md.

## Obsah regresních testů

6 původních UI/navigačních testů a 12 testů: zachování analýzy a jmen, zneplatnění
změněných dat, prořezání osiřelých vzorů, oprava migrací z 0.5, opakování chyb,
smazání jednoho profilu, odmítnutí neplatného sloučení, překlad bez falešných částí
slov, přerušení/obnova indexace, nezávislá oprávnění médií, přerušení/opětovné
použití SHA-256 a nedostupní potomci SAF stromu.

SHA-256 `MediaLupa_0_6_Pruzkumnik.apk`:
`73fabfee1d2a4f71a23eb69ca7f4555c7b3ac1bc9b5f4ac4b24c41bc4d00d78b`

Velikost APK: 162,520,671 B. Jde o testovací sestavení se všemi čtyřmi
architekturami a přiloženými modely, proto je větší než běžná varianta pro jeden telefon.
