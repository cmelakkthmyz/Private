# MediaLupa – verze pro vývoj přímo v telefonu (Android)

Tento archiv je upravený zdrojový projekt MediaLupy pro **Code on the Go 26.43** (říjen 2026). Byl přizpůsoben pro **AGP 9.3.1**, zabudovaný překladač Kotlin, **Gradle 9.6.1** a **compileSdk 36**. Zdrojový kód aplikace odpovídá původnímu MVP 0.1.

## Postup přímo v telefonu

1. Nainstaluj Code on the Go z https://appdevforall.org/code-on-the-go/ (zvol variantu pro svůj procesor, zpravidla **64-bit ARM**).
2. Po prvním spuštění dokonči **instalaci vývojových nástrojů**, kterou aplikace nabídne. Připrav alespoň **4 GB volného místa** a připojení k Wi-Fi. Následné sestavování může fungovat offline, jakmile jsou všechny závislosti k dispozici.
3. Stáhni tento ZIP, ve správci souborů jej **rozbal**. Následně otevři v Code on the Go **kořenovou složku `MediaLupa`** obsahující `settings.gradle.kts` a `app` (v archivu se jmenuje `MediaLupa-Pro-Telefon`).
4. Nech proběhnout synchronizaci. Pokud Code on the Go nabídne vlastní projektovou migraci, napřed zálohuj složku projektu.
5. Použij **Build / Run** podle nabídky editoru. Povol instalaci aplikací z tohoto zdroje (Android zobrazí systémové potvrzení).
6. Otevři MediaLupu, vyber **Indexovat telefon**, povol přístup k fotografiím/videím. Potom můžeš vyzkoušet **Přidat složku / cloud**.

## Když sestavení selže

Pošli do chatu **celý první chybový blok** z Build Output, zejména části začínající `FAILURE` a `What went wrong`. Nejčastější problémy bývají nedokončená instalace SDK, nedostatek místa, chybějící závislosti nebo aktualizace prostředí.

## Důležité upozornění

**Tento projekt nebyl na reálném Androidu přeložen ani otestován.** Je připravený pro mobilní toolchain podle jeho aktuální dokumentace; první skutečné sestavení musí ověřit Code on the Go. Neobsahuje hotové APK. Balíček neobsahuje Gradle wrapper skripty ani `gradle-wrapper.jar`, protože Code on the Go má vlastní sestavovací nástroje; případné použití mimo editor vyžaduje vlastní Gradle 9.6.1 / wrapper.

Indexace je lokální, aplikace bez povolení nic nemaže ani nikam neodesílá. Přístup k médiím je omezen oprávněními Androidu. Cloud přes SAF závisí na konkrétním poskytovateli.

## Obsah projektu

- `app/src/main/java/cz/medialupa/MainActivity.kt` – ovládání a uživatelské rozhraní
- `ContentIndexer.kt` – indexování souborů
- `IndexDatabase.kt` – lokální SQLite databáze
- `DuplicateFinder.kt` – shodné kopie pomocí SHA-256
- `FileRowAdapter.kt` – seznam výsledků
- `app/src/main/res/layout` – XML obrazovky a položky seznamu

Oficiální informace: https://appdevforall.org/code-on-the-go/
