# Aktuální stav po navázání

Projekt je nyní testovací Android MediaLupa 0.6, nikoli desktopový EXE.
Nejdříve čti aktuální README.md, OVERENI_06.md a STAV_A_DALSI_VYVOJ_06.md.
Původní zadání níže popisuje výchozí stav 0.5. Stav hotových a zbývajících funkcí
posuzuj podle současných souborů; neopakuj již dokončenou práci.

# MediaLupa — autonomní vývojový agent (pracovní zadání)

## Kontext a zdroj pravdy

Pokračuj v **existující Android aplikaci MediaLupa 0.5 Průzkumník**, nepiš vše znovu a nezaměň ji za desktopovou aplikaci pro Windows. Windows je vývojový počítač. Nejdříve si přečti `README.md`, `CO_JE_NOVE_05.md`, `OVERENI_05.md` a nastuduj Kotlin zdrojové soubory a testy. Zachovej české rozhraní, balíček a dosavadní funkce. Systém sestavování: Android Gradle Plugin 9.3.1, Gradle 9.6.1, JDK 17, Android SDK 36 (ověř podle build souborů).

## Požadovaný produkt

Offline-first chytrá galerie a organizátor Android médií, použitelný na Samsungu a běžných telefonech. Funkce už jsou částečně implementované. Rozvíjej je, testuj a nepřepisuj hotové bez důvodu:

- přehledný Průzkumník podobný Windows: strom složek, klikací cesty, mřížka/seznam, filtry, miniatury, náhledy, prohlížeč ve stylu IrfanView;
- rychlý lokální katalog fotek, videí a uživatelsky vybraných dokumentů; průběžná indexace, jasný stav, možnost přerušení, změnová aktualizace;
- offline kategorizace snímků a videí podle vizuálního obsahu v českých tématech (zvířata, lidé, vozidla, příroda, dokumenty...), hledání podle obsahu; na videích využij více klíčových snímků s limitem na výkon;
- OCR, přesné duplicity SHA-256, později přibližné duplicity bezpečně a bez automatického mazání originálů;
- lokální rozpoznávání shodných obličejů a **pojmenování galerie osob uživatelem**; žádné automatické veřejné určování identity. Označ nejisté shody a poskytni správu a mazání osobních obličejových šablon;
- Google Drive, OneDrive a další soubory zpřístupněné systémovým výběrem dokumentů (Android Storage Access Framework), s výslovnými souhlasy a respektováním oprávnění. Nevymýšlej neveřejná API. Ochrana soukromí je důležitější než rychlost.

## Nejdřív proveď

1. Ověř prostředí na Windows, spusť `gradlew.bat :app:testDebugUnitTest` a `gradlew.bat :app:assembleDebug`. Pokud JDK, SDK, Android Studio nebo jejich konfigurace chybí, pokus se je nainstalovat/nastavit přes běžné schválené postupy. Neprováděj destruktivní zásahy mimo projekt. Používej sandbox a nezvyšuj oprávnění bez důvodu.
2. Přečti všechna existující data a vytvoř technický backlog se stavem **funguje / chybí / ověřit na telefonu**. Vyhodnoť výkon a UI aktuální verze.
3. Zpracuj ucelenou verzi **MediaLupa 0.6** s prioritou: stabilita indexace, rychlé moderní rozhraní, vizuální hledání a galerijní správa osob. Neodstraň původní podporu offline. Připojení cloudu zaváděj nejdřív bezpečně přes SAF.
4. Pro každou implementovanou funkci přidej automatický test tam, kde to lze. Zajisti průchod unit testů a sestavení. Při nalezených chybách je oprav a opakuj testy.
5. Připrav hotové instalační APK pro test na Samsungu. Popiš přesně funkce, které skutečně fungují, a co nebylo ověřeno na fyzickém zařízení. Uveď cestu k APK a postup instalace (pokud možno vytvoř i GitHub Actions artifact).

## Pracovní zásady

- Pracuj iniciativně přímo v souborech projektu; nepožaduj průběžně potvrzení běžných technických rozhodnutí. Přeruš pouze při nevratném nebo externím kroku vyžadujícím souhlas, například publikování aplikace nebo smazání dat.
- Žádné odesílání fotografií, videí, face embeddingů ani soukromých metadat cizím serverům. Preferuj ověřené open-source knihovny a offline modely, vždy zkontroluj licence a velikost.
- Nikdy automaticky nemaž původní fotografie/videa ani nepřemisťuj obsah cloudu bez explicitního povolení. Zápisy k uživatelským souborům jsou zakázané; index a miniatury ukládej do interního prostoru aplikace.
- Zachovej kompatibilitu s Android 10+, pozornost věnuj runtime permission a systémovým omezením foreground service, pokud je využíván.
- Nepoužívej Git větev `main` existujícího cizího projektu. Jestli zakládáš Git repozitář, odděl MediaLupu od původního Hlídače.
- Nenuť uživatele číst a ručně opravovat kód; na konci dej odkaz nebo konkrétní dostupnou cestu k sestavenému APK a stručnou zprávu o výsledcích.
- Není možné tvrdit, že na projektu pracuješ i mimo aktivní běh agenta bez explicitně naplánovaných úloh.
