plugins {
    id("com.android.application")
}

android {
    namespace = "cz.medialupa"
    compileSdk = 36

    defaultConfig {
        applicationId = "cz.medialupa.explorer.v07"
        minSdk = 29
        targetSdk = 35
        versionCode = 8
        versionName = "0.7.0-media"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    signingConfigs.getByName("debug") {
        storeFile = rootProject.file("signing/medialupa-preview.jks")
        storePassword = "android"
        keyAlias = "androiddebugkey"
        keyPassword = "android"
    }
    testOptions { unitTests.isIncludeAndroidResources = true }
}

// Modely ML Kit jsou zabalené přímo do APK, nestahují se při prvním spuštění.
dependencies {
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.google.ai.edge.litert:litert:1.4.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.16")
}
