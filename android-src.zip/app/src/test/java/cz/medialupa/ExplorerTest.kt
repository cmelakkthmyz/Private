package cz.medialupa

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.app.Activity
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.GridView
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowContentResolver
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w412dp-h915dp-xhdpi", shadows = [HostImageDecoder::class, HostContentResolver::class])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ExplorerTest {
    private val app: Context get() = RuntimeEnvironment.getApplication()
    private lateinit var db: IndexDatabase
    private var activity: MainActivity? = null

    @Before fun prepare() {
        app.deleteDatabase("media_index.db")
        app.getSharedPreferences("sources", Context.MODE_PRIVATE).edit().clear().commit()
        db = IndexDatabase(app)
        val provider = Fixtures()
        provider.attachInfo(app, android.content.pm.ProviderInfo().apply { authority = "media" })
        ShadowContentResolver.registerProviderInternal("media", provider)
        db.addBatch(listOf(
            file(1, "Ranní světlo.jpg", "DCIM/Camera/"),
            file(2, "Výlet do hor.jpg", "DCIM/Camera/"),
            file(3, "Krajina.jpg", "Pictures/"),
            file(4, "Jiná složka.jpg", "DCIM/Camera2/"),
            file(5, "Podzim.jpg", "DCIM/Camera/Výlety/"),
            file(6, "Klip.mp4", "DCIM/Camera/", mime = "video/mp4", source = "PHONE_VIDEOS"),
            file(7, "Externí.jpg", "DCIM/Camera/", source = "TREE:other")
        ))
    }
    private fun file(id: Int, name: String, folder: String, mime: String = "image/jpeg", source: String = "PHONE_IMAGES") =
        IndexedFile("$source:$id", "content://media/external/images/media/$id", name, mime,
            id * 1_048_576L, 1793351741000L - id * 1000L, folder, source, if (source.startsWith("PHONE_")) "Telefon" else "Připojená složka")

    @After fun finish() {
        activity?.let { if (!it.isDestroyed) it.finish() }
        db.close()
    }

    @Test fun contentProviderImageCanBeDecoded() {
        val bitmap = ThumbnailLoader.preview(app, Uri.parse("content://media/external/images/media/1"), "image/jpeg")
        assertNotNull(bitmap)
        assertEquals(800, bitmap!!.width)
    }

    @Test fun folderTreeKeepsSourcesAndPathBoundaries() {
        val nodes = FolderTree.build(db.folderLocations())
        assertEquals(6, nodes.single { it.source == "PHONE" && it.path.isEmpty() }.count)
        assertEquals(4, nodes.single { it.source == "PHONE" && it.path == "DCIM/Camera" }.count)
        assertEquals(listOf("Camera", "Camera2"), FolderTree.children(nodes, "PHONE", "DCIM").map { it.title })
        assertEquals(2, FolderTree.children(nodes, null, "").size)
        assertEquals("DCIM/Camera", FolderTree.normalize("/DCIM//Camera/"))
    }

    @Test fun databaseScopesSearchWithoutLeakingSiblingOrOtherSource() {
        assertEquals(3, db.search("", FileFilter.ALL, sourceGroup = "PHONE", folderPath = "DCIM/Camera").size)
        val recursive = db.search("", FileFilter.ALL, sourceGroup = "PHONE", folderPath = "DCIM/Camera", recursive = true)
        assertEquals(4, recursive.size)
        assertFalse(recursive.any { it.name == "Jiná složka.jpg" || it.name == "Externí.jpg" })
        assertEquals(2, db.search("", FileFilter.PHOTOS, sourceGroup = "PHONE", folderPath = "DCIM/Camera").size)
        assertEquals(2, db.search("vylet", FileFilter.ALL, sourceGroup = "PHONE", folderPath = "DCIM/Camera", recursive = true).size)
        db.addBatch(listOf(file(8, "Emoji.jpg", "Fotky/🐕/Album/")))
        assertEquals(1, db.search("", FileFilter.ALL, sourceGroup = "PHONE", folderPath = "Fotky/🐕", recursive = true).size)
    }

    @Test fun portraitNavigationFiltersAndSearchStayUsable() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val screen = controller.get(); activity = screen
        val grid = screen.findViewById<GridView>(R.id.results)
        await { grid.adapter != null && grid.adapter.count == 9 }
        await { findViews(screen.window.decorView).filterIsInstance<android.widget.ImageView>().any { it.tag is String && it.drawable is android.graphics.drawable.BitmapDrawable } }
        screenshot(screen, "medialupa-telefon-knihovna.png", 412, 915)
        val fileAdapter = grid.adapter as FileRowAdapter
        val phoneIndex = (0 until fileAdapter.count).first { (fileAdapter.getItem(it) as? ExplorerEntry.Folder)?.folder?.source == "PHONE" }
        grid.performItemClick(null, phoneIndex, phoneIndex.toLong())
        await { (grid.adapter as FileRowAdapter).getItem(0).let { (it as? ExplorerEntry.Folder)?.folder?.path == "DCIM" } }
        grid.performItemClick(null, 0, 0)
        await { (grid.adapter as FileRowAdapter).getItem(0).let { (it as? ExplorerEntry.Folder)?.folder?.path == "DCIM/Camera" } }
        grid.performItemClick(null, 0, 0)
        await { grid.adapter.count == 4 }
        screenshot(screen, "medialupa-telefon-slozka.png", 412, 915)
        val query = screen.findViewById<EditText>(R.id.search)
        query.setText("ranni")
        await { grid.adapter.count == 1 }
        assertTrue(((grid.adapter as FileRowAdapter).getItem(0) as ExplorerEntry.Media).file.name.contains("Ranní"))
        query.text.clear()
        await { grid.adapter.count == 4 }
        screen.onBackPressed()
        await { grid.adapter.count == 2 }
        assertTrue(findLabels(screen.window.decorView).contains("DCIM"))
        controller.pause().stop().destroy(); activity = null
    }

    @Test @Config(qualifiers = "w1200dp-h800dp-mdpi")
    fun wideLayoutShowsFolderTreeAndMediaPreview() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val screen = controller.get(); activity = screen
        val grid = screen.findViewById<GridView>(R.id.results)
        await { grid.adapter != null && grid.adapter.count == 9 }
        val entries = grid.adapter as FileRowAdapter
        val index = (0 until entries.count).first { (entries.getItem(it) as? ExplorerEntry.Media)?.file?.mime?.startsWith("image/") == true }
        grid.performItemClick(null, index, index.toLong())
        await { findLabels(screen.window.decorView).any { it.contains("Ranní světlo.jpg") } }
        await { findViews(screen.window.decorView).filterIsInstance<ZoomImageView>().any { it.drawable != null } }
        screenshot(screen, "medialupa-siroka-obrazovka.png", 1200, 800)
        assertTrue(findLabels(screen.window.decorView).contains("SLOŽKY"))
        assertTrue(findLabels(screen.window.decorView).contains("Náhled"))
        controller.pause().stop().destroy(); activity = null
    }

    @Test fun viewerHandlesPhotoAndSwitchingToUnsupportedVideo() {
        val intent = android.content.Intent(app, MediaViewerActivity::class.java).apply {
            putStringArrayListExtra("uris", arrayListOf("content://media/external/images/media/1", "content://media/external/images/media/6"))
            putStringArrayListExtra("names", arrayListOf("Ukázková krajina.jpg", "Ukázkový klip.mp4"))
            putStringArrayListExtra("mimes", arrayListOf("image/jpeg", "video/mp4"))
        }
        val controller = Robolectric.buildActivity(MediaViewerActivity::class.java, intent).setup()
        val screen = controller.get()
        await { findLabels(screen.window.decorView).any { it.contains("px (náhled)") } }
        screenshot(screen, "medialupa-prohlizec.png", 412, 915)
        val next = findViews(screen.window.decorView).first { it.contentDescription == "Další soubor" }
        next.performClick()
        assertTrue(findLabels(screen.window.decorView).contains("Ukázkový klip.mp4"))
        controller.pause().stop().destroy()
    }

    private fun await(condition: () -> Boolean) {
        val deadline = System.nanoTime() + 10_000_000_000L
        while (System.nanoTime() < deadline) {
            shadowOf(Looper.getMainLooper()).idle()
            if (condition()) return
            Thread.sleep(25)
        }
        assertTrue("Timed out waiting for UI", condition())
    }
    private fun findViews(view: View): List<View> = listOf(view) +
        if (view is ViewGroup) (0 until view.childCount).flatMap { findViews(view.getChildAt(it)) } else emptyList()
    private fun findLabels(view: View) = findViews(view).filterIsInstance<android.widget.TextView>().map { it.text.toString() }
    private fun screenshot(screen: Activity, name: String, widthDp: Int, heightDp: Int) {
        val density = screen.resources.displayMetrics.density
        val width = (widthDp * density).toInt(); val height = (heightDp * density).toInt()
        val decor = screen.window.decorView
        decor.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY))
        decor.layout(0, 0, width, height)
        shadowOf(Looper.getMainLooper()).idle()
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        decor.draw(Canvas(bitmap))
        val output = File(System.getProperty("user.dir"), "build/ui-preview").apply { mkdirs() }
        File(output, name).outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    class Fixtures : ContentProvider() {
        override fun onCreate() = true
        override fun getType(uri: Uri) = "image/png"
        override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? = null
        override fun insert(uri: Uri, values: ContentValues?): Uri? = null
        override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?) = 0
        override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?) = 0
        @Synchronized override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
            val id = uri.lastPathSegment?.toIntOrNull() ?: 1
            val file = File(context!!.cacheDir, "fixture-$id.png")
            if (!file.exists()) {
                val bitmap = Bitmap.createBitmap(800, 560, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                paint.shader = LinearGradient(0f, 0f, 0f, 560f, Color.rgb(159,195,224), Color.rgb(240,220,173), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, 800f, 560f, paint); paint.shader = null
                paint.color = Color.rgb(246,222,161); canvas.drawCircle(610f, 125f, 50f, paint)
                paint.color = Color.rgb(99,131,143)
                val hills = Path().apply { moveTo(0f,390f); lineTo(180f,190f); lineTo(350f,370f); lineTo(520f,245f); lineTo(800f,405f); lineTo(800f,560f); lineTo(0f,560f); close() }
                canvas.drawPath(hills, paint)
                paint.color = Color.rgb(56,97,92)
                canvas.drawOval(-120f, 390f, 950f, 760f, paint)
                paint.color = Color.rgb(206,171,115)
                val trail = Path().apply { moveTo(350f,560f); lineTo(460f,455f); lineTo(490f,455f); lineTo(480f,560f); close() }
                canvas.drawPath(trail, paint)
                file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bitmap.recycle()
            }
            return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        }
        override fun openTypedAssetFile(uri: Uri, mimeTypeFilter: String, opts: Bundle?) =
            AssetFileDescriptor(openFile(uri, "r"), 0, AssetFileDescriptor.UNKNOWN_LENGTH)
    }
}
