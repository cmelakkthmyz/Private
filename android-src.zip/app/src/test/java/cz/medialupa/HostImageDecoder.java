package cz.medialupa;

import android.content.ContentResolver;
import android.graphics.ImageDecoder;
import android.net.Uri;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.robolectric.annotation.Implementation;
import org.robolectric.annotation.Implements;
import org.robolectric.shadows.ShadowNativeImageDecoder;

/** Host-only URI adapter: Android FDs are unavailable to Robolectric's Linux decoder.
 * The real Skia decoder still consumes the fixture PNG. Never included in the APK.
 */
@Implements(value = ImageDecoder.class, minSdk = 35, callNativeMethodsByDefault = true)
public class HostImageDecoder extends ShadowNativeImageDecoder {
    @Implementation
    protected static ImageDecoder.Source createSource(ContentResolver resolver, Uri uri) throws IOException {
        try (InputStream stream = resolver.openInputStream(uri)) {
            if (stream == null) throw new IOException("Fixture is unavailable");
            return ImageDecoder.createSource(ByteBuffer.wrap(stream.readAllBytes()));
        }
    }
}
