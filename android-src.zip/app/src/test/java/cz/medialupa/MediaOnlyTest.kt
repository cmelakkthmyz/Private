package cz.medialupa

import org.junit.Assert.*
import org.junit.Test

class MediaOnlyTest {
    @Test fun documentsScriptsAndExecutablesAreNotMedia() {
        listOf("script.py" to "text/x-python", "README.md" to "text/markdown",
            "invoice.pdf" to "application/pdf", "archive.zip" to "application/zip",
            "Word.docx" to "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "report.py" to "image/jpeg", "icon.svg" to "image/svg+xml")
            .forEach { (name, mime) -> assertFalse("$name $mime", MediaTypes.supported(name, mime)) }
    }

    @Test fun photosAndVideosInDocumentProvidersAreAccepted() {
        listOf("photo.jpg" to "image/jpeg", "photo.png" to "image/png",
            "photo.heic" to "image/heic", "clip.MP4" to "video/mp4",
            "clip.mkv" to "video/x-matroska", "raw.dng" to "image/x-adobe-dng",
            "photo.webp" to "application/octet-stream", "clip.mov" to "application/octet-stream")
            .forEach { (name, mime) -> assertTrue("$name $mime", MediaTypes.supported(name, mime)) }
    }

    @Test fun noiseIsRejectedButSpecificCropEvidenceIsAllowed() {
        assertTrue(LabelEvidence.bestLabels(listOf(LabelVote("Dog", .93f, false, 0))).contains("Dog"))
        assertFalse(LabelEvidence.bestLabels(listOf(LabelVote("Dog", .59f, false, 0))).contains("Dog"))
        assertTrue(LabelEvidence.bestLabels(listOf(
            LabelVote("Dog", .57f, true, 0), LabelVote("Dog", .61f, true, 1))).contains("Dog"))
        assertFalse(LabelEvidence.bestLabels(listOf(LabelVote("Photography", 1f, true, 0))).contains("Photography"))
        assertEquals(listOf("Dog", "Forest"), LabelEvidence.bestLabels(listOf(
            LabelVote("Forest", .74f, true, 0), LabelVote("Dog", .88f, true, 0))))
    }
}
