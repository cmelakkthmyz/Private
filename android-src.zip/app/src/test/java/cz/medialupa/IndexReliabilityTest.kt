package cz.medialupa

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.content.pm.ProviderInfo
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowContentResolver
import java.util.concurrent.CancellationException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class IndexReliabilityTest {
    private val app: Context get() = RuntimeEnvironment.getApplication()
    private lateinit var db: IndexDatabase
    @Before fun setup() { app.deleteDatabase("media_index.db"); db = IndexDatabase(app) }
    @After fun close() { db.close() }

    private fun file(id: Int, source: String = "PHONE_IMAGES") = IndexedFile(
        "content://media/external/images/media/$id", "content://media/external/images/media/$id",
        "Fotka $id.jpg", "image/jpeg", 100, 1000, "DCIM/Camera/", source, "Telefon")
    private fun face(x: Float = 1f, y: Float = 0f) = FaceSample(floatArrayOf(x, y), 0, .5f, .5f)
    private fun personCount() = db.readableDatabase.rawQuery("SELECT COUNT(*) FROM face_people", null).use { it.moveToFirst(); it.getInt(0) }
    private fun sampleCount() = db.readableDatabase.rawQuery("SELECT COUNT(*) FROM face_samples", null).use { it.moveToFirst(); it.getInt(0) }

    @Test fun labelTranslationDoesNotInventAnimalsFromWordFragments() {
        assertFalse(CzechSearch.indexedLabelText("Cathedral").contains("kocka"))
        assertFalse(CzechSearch.indexedLabelText("Hotdog").contains("pes"))
        assertTrue(CzechSearch.indexedLabelText("Dog").contains("pes"))
        assertTrue(CzechSearch.indexedLabelText("Domestic cat").contains("kocka"))
    }

    @Test fun unchangedRescanRetainsAnalysisHashAndUserNames() {
        val item = file(1)
        db.addBatch(listOf(item))
        db.saveAiResult(item.key, listOf("Dog", "Forest"), "Účtenka", true)
        db.setHash(item.key, "known-hash")
        db.saveFaceSamples(item.key, listOf(face()))
        val person = db.personAlbums().single()
        db.renamePerson(person.id, "Moje album")
        db.addBatch(listOf(item.copy(name = "Přejmenovaná fotka.jpg", folder = "Pictures/")))
        val found = db.search("pes les", FileFilter.AI).single()
        assertEquals("known-hash", found.sha256)
        assertEquals(1, found.analyzedVersion)
        assertEquals("Moje album", db.personAlbums().single().name)
        assertTrue(db.mediaToAnalyze(100, true).isEmpty())
        assertTrue(db.mediaToScanFaces(100).isEmpty())
    }

    @Test fun changedFileInvalidatesOnlyItsDerivedDataAndRebuildsPersonCenter() {
        val a = file(1); val b = file(2)
        db.addBatch(listOf(a, b))
        db.saveAiResult(a.key, listOf("Dog"), "", false)
        db.setHash(a.key, "old")
        db.saveFaceSamples(a.key, listOf(face()))
        db.saveFaceSamples(b.key, listOf(face(.98f, .1f)))
        val id = db.personAlbums().single().id
        db.renamePerson(id, "Zachované jméno")
        db.addBatch(listOf(a.copy(modified = 2000)))
        val changed = db.search("", FileFilter.ALL).single { it.key == a.key }
        assertNull(changed.sha256)
        assertEquals(0, changed.analyzedVersion)
        assertEquals(1, sampleCount())
        assertEquals("Zachované jméno", db.personAlbums().single().name)
        db.readableDatabase.rawQuery("SELECT sample_count FROM face_people WHERE id=?", arrayOf(id.toString())).use {
            assertTrue(it.moveToFirst()); assertEquals(1, it.getInt(0))
        }
    }

    @Test fun completedScanRemovesStaleBiometricsAndEmptyGroups() {
        val a = file(1); val b = file(2)
        db.addBatch(listOf(a, b))
        db.saveFaceSamples(a.key, listOf(face()))
        db.saveFaceSamples(b.key, listOf(face(0f, 1f)))
        db.markUnseen("PHONE_IMAGES")
        db.addBatch(listOf(b))
        db.dropUnseen("PHONE_IMAGES")
        assertEquals(listOf(b.key), db.search("", FileFilter.ALL).map { it.key })
        assertEquals(1, sampleCount()); assertEquals(1, personCount())
    }

    @Test fun failedWorkCanBeRetriedWithoutErasingValidResults() {
        val a = file(1); val b = file(2)
        db.addBatch(listOf(a, b))
        db.saveAiResult(a.key, listOf("Dog"), "Hotový text", true)
        db.markFacesScanned(a.key, false)
        db.markAiUnreadable(b.key)
        assertEquals(2, db.retryFailedAnalysis())
        assertEquals(listOf(b.key), db.mediaToAnalyze(100, true).map { it.key })
        assertEquals(1, db.search("pes", FileFilter.AI).size)
        assertEquals(0, db.retryFailedAnalysis())
    }

    @Test fun removingOnePersonErasesOnlyTheirTemplates() {
        val a = file(1); val b = file(2)
        db.addBatch(listOf(a, b))
        db.saveFaceSamples(a.key, listOf(face()))
        db.saveFaceSamples(b.key, listOf(face(0f, 1f)))
        val person = db.personAlbums().first()
        db.removePerson(person.id)
        assertEquals(2, db.stats().total)
        assertEquals(1, sampleCount()); assertEquals(1, personCount())
        assertTrue(db.search("", FileFilter.ALL, personId = person.id).isEmpty())
    }

    @Test fun databaseRejectsNonMediaAndCanRemoveOnlyOneFolderFromCatalog() {
        val valid = file(8).copy(source = "TREE:content://t/tree/1", folder = "/holiday/")
        val nested = file(9).copy(source = valid.source, folder = "/holiday/beach/")
        val other = file(10).copy(source = valid.source, folder = "/friends/")
        db.addBatch(listOf(valid, nested, other,
            file(100).copy(name = "evil.py", mime = "text/x-python"),
            file(101).copy(name = "invoice.pdf", mime = "application/pdf")))
        assertEquals(3, db.stats().total)
        db.removeFolderEntries(valid.source, "holiday")
        assertEquals(listOf(other.key), db.search("", FileFilter.ALL).map { it.key })
        db.removeSource(valid.source)
        assertEquals(0, db.stats().total)
    }

    @Test fun pendingCountsSpanMultipleSmallBatches() {
        val files = (1..153).map(::file)
        db.addBatch(files)
        assertEquals(153, db.pendingAiCount(false))
        assertEquals(75, db.mediaToAnalyze(75, false).size)
        for (f in files.take(75)) db.saveAiResult(f.key, listOf("Dog"), "", true)
        assertEquals(78, db.pendingAiCount(false))
        assertEquals(75, db.mediaToAnalyze(75, false).size)
        assertEquals(153, db.pendingFaceCount())
    }

    @Test fun invalidMergeCannotOrphanTemplates() {
        val a = file(1); db.addBatch(listOf(a)); db.saveFaceSamples(a.key, listOf(face()))
        val id = db.personAlbums().single().id
        try { db.mergePeople(999999, id); fail("Expected invalid album rejection") }
        catch (_: IllegalArgumentException) { }
        assertEquals(id, db.personAlbums().single().id)
        assertEquals(1, sampleCount())
    }

    @Test fun upgradeRepairsOrphanedTemplatesFromPreviousVersion() {
        val a = file(1); val b = file(2)
        db.addBatch(listOf(a, b))
        db.saveFaceSamples(a.key, listOf(face()))
        db.saveFaceSamples(b.key, listOf(face(0f, 1f)))
        db.writableDatabase.delete("entries", "key=?", arrayOf(a.key))
        db.writableDatabase.version = 3
        db.close()
        db = IndexDatabase(app)
        assertEquals(1, db.personAlbums().size)
        assertEquals(1, sampleCount()); assertEquals(1, personCount())
        assertEquals(5, db.readableDatabase.version)
    }

    @Test fun independentMediaPermissionsStillAllowGrantedVideoCollection() {
        val old = file(9000); db.addBatch(listOf(old))
        val provider = object : PhoneProvider() {
            override fun query(uri: Uri, projection: Array<out String>?, selection: String?, args: Array<out String>?, sort: String?): Cursor? {
                if (!uri.toString().contains("video")) throw SecurityException("Photos denied")
                return MatrixCursor(projection!!).apply {
                    addRow(arrayOf<Any>(1, "Klip.mp4", "video/mp4", 100, 1, "Movies/"))
                }
            }
        }
        provider.attachInfo(app, ProviderInfo().apply { authority = "media" })
        ShadowContentResolver.registerProviderInternal("media", provider)
        assertEquals(ScanOutcome(1, false), ContentIndexer(app, db).scanPhone({}))
        assertEquals(1, db.stats().videos)
        assertTrue(db.search("", FileFilter.ALL).any { it.key == old.key })
    }

    @Test fun duplicateHashingCanStopInsideFileAndReuseFinishedHashes() {
        val provider = object : PhoneProvider() {
            override fun openFile(uri: Uri, mode: String): android.os.ParcelFileDescriptor {
                val path = java.io.File(context!!.cacheDir, "duplicate-fixture.bin")
                path.writeBytes(ByteArray(256 * 1024) { 42 })
                return android.os.ParcelFileDescriptor.open(path, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
            }
        }
        provider.attachInfo(app, ProviderInfo().apply { authority = "media" })
        ShadowContentResolver.registerProviderInternal("media", provider)
        db.addBatch(listOf(file(1), file(2)))
        val finder = DuplicateFinder(app.contentResolver, db)
        var checks = 0
        assertEquals(0 to 0, finder.find({}) { ++checks >= 3 })
        assertTrue(db.search("", FileFilter.DUPLICATES).isEmpty())
        assertEquals(2 to 0, finder.find({}))
        assertEquals(2, db.search("", FileFilter.DUPLICATES).size)
        assertEquals(0 to 0, finder.find({}))
    }

    @Test fun cancelledPhoneScanPreservesCatalogAndCanBeStartedAgain() {
        val provider = PhoneProvider()
        provider.attachInfo(app, ProviderInfo().apply { authority = "media" })
        ShadowContentResolver.registerProviderInternal("media", provider)
        val stale = file(9000)
        db.addBatch(listOf(stale)); db.saveFaceSamples(stale.key, listOf(face()))
        var cancelled = false
        val indexer = ContentIndexer(app, db)
        try {
            indexer.scanPhone({ if (it.contains("200 položek")) cancelled = true }) { cancelled }
            fail("Expected cancellation")
        } catch (_: CancellationException) { }
        assertTrue(db.search("", FileFilter.ALL, limit = 1000).any { it.key == stale.key })
        assertEquals(1, sampleCount())
        assertEquals(ScanOutcome(201, true), ContentIndexer(app, db, { true }).scanPhone({}))
        assertEquals(201, db.stats().total)
        assertEquals(0, sampleCount()); assertEquals(0, personCount())
    }

    @Test fun limitedPhotoSelectionCannotDeletePreviouslyIndexedFaceAlbums() {
        val old = file(9000)
        db.addBatch(listOf(old))
        db.saveAiResult(old.key, listOf("Dog"), "", false)
        db.saveFaceSamples(old.key, listOf(face()))
        val person = db.personAlbums().single()
        db.renamePerson(person.id, "Moje pojmenovaná osoba")
        val provider = PhoneProvider()
        provider.attachInfo(app, ProviderInfo().apply { authority = "media" })
        ShadowContentResolver.registerProviderInternal("media", provider)

        // Simulate Android's selected-photos grant: MediaStore reports only a subset.
        val partial = ContentIndexer(app, db, { false }).scanPhone({})
        assertEquals(ScanOutcome(201, false), partial)
        assertEquals(202, db.stats().total)
        assertEquals("Moje pojmenovaná osoba", db.personAlbums().single().name)
        assertEquals(1, db.search("pes", FileFilter.AI).size)

        // Once full read permission is granted, a full rescan may remove stale entries.
        val full = ContentIndexer(app, db, { true }).scanPhone({})
        assertEquals(ScanOutcome(201, true), full)
        assertEquals(201, db.stats().total)
        assertTrue(db.personAlbums().isEmpty())
    }

    @Test fun inaccessibleTreeChildrenNeverEraseExistingCatalog() {
        val tree = Uri.parse("content://test.documents/tree/root")
        val source = "TREE:$tree"
        val old = file(1, source)
        db.addBatch(listOf(old))
        val provider = object : PhoneProvider() {
            override fun query(uri: Uri, projection: Array<out String>?, selection: String?, args: Array<out String>?, sort: String?): Cursor? {
                if (uri.path!!.endsWith("/children")) return null
                return MatrixCursor(projection!!).apply { addRow(arrayOf("root", "Vybraná složka")) }
            }
        }
        provider.attachInfo(app, ProviderInfo().apply { authority = "test.documents" })
        ShadowContentResolver.registerProviderInternal("test.documents", provider)
        val messages = mutableListOf<String>()
        assertEquals(ScanOutcome(0, false), ContentIndexer(app, db).scanTree(tree, { messages.add(it) }))
        assertEquals(1, db.stats().total)
        assertTrue(messages.last().contains("neúplný"))
    }

    open class PhoneProvider : ContentProvider() {
        override fun onCreate() = true
        override fun getType(uri: Uri) = "image/jpeg"
        override fun insert(uri: Uri, values: ContentValues?): Uri? = null
        override fun update(uri: Uri, values: ContentValues?, selection: String?, args: Array<out String>?) = 0
        override fun delete(uri: Uri, selection: String?, args: Array<out String>?) = 0
        override fun query(uri: Uri, projection: Array<out String>?, selection: String?, args: Array<out String>?, sort: String?): Cursor? {
            return MatrixCursor(projection!!).apply {
                if (!uri.toString().contains("video")) for (id in 1..201)
                    addRow(arrayOf<Any>(id, "Fotka $id.jpg", "image/jpeg", 100, 1, "DCIM/Camera/"))
            }
        }
    }
}
