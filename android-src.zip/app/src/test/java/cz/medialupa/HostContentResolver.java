package cz.medialupa;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.CancellationSignal;
import android.util.Size;
import java.io.IOException;
import org.robolectric.annotation.Implementation;
import org.robolectric.annotation.Implements;
import org.robolectric.annotation.RealObject;
import org.robolectric.shadows.ShadowContentResolver;

/** Fixtures for the OS-owned thumbnail service, whose Android FD bridge cannot run on Linux. */
@Implements(ContentResolver.class)
public class HostContentResolver extends ShadowContentResolver {
    @RealObject private ContentResolver resolver;
    @Implementation(minSdk = 29)
    protected Bitmap loadThumbnail(Uri uri, Size size, CancellationSignal cancellation) throws IOException {
        return ImageDecoder.decodeBitmap(ImageDecoder.createSource(resolver, uri), (decoder, info, source) -> {
            int side = Math.max(size.getWidth(), size.getHeight());
            float ratio = Math.min(1f, (float) side / Math.max(info.getSize().getWidth(), info.getSize().getHeight()));
            decoder.setTargetSize(Math.max(1, Math.round(info.getSize().getWidth() * ratio)),
                Math.max(1, Math.round(info.getSize().getHeight() * ratio)));
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
        });
    }
}
