package cz.medialupa

import org.junit.Assert.*
import org.junit.Test

class SmartAlbumsTest {
    private fun group(id: Long, x: Float, y: Float, frame: String, name: String = "") =
        FaceClusterGroup(id, name, floatArrayOf(x, y), listOf(floatArrayOf(x, y)), setOf(frame))

    @Test fun multiplePhotosOfSamePersonFormOneAlbum() {
        val suggested = FaceAutoCluster.suggestMerge(listOf(
            group(1, 1f, 0f, "photo1@0"),
            group(2, .97f, .24f, "photo2@0"),
            group(3, .96f, .28f, "photo3@0"),
            group(4, 0f, 1f, "photo4@0")
        ))
        assertEquals(2, suggested.size)
        assertFalse(suggested.any { it.first == 4L || it.second == 4L })
    }

    @Test fun differentFacesOnSameFrameNeverMerge() {
        assertTrue(FaceAutoCluster.suggestMerge(listOf(
            group(1,1f,0f,"image@0"),group(2,.999f,.01f,"image@0")
        )).isEmpty())
    }

    @Test fun confirmedDifferentNamesAreNotMerged() {
        assertTrue(FaceAutoCluster.suggestMerge(listOf(
            group(1,1f,0f,"a@0","Jan"),group(2,.99f,.1f,"b@0","Petr")
        )).isEmpty())
    }

    @Test fun captionsAreConciseAndNeverInventRelationships() {
        assertEquals("Video · dvě osoby v pokoji",
            MediaDescription.caption("video/mp4","room, people",2))
        assertEquals("Fotografie · pes v zahradě",
            MediaDescription.caption("image/jpeg","dog, garden"))
        assertEquals("Video · Jana, Petr v pokoji",
            MediaDescription.caption("video/mp4","room",2,listOf("Jana","Petr")))
        assertFalse(MediaDescription.caption("video/mp4","people",4).contains("rodinné"))
        assertTrue(MediaDescription.caption("image/jpeg","",analyzed=false).contains("čeká na analýzu"))
    }
}
