package cz.medialupa

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Size
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/** Offline detekce + embedding. Zadna sit, zadne automaticke pojmenovani osoby. */
class FaceLibraryIndexer(private val context: Context, private val db: IndexDatabase) {
    fun run(maxItems: Int, progress: (String) -> Unit, cancelled: () -> Boolean): Pair<Int, Int> {
        val files = db.mediaToScanFaces(maxItems)
        val modelBytes = context.assets.open("mobile_face_net.tflite").use { it.readBytes() }
        val model = ByteBuffer.allocateDirect(modelBytes.size).order(ByteOrder.nativeOrder())
        model.put(modelBytes)
        model.rewind()
        val interpreter = Interpreter(model, Interpreter.Options().setNumThreads(2))
        val detector = FaceDetection.getClient(FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setMinFaceSize(0.09f)
            .build())
        var done = 0
        var errors = 0
        try {
            for (file in files) {
                if (cancelled()) break
                try {
                    val collected = mutableListOf<FaceSample>()
                    val uri = Uri.parse(file.uri)
                    if (file.mime.startsWith("video/")) {
                        val retriever = MediaMetadataRetriever()
                        try {
                            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use {
                                retriever.setDataSource(it.fileDescriptor)
                            } ?: error("Nedostupne video")
                            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                            val stamps = if (duration > 0) listOf(0L, duration / 4, duration / 2, duration * 3 / 4, duration * 9 / 10) else listOf(0L)
                            var readableFrames = 0
                            for (ms in stamps) {
                                if (cancelled()) break
                                val img = retriever.getFrameAtTime(ms * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                                    ?: continue
                                readableFrames++
                                val small = shrink(img)
                                try { collected.addAll(analyzeFrame(small, ms * 1000L, detector, interpreter)) }
                                finally { small.recycle() }
                            }
                            if (readableFrames == 0 && !cancelled()) error("Video neobsahuje čitelné snímky")
                        } finally { retriever.release() }
                    } else {
                        val img = context.contentResolver.loadThumbnail(uri, Size(1600,1600),null)
                        try { collected.addAll(analyzeFrame(img,0L,detector,interpreter)) }
                        finally { img.recycle() }
                    }
                    // Never mark a partly scanned video complete when Stop was pressed.
                    if (cancelled()) break
                    db.saveFaceSamples(file.key,collected)
                    done++
                } catch (ex: Exception) {
                    db.markFacesScanned(file.key,false)
                    errors++
                }
                if ((done+errors)%3==0 || done+errors==files.size)
                    progress("Obličeje: ${done+errors}/${files.size} · úspěšně $done · chyby $errors")
            }
        } finally { detector.close();interpreter.close() }
        return done to errors
    }

    private fun shrink(image: Bitmap): Bitmap {
        val maxSide = max(image.width,image.height)
        if(maxSide<=1600) return image
        val ratio=1600.0/maxSide
        val result=Bitmap.createScaledBitmap(image,
            (image.width*ratio).toInt().coerceAtLeast(1),
            (image.height*ratio).toInt().coerceAtLeast(1),true)
        if (result !== image) image.recycle()
        return result
    }

    private fun analyzeFrame(bitmap:Bitmap, timeUs:Long,
        detector:com.google.mlkit.vision.face.FaceDetector, interpreter:Interpreter):List<FaceSample> {
        val faces=Tasks.await(detector.process(InputImage.fromBitmap(bitmap,0)))
        return faces.mapNotNull { face ->
            val rect=pad(face.boundingBox,bitmap.width,bitmap.height)
            if(rect.width()<60 || rect.height()<60) return@mapNotNull null
            val cut=Bitmap.createBitmap(bitmap,rect.left,rect.top,rect.width(),rect.height())
            val scaled=Bitmap.createScaledBitmap(cut,112,112,true)
            try {
                val raw=IntArray(112*112)
                scaled.getPixels(raw,0,112,0,0,112,112)
                val input=ByteBuffer.allocateDirect(112*112*3*4).order(ByteOrder.nativeOrder())
                val shape=interpreter.getInputTensor(0).shape()
                if(shape.size==4 && shape[1]==3 && shape[3]!=3) {
                    // NCHW: Qualcomm a dalsi exporty.
                    for(channel in 0..2) for(pixel in raw) {
                        val value=when(channel){0->(pixel shr 16) and 255;1->(pixel shr 8) and 255;else->pixel and 255}
                        input.putFloat(value/128f-1f)
                    }
                } else {
                    // NHWC: MobileFaceNet pro vetsinu beznych Android exportu.
                    for(pixel in raw) {
                        input.putFloat((((pixel shr 16) and 255)/128f)-1f)
                        input.putFloat((((pixel shr 8) and 255)/128f)-1f)
                        input.putFloat(((pixel and 255)/128f)-1f)
                    }
                }
                input.rewind()
                val out=ByteBuffer.allocateDirect(interpreter.getOutputTensor(0).numBytes())
                    .order(ByteOrder.nativeOrder())
                interpreter.run(input,out)
                out.rewind()
                val emb=FloatArray(out.remaining()/4){out.float}
                val length=kotlin.math.sqrt(emb.sumOf{(it*it).toDouble()}).toFloat()
                if(length < 1e-6f) null else FaceSample(FloatArray(emb.size){emb[it]/length},timeUs,
                    face.boundingBox.exactCenterX()/bitmap.width,
                    face.boundingBox.exactCenterY()/bitmap.height)
            } finally {scaled.recycle();if(cut!==scaled)cut.recycle()}
        }
    }

    private fun pad(r:Rect,width:Int,height:Int):Rect {
        val d=(max(r.width(),r.height())*0.18f).toInt()
        val left=max(0,r.left-d);val top=max(0,r.top-d)
        val right=min(width,r.right+d);val bottom=min(height,r.bottom+d)
        return Rect(left,top,max(left,right),max(top,bottom))
    }
}
