package cz.medialupa

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.os.StatFs

/** Univerzální profil podle dostupné paměti, nikoliv podle značky telefonu. */
data class DeviceProfile(val ramGiB: Double, val freeGiB: Double, val cores: Int, val recommendedBatch: Int) {
    val description: String get() = when {
        ramGiB < 4 -> "Úsporný režim"
        ramGiB < 8 -> "Standardní režim"
        else -> "Výkonný režim"
    }
    companion object {
        fun detect(context: Context): DeviceProfile {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memory = ActivityManager.MemoryInfo()
            manager.getMemoryInfo(memory)
            val gib = 1024.0 * 1024.0 * 1024.0
            val ram = memory.totalMem / gib
            val stat = StatFs(context.filesDir.absolutePath)
            val free = stat.availableBytes / gib
            val cores = Runtime.getRuntime().availableProcessors()
            val batch = when { ram < 4 || cores <= 4 -> 25; ram < 8 -> 75; else -> 150 }
            return DeviceProfile(ram, free, cores, batch)
        }
    }
}
