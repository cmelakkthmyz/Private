package cz.medialupa

import java.text.Normalizer
import java.util.Locale

/** Jednoduchý offline slovník – není generativní model ani úplný překladač. */
object CzechSearch {
    private val names = linkedMapOf(
        "dog" to "pes psi psa pejska štěně pejsek", "cat" to "kočka kočky kočku kotě",
        "bird" to "pták ptáci ptáček", "fish" to "ryba ryby rybář",
        "horse" to "kůň koně", "animal" to "zvíře zvířata",
        "person" to "osoba člověk lidé lidi", "people" to "lidé lidi osoby",
        "human" to "člověk lidé", "baby" to "dítě miminko kojenec",
        "child" to "dítě děti", "face" to "tvář obličej",
        "car" to "auto automobil auta vozidlo", "vehicle" to "vozidlo auto",
        "bicycle" to "kolo bicykl jízdní", "motorcycle" to "motorka motocykl",
        "airplane" to "letadlo", "train" to "vlak", "boat" to "loď člun",
        "building" to "budova stavba", "house" to "dům domy",
        "road" to "silnice cesta", "street" to "ulice",
        "food" to "jídlo pokrm", "drink" to "nápoj pití",
        "flower" to "květina květiny kytka", "plant" to "rostlina",
        "tree" to "strom stromy", "forest" to "les lesní",
        "mountain" to "hora hory", "river" to "řeka", "water" to "voda vody vodní",
        "lake" to "jezero rybník", "sea" to "moře", "beach" to "pláž",
        "sky" to "obloha nebe", "cloud" to "mrak mraky oblak",
        "sunset" to "západ slunce", "snow" to "sníh zimní",
        "document" to "dokument listina", "text" to "text nápis písmo",
        "receipt" to "účtenka doklad", "book" to "kniha",
        "screen" to "obrazovka displej snímek screenshot",
        "computer" to "počítač", "phone" to "telefon mobil",
        "clothing" to "oblečení oděv", "shoes" to "boty obuv",
        "furniture" to "nábytek", "kitchen" to "kuchyně",
        "sport" to "sport", "ball" to "míč",
        "nature" to "příroda krajina", "landscape" to "krajina příroda"
    )
    private val ignore = setOf("najdi", "ukaz", "vsechny", "vsechno", "moje", "muj", "mi", "me", "fotky", "fotka", "fotografii", "fotografie", "obrazky", "obrazek", "kde", "na", "u", "se", "s", "ve", "v", "z", "ze", "a", "nebo", "ktere", "ktery", "obsahuje", "obsahuji", "soubor", "soubory")
    private val inverse: Map<String, String> = buildMap {
        for ((english, synonyms) in names) {
            put(normalized(english), normalized(english))
            for (synonym in synonyms.split(' ')) put(normalized(synonym), normalized(synonyms).split(' ').first())
        }
    }
    fun normalized(input: String): String = Normalizer.normalize(input.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z0-9 ]"), " ").replace(Regex(" +"), " ").trim()

    fun searchTokens(input: String): List<String> = normalized(input).split(' ')
        .filter { it.isNotBlank() && it !in ignore }
        .map { inverse[it] ?: it }.distinct().take(8)

    fun indexedLabelText(english: String): String {
        val input = normalized(english)
        val czech = names.entries.filter { (" $input ").contains(" ${it.key} ") }
            .joinToString(" ") { it.value }
        return normalized("$english $czech")
    }

    fun displayLabels(english: List<String>): String = english.mapNotNull { name ->
        val key = normalized(name)
        names.entries.firstOrNull { key == it.key }?.value?.split(' ')?.first()
    }.distinct().take(5).joinToString(", ")
}
