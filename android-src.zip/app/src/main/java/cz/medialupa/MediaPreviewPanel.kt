package cz.medialupa

import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MediaPreviewPanel(context: Context, private val onOpen: () -> Unit, private val onShare: () -> Unit,
    private val onPrevious: () -> Unit, private val onNext: () -> Unit) : LinearLayout(context) {
    private val ui = Ui(context)
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var generation = 0
    private var closed = false
    private val image = ZoomImageView(context)
    private val placeholder = ui.label("Vyber soubor pro náhled", 14f, 0xFFBAC7D6.toInt()).apply { gravity = Gravity.CENTER; ui.pad(this, 16) }
    private val play = ui.iconButton("Přehrát video", R.drawable.ic_play) { onOpen() }.apply {
        setImageDrawable(ui.icon(R.drawable.ic_play, Color.WHITE)); background = ui.touch(ui.viewer)
    }
    private val title = ui.label("", 15f, bold = true)
    private val detail = ui.label("", 12f, ui.muted)
    private val path = ui.label("", 12f, ui.muted)
    private val loading = ProgressBar(context)
    private val open = ui.button("Otevřít náhled", R.drawable.ic_maximize) { onOpen() }
    private val share = ui.iconButton("Sdílet soubor", R.drawable.ic_share_2) { onShare() }
    init {
        orientation = VERTICAL; setBackgroundColor(ui.surface)
        val heading = ui.row().apply { ui.pad(this, 12) }
        heading.addWeighted(ui.label("Náhled", 15f, bold = true), 1f, -2)
        heading.addView(ui.iconButton("Předchozí soubor", R.drawable.ic_chevron_left) { onPrevious() }, LayoutParams(ui.dp(44), ui.dp(48)))
        heading.addView(ui.iconButton("Další soubor", R.drawable.ic_chevron_right) { onNext() }, LayoutParams(ui.dp(44), ui.dp(48)))
        addView(heading)
        val stage = FrameLayout(context).apply { setBackgroundColor(ui.viewer) }
        stage.addView(image, FrameLayout.LayoutParams(-1, -1))
        stage.addView(placeholder, FrameLayout.LayoutParams(-1, -1))
        stage.addView(play, FrameLayout.LayoutParams(ui.dp(56), ui.dp(56), Gravity.CENTER))
        stage.addView(loading, FrameLayout.LayoutParams(ui.dp(32), ui.dp(32), Gravity.CENTER))
        addView(stage, LayoutParams(-1, 0, 1f))
        val info = ui.column().apply { ui.pad(this, 14) }
        title.maxLines = 2; path.maxLines = 3; detail.setPadding(0, ui.dp(6), 0, ui.dp(8))
        info.addView(title); info.addView(detail); info.addView(path)
        val actions = ui.row().apply { setPadding(0, ui.dp(8), 0, 0) }
        actions.addWeighted(open, 1f, ui.dp(48)); actions.addView(share, LayoutParams(ui.dp(48), ui.dp(48)))
        info.addView(actions); addView(info)
        clear()
    }
    fun clear() {
        generation++; image.setImageDrawable(null)
        title.text = ""; detail.text = ""; path.text = ""
        placeholder.text = "Vyber soubor pro náhled"; placeholder.visibility = View.VISIBLE
        play.visibility = View.GONE; loading.visibility = View.GONE; open.isEnabled = false; share.isEnabled = false
    }
    fun showFile(file: IndexedFile) {
        val request = ++generation
        image.setImageDrawable(null); placeholder.visibility = View.GONE; loading.visibility = View.VISIBLE
        play.visibility = View.GONE; title.text = file.name
        val date = if (file.modified > 0) SimpleDateFormat("d. M. yyyy", Locale("cs", "CZ")).format(Date(file.modified)) else ""
        detail.text = "${FileRowAdapter.formatSize(file.size)} · $date\n${file.aiLabels}"
        path.text = "${file.sourceLabel}\n${file.folder}"
        open.isEnabled = true; share.isEnabled = true
        val media = file.mime.startsWith("image/") || file.mime.startsWith("video/")
        if (!media) {
            placeholder.text = "Tento soubor otevři v příslušné aplikaci."; placeholder.visibility = View.VISIBLE; loading.visibility = View.GONE
            return
        }
        worker.execute {
            val bitmap = try { ThumbnailLoader.preview(context.applicationContext, Uri.parse(file.uri), file.mime, 1600) }
                catch (_: Exception) { null } catch (_: OutOfMemoryError) { null }
            handler.post {
                if (closed || request != generation) return@post
                loading.visibility = View.GONE
                if (bitmap != null) image.showBitmap(bitmap)
                else { placeholder.text = "Náhled se nepodařilo načíst"; placeholder.visibility = View.VISIBLE }
                play.visibility = if (file.mime.startsWith("video/")) View.VISIBLE else View.GONE
            }
        }
    }
    fun shutdown() { closed = true; generation++; worker.shutdownNow(); handler.removeCallbacksAndMessages(null) }
}
