package cz.medialupa

import android.content.ContentResolver
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.util.Size
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Fully local ML Kit. Multiple views and temporal samples improve recall, but remain general-purpose labels. */
class OfflineImageAnalyzer(private val resolver: ContentResolver, private val db: IndexDatabase) {
    fun run(maxItems: Int, withOcr: Boolean, progress: (String) -> Unit,
        cancelled: () -> Boolean = { false }): Pair<Int, Int> {
        val files = db.mediaToAnalyze(maxItems, withOcr)
        if (files.isEmpty()) return 0 to 0
        val labeler = ImageLabeling.getClient(ImageLabelerOptions.Builder()
            .setConfidenceThreshold(0.4f).build())
        val textRecognizer = if (withOcr) TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) else null
        var done = 0
        var errors = 0
        try {
            for (file in files) {
                if (cancelled()) break
                try {
                    val frames = sampleFrames(file.uri, file.mime.startsWith("video/"))
                    val votes = mutableListOf<LabelVote>()
                    val words = linkedSetOf<String>()
                    try {
                        for ((frameIndex, bitmap) in frames.withIndex()) {
                            if (cancelled()) break
                            classify(labeler, bitmap, true, frameIndex, votes)
                            // A small object may be invisible in a whole-image classifier.
                            // Crop analysis only uses strong predictions to avoid false positives.
                            for (crop in crops(bitmap, file.mime.startsWith("video/"))) {
                                try { classify(labeler, crop, false, frameIndex, votes) }
                                finally { if (!crop.isRecycled) crop.recycle() }
                                if (cancelled()) break
                            }
                            if (textRecognizer != null && (frameIndex == 0 ||
                                    (frames.size > 2 && frameIndex == frames.size / 2))) {
                                val text = Tasks.await(textRecognizer.process(InputImage.fromBitmap(bitmap, 0))).text
                                if (text.isNotBlank()) words.add(text)
                            }
                        }
                    } finally { frames.forEach { if (!it.isRecycled) it.recycle() } }
                    if (cancelled()) break
                    db.saveAiResult(file.key, LabelEvidence.bestLabels(votes), words.joinToString("\n"), withOcr)
                    done++
                } catch (e: Exception) {
                    errors++
                    db.markAiUnreadable(file.key)
                }
                if ((done + errors) % 5 == 0 || done + errors == files.size)
                    progress("Offline AI: ${done + errors}/${files.size} · hotovo $done · nečitelné $errors")
            }
        } finally { labeler.close(); textRecognizer?.close() }
        return done to errors
    }

    private fun classify(
        labeler: com.google.mlkit.vision.label.ImageLabeler,
        bitmap: Bitmap, full: Boolean, frame: Int, votes: MutableList<LabelVote>
    ) {
        Tasks.await(labeler.process(InputImage.fromBitmap(bitmap, 0)))
            .sortedByDescending { it.confidence }.take(20)
            .forEach { votes.add(LabelVote(it.text, it.confidence, full, frame)) }
    }

    private fun crops(bitmap: Bitmap, video: Boolean): List<Bitmap> {
        if (minOf(bitmap.width, bitmap.height) < 360) return emptyList()
        val w = (bitmap.width * .64f).toInt().coerceAtLeast(1)
        val h = (bitmap.height * .64f).toInt().coerceAtLeast(1)
        val points = if (video) listOf((bitmap.width - w) / 2 to (bitmap.height - h) / 2)
            else listOf(0 to 0, (bitmap.width - w) to 0,
                0 to (bitmap.height - h), (bitmap.width - w) to (bitmap.height - h))
        return points.map { (x, y) -> Bitmap.createBitmap(bitmap, x, y, w, h) }
    }

    private fun sampleFrames(uri: String, video: Boolean): List<Bitmap> {
        val parsed = Uri.parse(uri)
        if (!video) {
            val thumbnail = try { resolver.loadThumbnail(parsed, Size(1200, 1200), null) }
                catch (_: Exception) {
                    val source = ImageDecoder.createSource(resolver, parsed)
                    ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                        val width = info.size.width; val height = info.size.height
                        val factor = minOf(1f, 1200f / maxOf(width, height))
                        decoder.setTargetSize((width * factor).toInt().coerceAtLeast(1),
                            (height * factor).toInt().coerceAtLeast(1))
                        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    }
                }
            return listOf(thumbnail)
        }
        val retriever = MediaMetadataRetriever()
        try {
            resolver.openAssetFileDescriptor(parsed, "r")?.use { descriptor ->
                retriever.setDataSource(descriptor.fileDescriptor)
            } ?: error("Video nelze otevřít")
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val times = if (durationMs > 0) listOf(10L, 30L, 50L, 70L, 90L).map { durationMs * it / 100 }
                .distinct() else listOf(0L)
            return times.mapNotNull { ms ->
                retriever.getFrameAtTime(ms * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { frame ->
                    val ratio = 960f / maxOf(frame.width, frame.height)
                    if (ratio >= 1f) frame else Bitmap.createScaledBitmap(frame,
                        (frame.width * ratio).toInt().coerceAtLeast(1),
                        (frame.height * ratio).toInt().coerceAtLeast(1), true).also { frame.recycle() }
                }
            }.ifEmpty { error("Video neobsahuje čitelné snímky") }
        } finally { retriever.release() }
    }
}
