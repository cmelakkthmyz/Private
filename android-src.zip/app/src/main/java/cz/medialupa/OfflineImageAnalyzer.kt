package cz.medialupa

import android.content.ContentResolver
import android.net.Uri
import android.media.MediaMetadataRetriever
import android.graphics.Bitmap
import android.util.Size
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Používá *zabalené* ML Kit modely, nevolá cloudové API. */
class OfflineImageAnalyzer(private val resolver: ContentResolver, private val db: IndexDatabase) {
    fun run(maxItems: Int, withOcr: Boolean, progress: (String) -> Unit,
        cancelled: () -> Boolean = { false }): Pair<Int, Int> {
        val files = db.mediaToAnalyze(maxItems, withOcr)
        if (files.isEmpty()) return 0 to 0
        val labeler = ImageLabeling.getClient(ImageLabelerOptions.Builder()
            .setConfidenceThreshold(0.48f).build())
        val textRecognizer = if (withOcr) TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) else null
        var done = 0
        var errors = 0
        try {
            for (file in files) {
                if (cancelled()) break
                try {
                    // Android 10+, zmenšený obrázek kvůli RAM; jen soubory z telefonu.
                    val frames = sampleFrames(file.uri, file.mime.startsWith("video/"))
                    val labels = linkedSetOf<String>()
                    val words = mutableListOf<String>()
                    try {
                    for ((i, bitmap) in frames.withIndex()) {
                        val image = InputImage.fromBitmap(bitmap, 0)
                        val found = Tasks.await(labeler.process(image)).sortedByDescending { it.confidence }
                        labels.addAll(found.take(8).map { it.text })
                        if (i == 0 && textRecognizer != null) words += Tasks.await(textRecognizer.process(image)).text
                    }
                    } finally { frames.forEach { if (!it.isRecycled) it.recycle() } }
                    db.saveAiResult(file.key, labels.toList().take(24), words.joinToString(" "), withOcr)
                    done++
                } catch (e: Exception) {
                    errors++
                    db.markAiUnreadable(file.key)
                }
                if ((done + errors) % 5 == 0 || done + errors == files.size)
                    progress("Offline AI: ${done + errors}/${files.size} · úspěšně $done · chyb $errors")
            }
        } finally { labeler.close(); textRecognizer?.close() }
        return done to errors
    }

    private fun sampleFrames(uri: String, video: Boolean): List<Bitmap> {
        if (!video) return listOf(resolver.loadThumbnail(Uri.parse(uri), Size(960, 960), null))
        val retriever = MediaMetadataRetriever()
        try {
            resolver.openAssetFileDescriptor(Uri.parse(uri), "r")?.use { descriptor ->
                retriever.setDataSource(descriptor.fileDescriptor)
            } ?: error("Video nelze otevřít")
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val times = if (durationMs > 0) listOf(0L, durationMs / 2L, durationMs * 4L / 5L)
                else listOf(0L)
            return times.mapNotNull { ms ->
                retriever.getFrameAtTime(ms * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { frame ->
                    val ratio = 960f / maxOf(frame.width, frame.height)
                    if (ratio >= 1f) frame else Bitmap.createScaledBitmap(frame,
                        (frame.width * ratio).toInt().coerceAtLeast(1),
                        (frame.height * ratio).toInt().coerceAtLeast(1), true).also { frame.recycle() }
                }
            }.ifEmpty { error("Video neobsahuje čitelné snímky") }
        } finally { retriever.release() }
    }
}
