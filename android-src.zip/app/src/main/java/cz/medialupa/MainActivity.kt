package cz.medialupa

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import java.util.concurrent.Executors
import java.util.concurrent.CancellationException

class MainActivity : Activity() {
    private lateinit var database: IndexDatabase
    private lateinit var indexer: ContentIndexer
    private lateinit var adapter: FileRowAdapter
    private lateinit var albumsAdapter: AlbumRowAdapter
    private enum class BrowseMode { FILES, TOPICS, PEOPLE }
    private var browseMode = BrowseMode.FILES
    private var selectedTopic: String? = null
    private var selectedPerson: Long? = null
    private var selectedAlbumTitle = ""
    private var selectedSource: String? = null
    private var folderPath = ""
    private var allFolders: List<FolderEntry> = emptyList()
    private val expandedFolders = mutableSetOf<String>()
    private var visibleTopics: List<TopicAlbum> = emptyList()
    private var visiblePeople: List<PersonAlbum> = emptyList()
    private var faceRunning = false
    private val background = Executors.newSingleThreadExecutor()
    private var filter = FileFilter.ALL
    private var sortOrder = SortOrder.NEWEST
    private lateinit var deviceProfile: DeviceProfile
    private lateinit var aiScan: Button
    private lateinit var faceScan: Button
    private lateinit var faceClear: Button
    private lateinit var withOcr: CheckBox
    private var busy = false
    @Volatile private var aiRunning = false
    @Volatile private var cancelRequested = false
    private val prefs by lazy { getSharedPreferences("sources", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var scanPhone: Button
    private lateinit var addFolder: Button
    private lateinit var checkDuplicates: Button
    private lateinit var results: GridView
    private lateinit var ui: Ui
    private lateinit var shell: LinearLayout
    private lateinit var sidebar: LinearLayout
    private lateinit var sidebarBody: LinearLayout
    private lateinit var preview: MediaPreviewPanel
    private lateinit var breadcrumbs: LinearLayout
    private lateinit var breadcrumbScroll: HorizontalScrollView
    private lateinit var albumTitle: TextView
    private lateinit var summary: TextView
    private lateinit var emptyState: LinearLayout
    private lateinit var emptyTitle: TextView
    private lateinit var emptyMessage: TextView
    private lateinit var emptyAction: Button
    private lateinit var filterBar: LinearLayout
    private lateinit var navBar: LinearLayout
    private lateinit var viewToggle: ImageButton
    private lateinit var folderMenuButton: ImageButton
    private lateinit var browserBody: LinearLayout
    private lateinit var upButton: ImageButton
    private lateinit var stopButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var moreResults: Button
    private var tiled = true
    private var resultLimit = 250
    private var reloadVersion = 0
    private var selectedFile: IndexedFile? = null
    private var treeDialog: Dialog? = null
    private var toolsDialog: AlertDialog? = null
    private var restoring = false

    companion object {
        private const val PERMISSION_REQUEST = 501
        private const val TREE_REQUEST = 502
        private const val DELETE_MEDIA_REQUEST = 503
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = Ui(this)
        database = IndexDatabase(this)
        indexer = ContentIndexer(this, database)
        adapter = FileRowAdapter(this)
        albumsAdapter = AlbumRowAdapter(this)
        deviceProfile = DeviceProfile.detect(this)
        tiled = prefs.getBoolean("tiles", true)
        savedInstanceState?.let {
            browseMode = BrowseMode.entries.getOrElse(it.getInt("mode")) { BrowseMode.FILES }
            selectedTopic = it.getString("topic")
            selectedPerson = if (it.containsKey("person")) it.getLong("person") else null
            selectedAlbumTitle = it.getString("album", "")
            selectedSource = it.getString("source")
            folderPath = it.getString("path", "")
            filter = FileFilter.entries.getOrElse(it.getInt("filter")) { FileFilter.ALL }
            sortOrder = SortOrder.entries.getOrElse(it.getInt("sort")) { SortOrder.NEWEST }
        }
        // Older saved navigation may point to Documents, which this media-only app no longer indexes.
        if (filter == FileFilter.DOCUMENTS) filter = FileFilter.ALL
        createWorkButtons()
        buildInterface()
        restoring = true
        search.setText(savedInstanceState?.getString("query") ?: "")
        restoring = false
        refreshMode()
        reload()
    }

    private fun createWorkButtons() {
        scanPhone = ui.button("Načíst média z telefonu", R.drawable.ic_refresh_cw) { closeTools(); requestMediaAccessOrScan() }
        addFolder = ui.button("Připojit složku", R.drawable.ic_folder) { closeTools(); chooseFolder() }
        aiScan = ui.button("Rozpoznat obsah", R.drawable.ic_sparkles) {
            closeTools()
            if (aiRunning) { cancelRequested = true; showStatus("Dokončuji soubor a zastavuji analýzu…") }
            else analyzePhoneImages()
        }
        checkDuplicates = ui.button("Najít přesné duplicity", R.drawable.ic_copy) { closeTools(); checkExactDuplicates() }
        faceScan = ui.button("Najít osoby", R.drawable.ic_scan_face) {
            closeTools()
            if (faceRunning) { cancelRequested = true; showStatus("Zastavuji hledání obličejů…") }
            else if (!prefs.getBoolean("face_consent", false)) askFaceConsent() else analyzeFaces()
        }
        faceClear = ui.button("Smazat index osob", R.drawable.ic_users) { closeTools(); confirmClearFaces() }
        withOcr = CheckBox(this).apply {
            text = "Při analýze přečíst i text (OCR)"; textSize = 14f
            setTextColor(ui.text); buttonTintList = android.content.res.ColorStateList.valueOf(ui.accent)
            isChecked = prefs.getBoolean("ocr", deviceProfile.ramGiB >= 4)
            minHeight = ui.dp(48)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("ocr", checked).apply() }
        }
    }

    private fun buildInterface() {
        shell = ui.column().apply { setBackgroundColor(ui.surface) }
        setContentView(shell)
        ui.safeInsets(this, shell)

        val top = ui.row().apply { setPadding(ui.dp(14), ui.dp(8), ui.dp(8), ui.dp(6)) }
        val brand = ui.column()
        brand.addView(ui.label("MediaLupa", 22f, bold = true))
        brand.addView(ui.label("Průzkumník médií", 12f, ui.muted))
        top.addWeighted(brand, 1f, -2)
        top.addView(ui.button("Přidat", R.drawable.ic_plus, true) { showAddMenu(itView = top) },
            LinearLayout.LayoutParams(-2, ui.dp(48)).apply { marginEnd = ui.dp(4) })
        top.addView(ui.iconButton("Nástroje a nastavení", R.drawable.ic_sliders_horizontal) { openTools() },
            LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)))
        shell.addView(top)

        val searchRow = ui.row().apply { setPadding(ui.dp(12), ui.dp(3), ui.dp(12), ui.dp(6)) }
        search = EditText(this).apply {
            id = R.id.search; hint = "Hledat název, obsah nebo text…"; textSize = 15f
            setTextColor(ui.text); setHintTextColor(ui.muted); setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            background = ui.shape(ui.bg, 12, ui.line)
            setPadding(ui.dp(12), ui.dp(6), ui.dp(8), ui.dp(6))
            setCompoundDrawablesRelative(ui.icon(R.drawable.ic_search, ui.muted), null, null, null)
            compoundDrawablePadding = ui.dp(10)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> hideKeyboard(); true }
        }
        searchRow.addWeighted(search, 1f, ui.dp(48))
        val clear = ui.iconButton("Vymazat hledání", R.drawable.ic_x) { search.text.clear() }
        searchRow.addView(clear, LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)))
        shell.addView(searchRow)

        val pathRow = ui.row().apply { setPadding(ui.dp(6), 0, ui.dp(8), 0) }
        pathRow.addView(ui.iconButton("Strom složek", R.drawable.ic_menu) { showFolderTree() }, LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)))
        upButton = ui.iconButton("O složku výš", R.drawable.ic_arrow_up) { navigateUp() }
        pathRow.addView(upButton, LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)))
        breadcrumbs = ui.row()
        breadcrumbScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; addView(breadcrumbs)
        }
        pathRow.addWeighted(breadcrumbScroll, 1f, ui.dp(48))
        shell.addView(pathRow)
        shell.addView(ui.divider())

        val body = ui.row().apply { gravity = Gravity.TOP; setBackgroundColor(ui.bg) }
        browserBody = body
        sidebar = ui.column().apply { setBackgroundColor(ui.surface) }
        sidebar.addView(ui.label("SLOŽKY", 12f, ui.muted, true).apply { ui.pad(this, 16) })
        sidebarBody = ui.column()
        sidebar.addView(ScrollView(this).apply { addView(sidebarBody) }, LinearLayout.LayoutParams(-1, 0, 1f))
        body.addView(sidebar, LinearLayout.LayoutParams(ui.dp(208), -1))

        val browser = ui.column()
        val heading = ui.row().apply { setPadding(ui.dp(14), ui.dp(10), ui.dp(8), ui.dp(6)) }
        val labels = ui.column()
        albumTitle = ui.label("Všechna média", 18f, bold = true).apply {
            id = R.id.albumTitle; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        }
        summary = ui.label("Načítám knihovnu…", 12f, ui.muted).apply {
            maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        labels.addView(albumTitle); labels.addView(summary)
        heading.addWeighted(labels, 1f, -2)
        folderMenuButton = ui.iconButton("Operace se složkou", R.drawable.ic_sliders_horizontal) {
            val source = selectedSource ?: return@iconButton
            folderActions(FolderEntry(source, folderPath, albumTitle.text.toString(), 0))
        }.apply { visibility = View.GONE }
        heading.addView(folderMenuButton, LinearLayout.LayoutParams(ui.dp(44), ui.dp(48)))
        heading.addView(ui.iconButton("Řazení souborů", R.drawable.ic_arrow_up_down) { showSortMenu(heading) }, LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)))
        viewToggle = ui.iconButton("Přepnout zobrazení", R.drawable.ic_grid_2x2) {
            tiled = !tiled; prefs.edit().putBoolean("tiles", tiled).apply()
            updateGridMode(); reload()
        }
        heading.addView(viewToggle, LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)))
        browser.addView(heading)
        filterBar = ui.row().apply { setPadding(ui.dp(12), 0, ui.dp(12), ui.dp(8)) }
        browser.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(filterBar) })

        val area = FrameLayout(this)
        results = GridView(this).apply {
            id = R.id.results; stretchMode = GridView.STRETCH_COLUMN_WIDTH
            horizontalSpacing = ui.dp(8); verticalSpacing = ui.dp(8)
            setPadding(ui.dp(12), ui.dp(4), ui.dp(12), ui.dp(12)); clipToPadding = false
            isVerticalScrollBarEnabled = true
            setSelector(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            setOnItemClickListener { _, _, position, _ ->
                when (browseMode) {
                    BrowseMode.TOPICS -> visibleTopics.getOrNull(position)?.let { openTopic(it) }
                    BrowseMode.PEOPLE -> visiblePeople.getOrNull(position)?.let { openPerson(it) }
                    BrowseMode.FILES -> when (val item = adapter.getItem(position)) {
                        is ExplorerEntry.Folder -> navigateFolder(item.folder)
                        is ExplorerEntry.Media -> selectFile(item.file)
                    }
                }
            }
            setOnItemLongClickListener { _, _, position, _ ->
                if (browseMode == BrowseMode.PEOPLE) visiblePeople.getOrNull(position)?.let { personActions(it) }
                else if (browseMode == BrowseMode.FILES) {
                    when (val item = adapter.getItem(position)) {
                        is ExplorerEntry.Folder -> folderActions(item.folder)
                        is ExplorerEntry.Media -> fileActions(item.file)
                    }
                }
                true
            }
        }
        area.addView(results, FrameLayout.LayoutParams(-1, -1))
        emptyState = ui.column().apply { gravity = Gravity.CENTER; ui.pad(this, 24); setBackgroundColor(ui.bg) }
        emptyState.addView(ui.image(R.drawable.ic_folder_open, ui.accent), LinearLayout.LayoutParams(ui.dp(46), ui.dp(46)))
        emptyTitle = ui.label("", 19f, bold = true).apply { gravity = Gravity.CENTER }
        emptyMessage = ui.label("", 14f, ui.muted).apply { gravity = Gravity.CENTER; setPadding(0, ui.dp(8), 0, ui.dp(16)) }
        emptyAction = ui.button("Načíst média", R.drawable.ic_plus, true) { requestMediaAccessOrScan() }
        emptyState.addView(emptyTitle); emptyState.addView(emptyMessage); emptyState.addView(emptyAction)
        area.addView(emptyState, FrameLayout.LayoutParams(-1, -1))
        browser.addView(area, LinearLayout.LayoutParams(-1, 0, 1f))
        moreResults = ui.button("Načíst další soubory", R.drawable.ic_chevron_down) { resultLimit += 250; reload() }.apply { visibility = View.GONE }
        browser.addView(moreResults, LinearLayout.LayoutParams(-1, ui.dp(48)))
        body.addWeighted(browser)
        preview = MediaPreviewPanel(this, onOpen = { selectedFile?.let { openViewer(it, it.mime.startsWith("video/")) } },
            onShare = { selectedFile?.let { shareFile(it) } },
            onPrevious = { stepPreview(-1) }, onNext = { stepPreview(1) })
        body.addView(preview, LinearLayout.LayoutParams(ui.dp(290), -1))
        shell.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        body.addOnLayoutChangeListener { _, left, _, right, _, _, _, _, _ ->
            val availableDp = (right - left) / resources.displayMetrics.density
            if (availableDp > 0f) updateResponsiveLayout(availableDp)
        }

        val statusRow = ui.row().apply { setPadding(ui.dp(14), ui.dp(4), ui.dp(8), ui.dp(4)) }
        progress = ProgressBar(this).apply { visibility = View.GONE; isIndeterminate = true }
        statusRow.addView(progress, LinearLayout.LayoutParams(ui.dp(20), ui.dp(20)).apply { marginEnd = ui.dp(8) })
        status = ui.label("Vše zůstává v telefonu", 12f, ui.muted).apply { id = R.id.status; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        statusRow.addWeighted(status, 1f, -2)
        stopButton = ui.button("Zastavit") { cancelRequested = true; showStatus("Dokončuji soubor a zastavuji…") }.apply { visibility = View.GONE }
        statusRow.addView(stopButton, LinearLayout.LayoutParams(-2, ui.dp(48)))
        shell.addView(statusRow)
        shell.addView(ui.divider())
        navBar = ui.row().apply { setPadding(ui.dp(8), ui.dp(5), ui.dp(8), ui.dp(5)) }
        shell.addView(navBar)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!restoring) { resultLimit = 250; clearPreview(); reload() }
            }
        })
        updateResponsiveLayout()
        updateGridMode()
    }

    private fun showAddMenu(itView: View) {
        PopupMenu(this, itView).apply {
            menu.add("Načíst média z telefonu").setOnMenuItemClickListener { requestMediaAccessOrScan(); true }
            menu.add("Připojit složku").setOnMenuItemClickListener { chooseFolder(); true }
            show()
        }
    }

    private fun showSortMenu(anchor: View) {
        val labels = arrayOf("Nejnovější", "Nejstarší", "Největší", "Nejmenší", "Podle názvu")
        PopupMenu(this, anchor).apply {
            labels.forEachIndexed { index, title ->
                menu.add(0, index, index, title).apply {
                    isCheckable = true; isChecked = sortOrder.ordinal == index
                    setOnMenuItemClickListener { sortOrder = SortOrder.entries[index]; reload(); true }
                }
            }
            show()
        }
    }

    private fun folderActions(folder: FolderEntry) {
        val isLinkedTree = folder.source.startsWith("TREE:")
        val root = folder.path.isEmpty()
        val options = when {
            isLinkedTree && root -> arrayOf("Odebrat složku z MediaLupy", "Znovu načíst složku")
            isLinkedTree -> arrayOf("Smazat složku z úložiště", "Znovu načíst složku")
            else -> arrayOf("Otevřít správce souborů", "Znovu načíst média")
        }
        AlertDialog.Builder(this).setTitle(folder.title).setItems(options) { _, choice ->
            when {
                isLinkedTree && root && choice == 0 -> confirmUnlinkFolder(folder)
                isLinkedTree && !root && choice == 0 -> confirmDeleteFolder(folder)
                isLinkedTree && choice == 1 -> scanChosenTree(Uri.parse(folder.source.removePrefix("TREE:")))
                !isLinkedTree && choice == 0 -> {
                    // MediaStore grants read access, not unrestricted directory deletion.
                    AlertDialog.Builder(this).setTitle("Systémová složka telefonu")
                        .setMessage("Složky z telefonu lze bezpečně mazat ve správci souborů. MediaLupa nemá právo mazat celý systémový adresář. Otevřu výběr složek systému Android.")
                        .setPositiveButton("Otevřít") { _, _ -> chooseFolder() }
                        .setNegativeButton("Zavřít", null).show()
                }
                else -> scanAll()
            }
        }.show()
    }

    private fun confirmUnlinkFolder(folder: FolderEntry) {
        AlertDialog.Builder(this).setTitle("Odebrat sledování složky?")
            .setMessage("Odstraní složku pouze z MediaLupy včetně jejího katalogu. Žádné soubory na telefonu ani v cloudu se nesmažou.")
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("Odebrat") { _, _ ->
                runWork("Odebírám složku z katalogu…") {
                    val key = folder.source.removePrefix("TREE:")
                    val old = prefs.getStringSet("folders", emptySet()).orEmpty()
                    prefs.edit().putStringSet("folders", old - key).apply()
                    database.removeSource(folder.source)
                    runOnUiThread { goTo(BrowseMode.FILES) }
                    "Složka odebrána z MediaLupy. Původní soubory zůstaly zachovány."
                }
            }.show()
    }

    private fun confirmDeleteFolder(folder: FolderEntry) {
        if (busy) return
        AlertDialog.Builder(this).setTitle("Trvale smazat složku ${folder.title}?")
            .setMessage("POZOR: Smaže skutečnou podsložku v úložišti, případně i její soubory, které nejsou v MediaLupě zobrazeny. Tuto akci nemusí jít vrátit. Android ji dovolí pouze při uděleném oprávnění k zápisu a podpoře poskytovatele.")
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("Trvale smazat") { _, _ ->
                runWork("Mažu vybranou složku…") {
                    val tree = Uri.parse(folder.source.removePrefix("TREE:"))
                    val deleted = SafFolderManager(contentResolver).deleteFolder(tree, folder.path)
                    if (!deleted) "Složku se nepodařilo smazat (úložiště operaci nepodporuje)."
                    else {
                        database.removeFolderEntries(folder.source, folder.path)
                        runOnUiThread { goTo(BrowseMode.FILES) }
                        "Složka ${folder.title} odstraněna z úložiště a katalog aktualizován."
                    }
                }
            }.show()
    }

    private fun openTools() {
        val box = ui.column().apply { ui.pad(this, 16) }
        box.addView(ui.label("Rozpoznávání a knihovna", 18f, bold = true))
        box.addView(ui.label("Analýza fotografií a videí probíhá offline.", 13f, ui.muted).apply { setPadding(0, ui.dp(6), 0, ui.dp(10)) })
        for (button in listOf(aiScan, checkDuplicates, faceScan)) {
            (button.parent as? ViewGroup)?.removeView(button); box.addView(button, LinearLayout.LayoutParams(-1, ui.dp(52)))
        }
        (withOcr.parent as? ViewGroup)?.removeView(withOcr)
        box.addView(withOcr)
        box.addView(ui.button("Zkusit znovu nečitelné soubory", R.drawable.ic_refresh_cw) {
            closeTools()
            runWork("Připravuji další pokus…") {
                val count = database.retryFailedAnalysis()
                "$count souborů připraveno. Spusť rozpoznávání obsahu nebo hledání osob."
            }
        }.apply { isEnabled = !busy }, LinearLayout.LayoutParams(-1, ui.dp(52)))
        box.addView(ui.divider())
        for (button in listOf(scanPhone, addFolder, faceClear)) {
            (button.parent as? ViewGroup)?.removeView(button); box.addView(button, LinearLayout.LayoutParams(-1, ui.dp(52)))
        }
        box.addView(ui.label("Zařízení: %.1f GB RAM · %.1f GB volno".format(java.util.Locale("cs", "CZ"),
            deviceProfile.ramGiB, deviceProfile.freeGiB), 12f, ui.muted).apply { ui.pad(this, 6) })
        toolsDialog = AlertDialog.Builder(this).setView(ScrollView(this).apply { addView(box) })
            .setNegativeButton("Zavřít", null).create()
        toolsDialog?.show()
    }
    private fun closeTools() { toolsDialog?.dismiss(); toolsDialog = null }

    private fun updateGridMode() {
        adapter.tiled = tiled; albumsAdapter.tiled = tiled
        results.numColumns = if (tiled) GridView.AUTO_FIT else 1
        results.columnWidth = ui.dp(if (resources.configuration.screenWidthDp < 380) 128 else 148)
        viewToggle.setImageDrawable(ui.icon(if (tiled) R.drawable.ic_list else R.drawable.ic_grid_2x2))
        viewToggle.contentDescription = if (tiled) "Zobrazit jako seznam" else "Zobrazit jako mřížku"
    }

    private fun updateResponsiveLayout(availableDp: Float = resources.configuration.screenWidthDp.toFloat()) {
        // The browser must remain large enough for media tiles and controls.
        // Font scaling and split-screen reduce usable width even on tablets.
        val multiplier = resources.configuration.fontScale.coerceAtLeast(1f)
        val side = availableDp >= 1120f * multiplier
        val showPreview = availableDp >= 1000f * multiplier
        val sideVisibility = if (side) View.VISIBLE else View.GONE
        val previewVisibility = if (showPreview) View.VISIBLE else View.GONE
        val sideChanged = sidebar.visibility != sideVisibility
        if (sideChanged) sidebar.visibility = sideVisibility
        if (preview.visibility != previewVisibility) preview.visibility = previewVisibility
        if (::sidebarBody.isInitialized && side && sideChanged) renderSidebar()
    }
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateResponsiveLayout(); updateGridMode(); results.requestLayout()
    }

    private fun goTo(mode: BrowseMode) {
        browseMode = mode; selectedTopic = null; selectedPerson = null; selectedSource = null; folderPath = ""
        selectedAlbumTitle = ""; resultLimit = 250; clearPreview()
        search.text.clear(); hideKeyboard(); refreshMode(); reload()
    }
    private fun openTopic(topic: TopicAlbum) {
        browseMode = BrowseMode.FILES; selectedTopic = topic.id; selectedPerson = null
        selectedSource = null; filter = FileFilter.ALL; selectedAlbumTitle = topic.title; resultLimit = 250
        search.text.clear(); clearPreview(); refreshMode(); reload()
    }
    private fun openPerson(person: PersonAlbum) {
        browseMode = BrowseMode.FILES; selectedPerson = person.id; selectedTopic = null
        selectedSource = null; filter = FileFilter.ALL; selectedAlbumTitle = person.name; resultLimit = 250
        search.text.clear(); clearPreview(); refreshMode(); reload()
    }

    private fun navigateFolder(folder: FolderEntry) {
        browseMode = BrowseMode.FILES; selectedTopic = null; selectedPerson = null
        selectedSource = folder.source; folderPath = folder.path; resultLimit = 250
        var path = folder.path
        expandedFolders.add(treeKey(folder.source, ""))
        while (path.isNotEmpty()) { expandedFolders.add(treeKey(folder.source, path)); path = FolderTree.parent(path) }
        search.text.clear(); clearPreview(); treeDialog?.dismiss(); treeDialog = null
        hideKeyboard(); refreshMode(); reload()
    }
    private fun navigateUp() {
        if (selectedTopic != null) { goTo(BrowseMode.TOPICS); return }
        if (selectedPerson != null) { goTo(BrowseMode.PEOPLE); return }
        val source = selectedSource
        if (source == null) { if (browseMode != BrowseMode.FILES) goTo(BrowseMode.FILES); return }
        if (folderPath.isEmpty()) goTo(BrowseMode.FILES)
        else navigateFolder(FolderEntry(source, FolderTree.parent(folderPath), "", 0))
    }

    private fun refreshMode() {
        if (!::navBar.isInitialized) return
        navBar.removeAllViews()
        val active = when { selectedTopic != null -> BrowseMode.TOPICS; selectedPerson != null -> BrowseMode.PEOPLE; else -> browseMode }
        listOf(Triple(BrowseMode.FILES, "Průzkumník", R.drawable.ic_folder_open),
            Triple(BrowseMode.TOPICS, "Témata", R.drawable.ic_tags),
            Triple(BrowseMode.PEOPLE, "Osoby", R.drawable.ic_users)).forEach { (mode, label, icon) ->
            val button = ui.button(label) { goTo(mode) }.apply {
                textSize = 12f; gravity = Gravity.CENTER
                setCompoundDrawablesRelative(null, ui.icon(icon, if (mode == active) ui.accent else ui.muted), null, null)
                compoundDrawablePadding = ui.dp(2)
                background = ui.touch(if (mode == active) ui.selected else ui.surface)
                setTextColor(if (mode == active) ui.accent else ui.muted); isSelected = mode == active
            }
            navBar.addWeighted(button, 1f, ui.dp(60))
        }
        filterBar.removeAllViews()
        if (browseMode == BrowseMode.FILES) {
            val options = listOf("Vše" to FileFilter.ALL, "Fotky" to FileFilter.PHOTOS, "Videa" to FileFilter.VIDEOS,
                "Duplicity" to FileFilter.DUPLICATES, "AI výsledky" to FileFilter.AI)
            options.forEach { (title, option) ->
                val button = ui.button(title) {
                    filter = option; resultLimit = 250; clearPreview(); refreshMode(); reload()
                }.apply {
                    setTextColor(if (filter == option) ui.accent else ui.muted)
                    background = ui.touch(if (filter == option) ui.selected else ui.surface, if (filter == option) ui.accent else ui.line)
                    isSelected = filter == option
                }
                filterBar.addView(button, LinearLayout.LayoutParams(-2, ui.dp(48)).apply { marginEnd = ui.dp(6) })
            }
        } else {
            val action = if (browseMode == BrowseMode.PEOPLE) ui.button("Najít osoby", R.drawable.ic_scan_face) { faceScan.performClick() }
                else ui.button("Rozpoznat obsah", R.drawable.ic_sparkles) { aiScan.performClick() }
            filterBar.addView(action)
        }
        albumTitle.text = when {
            selectedTopic != null || selectedPerson != null -> selectedAlbumTitle
            browseMode == BrowseMode.TOPICS -> "Témata podle obsahu"
            browseMode == BrowseMode.PEOPLE -> "Alba osob"
            selectedSource != null -> allFolders.firstOrNull { it.source == selectedSource && it.path == folderPath }?.title
                ?: folderPath.substringAfterLast('/').ifEmpty { "Telefon" }
            else -> "Všechna média"
        }
        rebuildBreadcrumbs()
        folderMenuButton.visibility = if (browseMode == BrowseMode.FILES && selectedSource != null &&
            selectedTopic == null && selectedPerson == null) View.VISIBLE else View.GONE
        upButton.isEnabled = selectedSource != null || selectedTopic != null || selectedPerson != null || browseMode != BrowseMode.FILES
        upButton.alpha = if (upButton.isEnabled) 1f else .35f
    }

    private fun rebuildBreadcrumbs() {
        breadcrumbs.removeAllViews()
        fun part(title: String, action: () -> Unit) {
            if (breadcrumbs.childCount > 0) breadcrumbs.addView(ui.image(R.drawable.ic_chevron_right, ui.muted),
                LinearLayout.LayoutParams(ui.dp(16), ui.dp(16)))
            breadcrumbs.addView(ui.button(title) { action() }.apply {
                textSize = 13f; maxWidth = ui.dp(190); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            }, LinearLayout.LayoutParams(-2, ui.dp(48)))
        }
        if (selectedSource != null) {
            breadcrumbs.addView(ui.iconButton("Knihovna", R.drawable.ic_hard_drive) { goTo(BrowseMode.FILES) },
                LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)))
        } else part("Knihovna") { goTo(BrowseMode.FILES) }
        if (selectedTopic != null || selectedPerson != null) {
            part(if (selectedTopic != null) "Témata" else "Osoby") { goTo(if (selectedTopic != null) BrowseMode.TOPICS else BrowseMode.PEOPLE) }
            part(selectedAlbumTitle) { }
        } else if (selectedSource != null) {
            val source = selectedSource!!
            val label = allFolders.firstOrNull { it.source == source && it.path.isEmpty() }?.title ?: "Telefon"
            part(label) { navigateFolder(FolderEntry(source, "", label, 0)) }
            val names = folderPath.split('/').filter { it.isNotEmpty() }
            names.forEachIndexed { index, name ->
                val path = names.take(index + 1).joinToString("/")
                part(name) { navigateFolder(FolderEntry(source, path, name, 0)) }
            }
        } else if (browseMode != BrowseMode.FILES) part(if (browseMode == BrowseMode.TOPICS) "Témata" else "Osoby") { }
        breadcrumbScroll.post { breadcrumbScroll.fullScroll(View.FOCUS_RIGHT) }
    }

    private fun treeKey(source: String, path: String) = source + "\n" + path
    private fun fillTree(box: LinearLayout, redraw: () -> Unit) {
        box.removeAllViews()
        box.addView(ui.button("Všechna média", R.drawable.ic_hard_drive) {
            treeDialog?.dismiss(); treeDialog = null; goTo(BrowseMode.FILES)
        }, LinearLayout.LayoutParams(-1, ui.dp(52)))
        val parents = allFolders.filter { it.path.isNotEmpty() }.map { treeKey(it.source, FolderTree.parent(it.path)) }.toHashSet()
        allFolders.forEach { folder ->
            val ancestors = folder.path.split('/').filter { it.isNotEmpty() }.dropLast(1)
            var prefix = ""
            val visible = folder.path.isEmpty() || (treeKey(folder.source, "") in expandedFolders &&
                ancestors.all { name -> prefix = if (prefix.isEmpty()) name else "$prefix/$name"; treeKey(folder.source, prefix) in expandedFolders })
            if (!visible) return@forEach
            val depth = if (folder.path.isEmpty()) 0 else folder.path.count { it == '/' } + 1
            val row = ui.row().apply {
                setPadding(ui.dp((depth * 12).coerceAtMost(72)), 0, ui.dp(6), 0)
                background = ui.touch(if (selectedSource == folder.source && folderPath == folder.path) ui.selected else ui.surface)
            }
            val hasChildren = treeKey(folder.source, folder.path) in parents
            val key = treeKey(folder.source, folder.path)
            val toggle = ui.iconButton(if (key in expandedFolders) "Sbalit ${folder.title}" else "Rozbalit ${folder.title}",
                if (key in expandedFolders) R.drawable.ic_chevron_down else R.drawable.ic_chevron_right) {
                if (!expandedFolders.add(key)) expandedFolders.remove(key); redraw()
            }.apply { visibility = if (hasChildren) View.VISIBLE else View.INVISIBLE }
            row.addView(toggle, LinearLayout.LayoutParams(ui.dp(44), ui.dp(48)))
            val title = ui.button(folder.title, if (folder.path.isEmpty()) R.drawable.ic_hard_drive else R.drawable.ic_folder) {
                navigateFolder(folder)
            }.apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }
            row.addWeighted(title, 1f, ui.dp(48))
            title.setOnLongClickListener { folderActions(folder); true }
            row.setOnLongClickListener { folderActions(folder); true }
            box.addView(row)
        }
        if (allFolders.isEmpty()) box.addView(ui.label("Nejprve načti média nebo připoj složku.", 14f, ui.muted).apply { ui.pad(this, 16) })
        box.addView(ui.button("Připojit složku", R.drawable.ic_plus) { treeDialog?.dismiss(); treeDialog = null; chooseFolder() },
            LinearLayout.LayoutParams(-1, ui.dp(52)))
    }
    private fun renderSidebar() { if (sidebar.visibility == View.VISIBLE) fillTree(sidebarBody) { renderSidebar() } }
    private fun showFolderTree() {
        val box = ui.column().apply { setBackgroundColor(ui.surface); ui.pad(this, 8) }
        val title = ui.row()
        title.addWeighted(ui.label("Složky", 20f, bold = true).apply { ui.pad(this, 12) }, 1f, -2)
        title.addView(ui.iconButton("Zavřít složky", R.drawable.ic_x) { treeDialog?.dismiss(); treeDialog = null }, LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)))
        box.addView(title)
        val tree = ui.column()
        fun redraw() { fillTree(tree) { redraw() } }
        redraw()
        box.addView(ScrollView(this).apply { addView(tree) }, LinearLayout.LayoutParams(-1, 0, 1f))
        treeDialog = Dialog(this).apply {
            setContentView(box)
            window?.setBackgroundDrawable(ui.shape(ui.surface, 16))
            show()
            window?.setLayout(minOf(ui.dp(370), (resources.displayMetrics.widthPixels * .92).toInt()),
                (resources.displayMetrics.heightPixels * .85).toInt())
        }
    }

    private fun reload() {
        if (!::search.isInitialized || background.isShutdown) return
        val request = ++reloadVersion
        val query = search.text.toString()
        val mode = browseMode; val topic = selectedTopic; val person = selectedPerson
        val source = selectedSource; val path = folderPath; val chosenFilter = filter; val chosenSort = sortOrder
        val limit = resultLimit
        background.execute {
            try {
                val stats = database.stats()
                val folders = FolderTree.build(database.folderLocations())
                val topics = if (mode == BrowseMode.TOPICS) database.topicAlbums().filter {
                    CzechSearch.normalized(it.title).contains(CzechSearch.normalized(query)) } else emptyList()
                val people = if (mode == BrowseMode.PEOPLE) database.personAlbums().filter {
                    CzechSearch.normalized(it.name).contains(CzechSearch.normalized(query)) } else emptyList()
                val files = if (mode != BrowseMode.FILES) emptyList() else database.search(query, chosenFilter, chosenSort,
                    limit, source, if (source != null) path else null, query.isNotBlank(), topic, person)
                val children = if (mode == BrowseMode.FILES && topic == null && person == null && query.isBlank()
                    && chosenFilter == FileFilter.ALL) FolderTree.children(folders, source, path) else emptyList()
                runOnUiThread {
                    if (isDestroyed || isFinishing || request != reloadVersion) return@runOnUiThread
                    allFolders = folders
                    if (expandedFolders.isEmpty()) folders.filter { it.path.isEmpty() }.forEach { expandedFolders.add(treeKey(it.source, "")) }
                    refreshMode(); renderSidebar()
                    when (mode) {
                        BrowseMode.TOPICS -> { visibleTopics = topics; albumsAdapter.showTopics(topics); results.adapter = albumsAdapter }
                        BrowseMode.PEOPLE -> { visiblePeople = people; albumsAdapter.showPeople(people); results.adapter = albumsAdapter }
                        BrowseMode.FILES -> { adapter.replace(files, children); if (results.adapter !== adapter) results.adapter = adapter }
                    }
                    val count = when (mode) { BrowseMode.TOPICS -> topics.size; BrowseMode.PEOPLE -> people.size; else -> files.size + children.size }
                    summary.text = when (mode) {
                        BrowseMode.TOPICS -> counted(topics.size, "tematické album", "tematická alba", "tematických alb")
                        BrowseMode.PEOPLE -> albumCount(people.size) + " · návrhy skupin, podržením upravíš"
                        else -> fileCount(files.size) + if (children.isNotEmpty()) " · " + folderCount(children.size) else ""
                    }
                    moreResults.visibility = if (mode == BrowseMode.FILES && files.size >= limit && limit < 10000) View.VISIBLE else View.GONE
                    emptyState.visibility = if (count == 0) View.VISIBLE else View.GONE
                    if (count == 0) {
                        val noLibrary = stats.total == 0
                        emptyTitle.text = when {
                            noLibrary -> "Tvoje média na jednom místě"
                            query.isNotBlank() -> "Nic jsme nenašli"
                            mode == BrowseMode.TOPICS -> "Témata čekají na analýzu"
                            mode == BrowseMode.PEOPLE -> "Přidej tváře ke vzpomínkám"
                            else -> "Zatím tu nic není"
                        }
                        emptyMessage.text = when {
                            noLibrary -> "Načti fotografie a videa z telefonu nebo připoj složku."
                            query.isNotBlank() -> "Zkus kratší dotaz nebo jiný filtr."
                            mode == BrowseMode.TOPICS -> "Spusť rozpoznávání obsahu v nabídce Nástroje."
                            mode == BrowseMode.PEOPLE -> "Spusť hledání osob. Jejich jména doplníš ty."
                            else -> "Změň filtr nebo přidej soubory do knihovny."
                        }
                        emptyAction.text = if (noLibrary) "Načíst média" else if (query.isNotBlank()) "Vymazat hledání" else "Otevřít nástroje"
                        emptyAction.setOnClickListener {
                            if (noLibrary) requestMediaAccessOrScan() else if (query.isNotBlank()) search.text.clear() else openTools()
                        }
                    }
                }
            } catch (e: Exception) { showStatus("Knihovnu nelze načíst: ${e.message}") }
        }
    }

    private fun selectFile(file: IndexedFile) {
        selectedFile = file; adapter.selectedKey = file.key
        if (preview.visibility == View.VISIBLE) preview.showFile(file)
        else openViewer(file)
    }
    private fun clearPreview() {
        selectedFile = null
        if (::adapter.isInitialized) adapter.selectedKey = null
        if (::preview.isInitialized) preview.clear()
    }
    private fun stepPreview(delta: Int) {
        val files = adapter.files
        val current = files.indexOfFirst { it.key == selectedFile?.key }
        files.getOrNull(current + delta)?.let { selectFile(it) }
    }
    private fun openViewer(file: IndexedFile, autoplay: Boolean = false) {
        val media = adapter.files.filter { it.mime.startsWith("image/") || it.mime.startsWith("video/") }
        if (!file.mime.startsWith("image/") && !file.mime.startsWith("video/")) { openExternal(file); return }
        // Keep Binder payload bounded, even when the user loaded a very large folder.
        val index = media.indexOfFirst { it.key == file.key }.coerceAtLeast(0)
        val from = (index - 100).coerceAtLeast(0)
        val queue = media.drop(from).take(201)
        val chosen = queue.indexOfFirst { it.key == file.key }.coerceAtLeast(0)
        startActivity(Intent(this, MediaViewerActivity::class.java).apply {
            putStringArrayListExtra("uris", ArrayList(queue.map { it.uri }))
            putStringArrayListExtra("names", ArrayList(queue.map { it.name }))
            putStringArrayListExtra("mimes", ArrayList(queue.map { it.mime }))
            putExtra("position", chosen); putExtra("autoplay", autoplay)
        })
    }
    private fun openExternal(file: IndexedFile) {
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(file.uri), file.mime); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Otevřít soubor")) } catch (e: Exception) { showStatus("Soubor nelze otevřít: ${e.message}") }
    }
    private fun shareFile(file: IndexedFile) {
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = file.mime; putExtra(Intent.EXTRA_STREAM, Uri.parse(file.uri))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = android.content.ClipData.newRawUri(file.name, Uri.parse(file.uri))
        }, "Sdílet soubor")) } catch (e: Exception) { showStatus("Soubor nelze sdílet: ${e.message}") }
    }
    private fun fileActions(file: IndexedFile) {
        val options = mutableListOf("Zobrazit náhled", "Otevřít v jiné aplikaci", "Sdílet", "Podrobnosti", "Smazat soubor")
        if (selectedPerson != null) options += "Opravit přiřazení osoby"
        AlertDialog.Builder(this).setTitle(file.name).setItems(options.toTypedArray()) { _, which ->
            when (which) {
                0 -> selectFile(file); 1 -> openExternal(file); 2 -> shareFile(file)
                3 -> AlertDialog.Builder(this).setTitle(file.name)
                    .setMessage("${file.mime}\n${FileRowAdapter.formatSize(file.size)}\n\n${file.sourceLabel}\n${file.folder}\n\n" +
                        if (file.aiLabels.isBlank()) "Obsah zatím nebyl rozpoznán." else "Rozpoznaný obsah: ${file.aiLabels}")
                    .setPositiveButton("Zavřít", null).show()
                4 -> confirmDeleteFile(file)
                5 -> excludeFile(file)
            }
        }.show()
    }

    private fun confirmDeleteFile(file: IndexedFile) {
        if (busy) return
        AlertDialog.Builder(this).setTitle("Smazat ${file.name}?")
            .setMessage("Odstraní skutečný mediální soubor z úložiště. Když poskytovatel nepoužívá koš, nemusí jít akci vrátit.")
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("Smazat soubor") { _, _ ->
                if (file.source.startsWith("TREE:")) {
                    runWork("Mažu soubor…") {
                        val removed = android.provider.DocumentsContract.deleteDocument(contentResolver, Uri.parse(file.uri))
                        if (removed) { database.removeEntry(file.key); "Soubor smazán." }
                        else "Úložiště odstranění tohoto souboru nepovolilo."
                    }
                } else if (Build.VERSION.SDK_INT >= 30) {
                    try {
                        val request = android.provider.MediaStore.createDeleteRequest(contentResolver, listOf(Uri.parse(file.uri)))
                        @Suppress("DEPRECATION")
                        startIntentSenderForResult(request.intentSender, DELETE_MEDIA_REQUEST, null, 0, 0, 0)
                    } catch (e: Exception) { showStatus("Nelze vyžádat smazání: ${e.message}") }
                } else {
                    showStatus("Android 10 vyžaduje smazání této fotky ve správci souborů.")
                }
            }.show()
    }
    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    @Deprecated("Platform navigation")
    override fun onBackPressed() {
        when {
            selectedPerson != null -> goTo(BrowseMode.PEOPLE)
            selectedTopic != null -> goTo(BrowseMode.TOPICS)
            selectedSource != null || browseMode != BrowseMode.FILES -> navigateUp()
            search.text.isNotBlank() -> search.text.clear()
            selectedFile != null -> clearPreview()
            else -> super.onBackPressed()
        }
    }

    private fun runWork(initial: String, task: () -> String) {
        if (busy) { Toast.makeText(this, "Právě běží zpracování knihovny", Toast.LENGTH_SHORT).show(); return }
        cancelRequested = false
        busy = true; setButtonsEnabled(false); showStatus(initial)
        background.execute {
            val message = try { task() } catch (e: CancellationException) {
                "Načítání pozastaveno. Uložený index zůstal zachován; pokračuj opětovným spuštěním."
            } catch (e: Exception) { "Chyba: ${e.message ?: e.javaClass.simpleName}" }
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                busy = false; aiRunning = false; faceRunning = false
                aiScan.text = "Rozpoznat obsah"; faceScan.text = "Najít osoby"
                setButtonsEnabled(true); showStatus(message); reload()
            }
        }
    }
    private fun setButtonsEnabled(enabled: Boolean) {
        scanPhone.isEnabled = enabled; addFolder.isEnabled = enabled; checkDuplicates.isEnabled = enabled
        aiScan.isEnabled = enabled || aiRunning; faceScan.isEnabled = enabled || faceRunning
        faceClear.isEnabled = enabled; withOcr.isEnabled = enabled
        progress.visibility = if (enabled) View.GONE else View.VISIBLE
        stopButton.visibility = if (!enabled) View.VISIBLE else View.GONE
    }
    private fun showStatus(message: String) {
        runOnUiThread { if (!isDestroyed && !isFinishing && ::status.isInitialized) status.text = message }
    }
    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt("mode", browseMode.ordinal); outState.putString("topic", selectedTopic)
        selectedPerson?.let { outState.putLong("person", it) }
        outState.putString("album", selectedAlbumTitle); outState.putString("source", selectedSource)
        outState.putString("path", folderPath); outState.putString("query", search.text.toString())
        outState.putInt("filter", filter.ordinal); outState.putInt("sort", sortOrder.ordinal)
        super.onSaveInstanceState(outState)
    }
    override fun onDestroy() {
        cancelRequested = true; treeDialog?.dismiss(); closeTools()
        adapter.shutdown(); albumsAdapter.shutdown(); preview.shutdown()
        background.execute { database.close() }; background.shutdown()
        super.onDestroy()
    }
    private fun askFaceConsent() {
        AlertDialog.Builder(this).setTitle("Soukromá alba osob")
            .setMessage("MediaLupa bude v telefonu lokálně rozpoznávat obličeje a ukládat jejich biometrické číselné vzory. Jména přiřadíš pouze ty. Skupiny jsou návrhy a mohou obsahovat chybné shody. Nic se neodesílá na internet a index můžeš kdykoli smazat. Používej tuto funkci jen pro fotografie, které smíš takto zpracovávat. Zapnout?")
            .setPositiveButton("Zapnout") { _, _ -> prefs.edit().putBoolean("face_consent",true).apply();analyzeFaces() }
            .setNegativeButton("Zrušit",null).show()
    }
    private fun analyzeFaces() {
        if(busy)return
        cancelRequested=false;faceRunning=true
        faceScan.text="Zastavit obličeje"
        runWork("Vyhledávám obličeje přímo v telefonu…") {
            val analyzer = FaceLibraryIndexer(this, database)
            val initial = database.pendingFaceCount()
            var done = 0
            var errors = 0
            while (!cancelRequested) {
                val (ok, bad) = analyzer.run(deviceProfile.recommendedBatch.coerceAtMost(60),
                    { showStatus("Hledání osob: $it · celkem ${done + errors}/$initial") }) { cancelRequested }
                done += ok; errors += bad
                val remaining = database.pendingFaceCount()
                showStatus("Osoby: $done hotovo · $errors chyb · zbývá $remaining")
                if (ok + bad == 0 || remaining == 0) break
            }
            "Obličeje: zpracováno $done souborů; chyby: $errors." +
                if (cancelRequested) " Hledání pozastaveno." else " Celá knihovna zpracována."
        }
    }
    private fun confirmClearFaces() {
        if(busy)return
        AlertDialog.Builder(this).setTitle("Smazat všechna alba osob?")
            .setMessage("Smaže jen lokální rozpoznané obličeje, uložená jména a jejich skupiny. Původní fotografie a videa zůstanou nedotčené.")
            .setNegativeButton("Zrušit",null)
            .setPositiveButton("Smazat index") { _, _ ->
                runWork("Mažu index obličejů…") {
                    database.removeAllFaces()
                    prefs.edit().putBoolean("face_consent",false).apply()
                    "Index obličejů a uložená jména byly odstraněny."
                }
            }.show()
    }
    private fun personActions(person:PersonAlbum) {
        AlertDialog.Builder(this).setTitle(person.name)
            .setItems(arrayOf("Přejmenovat", "Sloučit s jinou osobou", "Smazat toto album osob")) { _, which ->
                when (which) {
                    0 -> renamePerson(person)
                    1 -> mergePerson(person)
                    2 -> AlertDialog.Builder(this).setTitle("Smazat album ${person.name}?")
                        .setMessage("Odstraní jméno a uložené vzory této osoby. Fotografie a ostatní alba zůstanou zachovány.")
                        .setNegativeButton("Zrušit", null)
                        .setPositiveButton("Smazat album") { _, _ ->
                            runWork("Mažu album osoby…") {
                                database.removePerson(person.id)
                                "Album osoby a jeho uložené vzory byly smazány."
                            }
                        }.show()
                }
            }.show()
    }
    private fun renamePerson(person:PersonAlbum) {
        val field=EditText(this).apply{setSingleLine(true);setText(if(person.name.startsWith("Osoba ")) "" else person.name);hint="Jméno osoby"}
        AlertDialog.Builder(this).setTitle("Pojmenovat album")
            .setView(field).setNegativeButton("Zrušit",null)
            .setPositiveButton("Uložit") { _, _ ->
                runWork("Ukládám jméno…") {
                    database.renamePerson(person.id,field.text.toString());"Jméno alba bylo uloženo."
                }
            }.show()
    }
    private fun mergePerson(source:PersonAlbum) {
        val options=visiblePeople.filter{it.id!=source.id}
        if(options.isEmpty()){showStatus("Žádné další osoby ke sloučení.");return}
        AlertDialog.Builder(this).setTitle("Sloučit ${source.name} s…")
            .setItems(options.map{it.name}.toTypedArray()) { _, which ->
                val target=options[which]
                AlertDialog.Builder(this).setTitle("Potvrdit sloučení")
                    .setMessage("Všechny přiřazené obličeje osoby ${source.name} budou patřit do alba ${target.name}.")
                    .setNegativeButton("Zrušit",null)
                    .setPositiveButton("Sloučit") { _, _ ->
                        runWork("Slučuji osoby…"){
                            database.mergePeople(target.id,source.id);"Galerie osob byly spojeny."
                        }
                    }.show()
            }.show()
    }
    private fun excludeFile(file:IndexedFile) {
        val id=selectedPerson?:return
        AlertDialog.Builder(this).setTitle("Opravit nesprávné přiřazení")
            .setMessage("Oddělit tento soubor od aktuální osoby? Jeho obličeje budou přesunuty do nových nepojmenovaných skupin, fotografii nesmažeme.")
            .setNegativeButton("Zrušit",null)
            .setPositiveButton("Oddělit") { _, _ ->
                runWork("Opravuji přiřazení…") {
                    database.splitFileFromPerson(file.key,id);"Soubor byl oddělen od alba."
                }
            }.show()
    }

    private fun requestMediaAccessOrScan() {
        if (hasMediaAccess()) { scanAll(); return }
        val requested = if (Build.VERSION.SDK_INT >= 34) arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
        ) else if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        requestPermissions(requested, PERMISSION_REQUEST)
    }

    private fun hasMediaAccess(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            val photo = checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
            val video = checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
            val limited = Build.VERSION.SDK_INT >= 34 &&
                checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
            return photo || video || limited
        } else Manifest.permission.READ_EXTERNAL_STORAGE
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST) {
            if (hasMediaAccess()) scanAll()
            else showStatus("Přístup odmítnut. Můžeš připojit jednotlivou složku.")
        }
    }

    private fun chooseFolder() {
        // SAF also exposes some connected cloud document providers, when the provider supports trees.
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try { startActivityForResult(intent, TREE_REQUEST) }
        catch (e: Exception) { showStatus("Systémový výběr složky nelze otevřít: ${e.message}") }
    }

    @Deprecated("Platform result API is used to keep this project dependency-free")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == DELETE_MEDIA_REQUEST) {
            if (resultCode == RESULT_OK) scanAll() else showStatus("Mazání souboru bylo zrušeno.")
            return
        }
        if (requestCode != TREE_REQUEST || resultCode != RESULT_OK) return
        val tree = data?.data ?: return
        try {
            // Ask for write access explicitly. Some cloud providers only grant read access;
            // their media can still be indexed but cannot be deleted from MediaLupa.
            val granted = (data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION)) or Intent.FLAG_GRANT_READ_URI_PERMISSION
            try { contentResolver.takePersistableUriPermission(tree, granted) }
            catch (_: SecurityException) {
                contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val old = prefs.getStringSet("folders", emptySet()) ?: emptySet()
            prefs.edit().putStringSet("folders", old.toMutableSet().apply { add(tree.toString()) }).apply()
            scanChosenTree(tree)
        } catch (e: Exception) {
            showStatus("Nepodařilo se uložit přístup ke složce: ${e.message}")
        }
    }

    private fun scanChosenTree(uri: Uri) = runWork("Načítám vybranou složku…") {
        val result = indexer.scanTree(uri, ::showStatus, cancelled = { cancelRequested })
        "Načteno ${result.count} položek ze složky." +
            if (!result.complete) " Průchod není úplný. Některé složky nebyly dostupné nebo byl dosažen limit 10 000 souborů. Zkus načíst menší podsložku." else ""
    }

    private fun scanAll() = runWork("Indexuji fotografie a videa…") {
        var phoneResult = ""
        try {
            val result = indexer.scanPhone(::showStatus) { cancelRequested }
            phoneResult = "Telefon: ${result.count} položek" +
                if (!result.complete) " (část oprávnění chybí)" else ""
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            phoneResult = "Telefon nelze celý načíst: ${e.message}"
        }
        var foldersCount = 0
        var failures = 0
        for (item in (prefs.getStringSet("folders", emptySet()) ?: emptySet())) {
            try {
                val result = indexer.scanTree(Uri.parse(item), ::showStatus, cancelled = { cancelRequested })
                foldersCount += result.count
                if (!result.complete) failures++
            }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { failures++ }
        }
        "$phoneResult; složky: $foldersCount položek" +
            if (failures > 0) "; $failures průchodů složkami neúplných" else "."
    }

    private fun analyzePhoneImages() {
        if (busy) return
        val readText = withOcr.isChecked
        cancelRequested = false
        aiRunning = true
        aiScan.text = "Zastavit AI"
        runWork("Připravuji offline AI modely…") {
            val analyzer = OfflineImageAnalyzer(contentResolver, database)
            val initial = database.pendingAiCount(readText)
            var done = 0
            var errors = 0
            // Load small chunks to cap RAM use, but continue until there is nothing left.
            while (!cancelRequested) {
                val (ok, bad) = analyzer.run(deviceProfile.recommendedBatch, readText,
                    { showStatus("Rozpoznávání: $it · celkem ${done + errors}/$initial") }) { cancelRequested }
                done += ok; errors += bad
                val remaining = database.pendingAiCount(readText)
                showStatus("Rozpoznáno $done / $initial · nečitelné $errors · zbývá $remaining")
                if (ok + bad == 0 || remaining == 0) break
            }
            (if (cancelRequested) "Rozpoznávání pozastaveno." else "Rozpoznávání dokončeno.") +
                " Zpracováno $done souborů; chyb $errors; zbývá ${database.pendingAiCount(readText)}."
        }
    }

    private fun checkExactDuplicates() = runWork("Počítám SHA-256 lokálních souborů…") {
        val (hashed, failed) = DuplicateFinder(contentResolver, database).find(::showStatus) { cancelRequested }
        runOnUiThread {
            browseMode = BrowseMode.FILES; selectedTopic = null; selectedPerson = null
            selectedSource = null; folderPath = ""; filter = FileFilter.DUPLICATES
            refreshMode()
        }
        (if (cancelRequested) "Kontrola pozastavena. " else "") +
            "Nově zkontrolováno $hashed souborů; nečitelných: $failed. Uložené kontrolní součty se použijí příště."
    }


}
