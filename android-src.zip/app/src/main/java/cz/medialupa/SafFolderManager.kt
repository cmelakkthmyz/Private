package cz.medialupa

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract

/** Folder operations are limited to the tree granted by the user in Android's system picker. */
class SafFolderManager(private val resolver: ContentResolver) {
    fun deleteFolder(tree: Uri, relativePath: String): Boolean {
        val path = FolderTree.normalize(relativePath)
        require(path.isNotEmpty() && path.split('/').none { it == "." || it == ".." }) {
            "Nelze smazat kořen bez výběru konkrétní podsložky"
        }
        var parentId = DocumentsContract.getTreeDocumentId(tree)
        val parts = path.split('/')
        for ((index, segment) in parts.withIndex()) {
            val childUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_FLAGS
            )
            val next = resolver.query(childUri, projection, null, null, null)?.use { cursor ->
                var found: Pair<String, Int>? = null
                while (cursor.moveToNext()) {
                    if (cursor.getString(1) == segment &&
                        cursor.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                        found = cursor.getString(0) to cursor.getInt(3)
                        break
                    }
                }
                found
            } ?: return false
            parentId = next.first
            if (index == parts.lastIndex) {
                require(next.second and DocumentsContract.Document.FLAG_SUPPORTS_DELETE != 0) {
                    "Poskytovatel úložiště nepovoluje odstranění této složky"
                }
            }
        }
        return DocumentsContract.deleteDocument(resolver,
            DocumentsContract.buildDocumentUriUsingTree(tree, parentId))
    }
}
