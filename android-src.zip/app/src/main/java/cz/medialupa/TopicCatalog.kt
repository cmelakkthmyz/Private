package cz.medialupa

/** Tematicke kategorie jsou pouze index: stejna fotka muze byt ve vice albech. */
object TopicCatalog {
    data class Topic(val id: String, val title: String, val words: List<String>)
    val all = listOf(
        Topic("animals", "🐾 Zvířata", listOf("animal", "dog", "cat", "bird", "fish", "horse", "wildlife", "pet", "insect", "butterfly", "rabbit", "sheep", "cow", "puppy", "kitten", "safari", "reptile")),
        Topic("nature", "🌲 Příroda a krajina", listOf("nature", "forest", "tree", "mountain", "sky", "lake", "river", "beach", "sea", "ocean", "flower", "plant", "rock", "snow", "waterfall", "sunset", "landscape", "garden", "grass")),
        Topic("people", "👥 Lidé a portréty", listOf("person", "people", "face", "human", "baby", "child", "selfie", "portrait", "smile", "family", "wedding", "crowd")),
        Topic("transport", "🚗 Vozidla a doprava", listOf("car", "vehicle", "bus", "train", "plane", "airplane", "bicycle", "motorcycle", "boat", "truck", "ship", "railway", "tractor")),
        Topic("food", "🍎 Jídlo a nápoje", listOf("food", "meal", "dinner", "drink", "fruit", "vegetable", "pizza", "cake", "coffee", "bread", "breakfast", "dessert", "restaurant")),
        Topic("buildings", "🏡 Města a budovy", listOf("house", "building", "city", "urban", "street", "road", "bridge", "architecture", "home", "church", "monument", "castle", "interior")),
        Topic("documents", "📄 Dokumenty a obrazovky", listOf("document", "receipt", "text", "book", "paper", "screen", "computer", "phone", "invoice", "letter", "screenshot")),
        Topic("sport", "⚽ Sport a aktivity", listOf("sport", "ball", "soccer", "tennis", "cycling", "swimming", "hiking", "running", "fitness", "ski", "exercise")),
        Topic("objects", "🧸 Věci a předměty", listOf("toy", "furniture", "clothing", "shoes", "tool", "machine", "electronics", "instrument", "clock", "art", "jewelry"))
    )
}
