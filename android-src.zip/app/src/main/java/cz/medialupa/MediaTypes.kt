package cz.medialupa

import java.util.Locale

/** Only photographic images and playable video, never arbitrary documents or source files. */
object MediaTypes {
    private val images = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif", "tif", "tiff", "dng", "nef", "cr2", "arw", "rw2")
    private val videos = setOf("mp4", "m4v", "mov", "mkv", "webm", "avi", "wmv", "3gp", "3g2", "mts", "m2ts", "mpg", "mpeg", "ts")
    private val imageMime = setOf("image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif",
        "image/bmp", "image/x-ms-bmp", "image/heic", "image/heif", "image/avif", "image/tiff",
        "image/x-adobe-dng", "image/x-canon-cr2", "image/x-nikon-nef", "image/x-sony-arw", "image/x-panasonic-rw2")
    private val videoMime = setOf("video/mp4", "video/quicktime", "video/x-matroska", "video/webm", "video/x-msvideo",
        "video/x-ms-wmv", "video/3gpp", "video/3gpp2", "video/mpeg", "video/mp2t", "video/avi")

    fun supported(name: String, mime: String): Boolean {
        val type = mime.substringBefore(';').trim().lowercase(Locale.ROOT)
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val image = type in imageMime || (type in setOf("", "application/octet-stream") && ext in images)
        val video = type in videoMime || (type in setOf("", "application/octet-stream") && ext in videos)
        // A provider can supply a valid MIME type without a file extension. If it has an extension,
        // reject contradictory names such as script.py masquerading as image/jpeg.
        return when {
            ext.isEmpty() -> image || video
            image -> ext in images
            video -> ext in videos
            else -> false
        }
    }

    fun normalizedMime(name: String, mime: String): String {
        val type = mime.substringBefore(';').trim().lowercase(Locale.ROOT)
        if (type in imageMime || type in videoMime) return type
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "bmp" -> "image/bmp"
            "heic" -> "image/heic"
            "heif" -> "image/heif"
            "avif" -> "image/avif"
            "tif", "tiff" -> "image/tiff"
            "dng" -> "image/x-adobe-dng"
            "nef" -> "image/x-nikon-nef"
            "cr2" -> "image/x-canon-cr2"
            "arw" -> "image/x-sony-arw"
            "rw2" -> "image/x-panasonic-rw2"
            "mp4", "m4v" -> "video/mp4"
            "mov" -> "video/quicktime"
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            "avi" -> "video/x-msvideo"
            "wmv" -> "video/x-ms-wmv"
            "3gp" -> "video/3gpp"
            "3g2" -> "video/3gpp2"
            "mts", "m2ts", "ts" -> "video/mp2t"
            "mpg", "mpeg" -> "video/mpeg"
            else -> type
        }
    }
}
