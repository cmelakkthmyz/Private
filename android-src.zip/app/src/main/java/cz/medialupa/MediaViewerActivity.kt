package cz.medialupa

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.concurrent.Executors

/** Fullscreen local viewer. Image transformations only affect this preview, never file bytes. */
class MediaViewerActivity : Activity() {
    private lateinit var ui: Ui
    private lateinit var image: ZoomImageView
    private lateinit var video: VideoView
    private lateinit var loading: ProgressBar
    private lateinit var message: TextView
    private lateinit var name: TextView
    private lateinit var detail: TextView
    private lateinit var imageControls: LinearLayout
    private lateinit var filmstrip: LinearLayout
    private lateinit var filmLoader: ThumbnailLoader
    private lateinit var videoControls: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var elapsed: TextView
    private lateinit var play: ImageButton
    private lateinit var previous: ImageButton
    private lateinit var next: ImageButton
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var uris = arrayListOf<String>()
    private var names = arrayListOf<String>()
    private var mimes = arrayListOf<String>()
    private var position = 0
    private var generation = 0
    private var closed = false
    private var savedVideoPosition = 0
    private var videoReady = false
    private var seeking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = Ui(this)
        uris = intent.getStringArrayListExtra("uris") ?: arrayListOf()
        names = intent.getStringArrayListExtra("names") ?: arrayListOf()
        mimes = intent.getStringArrayListExtra("mimes") ?: arrayListOf()
        if (uris.isEmpty() || uris.size != names.size || uris.size != mimes.size) { finish(); return }
        position = (savedInstanceState?.getInt("position") ?: intent.getIntExtra("position", 0)).coerceIn(0, uris.lastIndex)
        savedVideoPosition = savedInstanceState?.getInt("videoPosition") ?: 0
        val root = ui.column().apply { setBackgroundColor(ui.viewer) }
        setContentView(root); ui.safeInsets(this, root, true)
        fun icon(label: String, resource: Int, action: () -> Unit) = ui.iconButton(label, resource, action).apply {
            background = ui.touch(ui.viewer); setImageDrawable(ui.icon(resource, Color.WHITE))
        }
        val top = ui.row().apply { setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(6)) }
        top.addView(icon("Zpět do knihovny", R.drawable.ic_chevron_left) { finish() }, LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)))
        val title = ui.column()
        name = ui.label("", 15f, Color.WHITE, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }
        detail = ui.label("", 12f, 0xFFB2C1D2.toInt())
        title.addView(name); title.addView(detail); top.addWeighted(title, 1f, -2)
        top.addView(icon("Sdílet soubor", R.drawable.ic_share_2) { shareCurrent() }, LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)))
        root.addView(top)
        val stage = FrameLayout(this).apply { setBackgroundColor(ui.viewer) }
        image = ZoomImageView(this)
        video = VideoView(this)
        stage.addView(image, FrameLayout.LayoutParams(-1, -1))
        stage.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        loading = ProgressBar(this)
        stage.addView(loading, FrameLayout.LayoutParams(ui.dp(40), ui.dp(40), Gravity.CENTER))
        message = ui.label("", 15f, Color.WHITE).apply { gravity = Gravity.CENTER; ui.pad(this, 24) }
        stage.addView(message, FrameLayout.LayoutParams(-1, -1))
        root.addView(stage, LinearLayout.LayoutParams(-1, 0, 1f))

        videoControls = ui.column().apply { setPadding(ui.dp(12), 0, ui.dp(12), 0) }
        elapsed = ui.label("0:00 / 0:00", 12f, 0xFFBAC7D6.toInt())
        seek = SeekBar(this).apply { minHeight = ui.dp(48); progressTintList = android.content.res.ColorStateList.valueOf(0xFF8AB5FF.toInt()) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(bar: SeekBar) { seeking = true }
            override fun onStopTrackingTouch(bar: SeekBar) { if (videoReady) video.seekTo(bar.progress); seeking = false }
            override fun onProgressChanged(bar: SeekBar, value: Int, fromUser: Boolean) {}
        })
        videoControls.addView(elapsed); videoControls.addView(seek)
        root.addView(videoControls)

        filmLoader = ThumbnailLoader(this)
        filmstrip = ui.row().apply { setPadding(ui.dp(8), ui.dp(6), ui.dp(8), ui.dp(6)) }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(filmstrip)
            visibility = if (uris.size > 1) View.VISIBLE else View.GONE
        }, LinearLayout.LayoutParams(-1, ui.dp(76)))

        imageControls = ui.row().apply { setPadding(ui.dp(8), ui.dp(6), ui.dp(8), ui.dp(8)) }
        previous = icon("Předchozí soubor", R.drawable.ic_chevron_left) { move(-1) }
        next = icon("Další soubor", R.drawable.ic_chevron_right) { move(1) }
        play = icon("Přehrát video", R.drawable.ic_play) {
            if (videoReady) { if (video.isPlaying) video.pause() else video.start(); updatePlayButton() }
        }
        imageControls.addWeighted(previous, 1f, ui.dp(48))
        imageControls.addWeighted(icon("Oddálit", R.drawable.ic_zoom_out) { image.zoomBy(.75f) }.apply { tag = "imageOnly" }, 1f, ui.dp(48))
        imageControls.addWeighted(icon("Přizpůsobit oknu", R.drawable.ic_maximize) { image.fit() }.apply { tag = "imageOnly" }, 1f, ui.dp(48))
        imageControls.addWeighted(icon("Přiblížit", R.drawable.ic_zoom_in) { image.zoomBy(1.4f) }.apply { tag = "imageOnly" }, 1f, ui.dp(48))
        imageControls.addWeighted(icon("Otočit náhled", R.drawable.ic_rotate_cw) { image.rotatePreview() }.apply { tag = "imageOnly" }, 1f, ui.dp(48))
        imageControls.addWeighted(play, 1f, ui.dp(48))
        imageControls.addWeighted(next, 1f, ui.dp(48))
        root.addView(imageControls)
        showCurrent(savedInstanceState == null && intent.getBooleanExtra("autoplay", false))
        handler.post(ticker)
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (closed) return
            if (::video.isInitialized && videoReady && ::seek.isInitialized) {
                if (!seeking) seek.progress = video.currentPosition
                elapsed.text = "${time(video.currentPosition)} / ${time(video.duration)}"
                updatePlayButton()
            }
            handler.postDelayed(this, 500)
        }
    }
    private fun time(ms: Int): String { val seconds = ms.coerceAtLeast(0) / 1000; return "%d:%02d".format(seconds / 60, seconds % 60) }
    private fun updatePlayButton() {
        val playing = videoReady && video.isPlaying
        play.contentDescription = if (playing) "Pozastavit video" else "Přehrát video"
        play.setImageDrawable(ui.icon(if (playing) R.drawable.ic_pause else R.drawable.ic_play, Color.WHITE))
    }
    private fun move(delta: Int) {
        val target = position + delta
        if (target !in uris.indices) return
        position = target; savedVideoPosition = 0; showCurrent(false)
    }
    private fun showCurrent(autoplay: Boolean) {
        val request = ++generation
        val uri = Uri.parse(uris[position])
        val mime = mimes[position]
        val isVideo = mime.startsWith("video/")
        updateFilmstrip()
        name.text = names[position]
        detail.text = "${position + 1} / ${uris.size} · " + if (isVideo) "Video" else "Fotografie"
        previous.isEnabled = position > 0; next.isEnabled = position < uris.lastIndex
        previous.alpha = if (previous.isEnabled) 1f else .3f
        next.alpha = if (next.isEnabled) 1f else .3f
        video.stopPlayback(); videoReady = false
        image.setImageDrawable(null); message.visibility = View.GONE; loading.visibility = View.VISIBLE
        image.visibility = if (isVideo) View.GONE else View.VISIBLE
        video.visibility = if (isVideo) View.VISIBLE else View.GONE
        videoControls.visibility = if (isVideo) View.VISIBLE else View.GONE
        for (i in 0 until imageControls.childCount) {
            val child = imageControls.getChildAt(i)
            if (child.tag == "imageOnly") child.visibility = if (isVideo) View.GONE else View.VISIBLE
        }
        play.visibility = if (isVideo) View.VISIBLE else View.GONE; play.isEnabled = false
        if (isVideo) {
            seek.progress = 0; elapsed.text = "Načítám video…"
            video.setOnPreparedListener {
                if (request == generation) {
                    videoReady = true; loading.visibility = View.GONE; play.isEnabled = true
                    seek.max = video.duration.coerceAtLeast(1)
                    video.seekTo(savedVideoPosition.coerceAtLeast(1))
                    if (autoplay) video.start()
                    updatePlayButton()
                }
            }
            video.setOnCompletionListener { updatePlayButton() }
            video.setOnErrorListener { _, _, _ ->
                if (request == generation) showError("Toto video nelze přehrát. Zkus ho otevřít v jiné aplikaci.")
                true
            }
            try { video.setVideoURI(uri) } catch (_: Exception) { showError("Video není dostupné.") }
        } else worker.execute {
            val bitmap = try { ThumbnailLoader.preview(applicationContext, uri, mime, 2560) }
                catch (_: Exception) { null } catch (_: OutOfMemoryError) { null }
            handler.post {
                if (closed || request != generation) return@post
                loading.visibility = View.GONE
                if (bitmap != null) {
                    image.showBitmap(bitmap)
                    detail.text = "${position + 1} / ${uris.size} · ${bitmap.width} × ${bitmap.height} px (náhled)"
                } else showError("Fotografii se nepodařilo načíst. Ověř přístup k souboru.")
            }
        }
    }
    private fun updateFilmstrip() {
        filmstrip.removeAllViews()
        val first = (position - 3).coerceIn(0, (uris.size - 7).coerceAtLeast(0))
        for (index in first until minOf(first + 7, uris.size)) {
            val frame = FrameLayout(this).apply {
                background = ui.shape(if (index == position) ui.accent else 0xFF2A3747.toInt(), 8)
                setPadding(ui.dp(2), ui.dp(2), ui.dp(2), ui.dp(2))
                contentDescription = names[index]; isFocusable = true
                setOnClickListener { position = index; savedVideoPosition = 0; showCurrent(false) }
            }
            frame.addView(ui.image(if (mimes[index].startsWith("video/")) R.drawable.ic_video else R.drawable.ic_image, Color.LTGRAY),
                FrameLayout.LayoutParams(ui.dp(24), ui.dp(24), Gravity.CENTER))
            val thumbnail = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            frame.addView(thumbnail, FrameLayout.LayoutParams(-1, -1))
            filmLoader.load(thumbnail, uris[index])
            filmstrip.addView(frame, LinearLayout.LayoutParams(ui.dp(72), ui.dp(60)).apply { marginEnd = ui.dp(6) })
        }
    }
    private fun showError(text: String) { loading.visibility = View.GONE; message.text = text; message.visibility = View.VISIBLE }
    private fun shareCurrent() {
        val uri = Uri.parse(uris[position])
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = mimes[position]; putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri(names[position], uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Sdílet soubor")) } catch (_: Exception) { Toast.makeText(this, "Sdílení není dostupné", Toast.LENGTH_SHORT).show() }
    }
    override fun onPause() { if (::video.isInitialized) { savedVideoPosition = video.currentPosition; video.pause() }; super.onPause() }
    override fun onSaveInstanceState(state: Bundle) {
        state.putInt("position", position); state.putInt("videoPosition", if (::video.isInitialized) video.currentPosition else 0)
        super.onSaveInstanceState(state)
    }
    override fun onDestroy() {
        closed = true; generation++
        if (::video.isInitialized) video.stopPlayback()
        if (::filmLoader.isInitialized) filmLoader.shutdown()
        worker.shutdownNow(); handler.removeCallbacksAndMessages(null); super.onDestroy()
    }
}
