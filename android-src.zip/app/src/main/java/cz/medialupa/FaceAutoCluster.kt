package cz.medialupa

import kotlin.math.sqrt

/** Face groups based on normalized face embeddings; does not assign names or upload media. */
data class FaceClusterGroup(
    val id: Long,
    val name: String,
    val center: FloatArray,
    val examples: List<FloatArray>,
    /** Image + frame IDs in which this group was observed; two groups sharing a frame
     * cannot be the same face, and are never merged automatically. */
    val frames: Set<String>
)

object FaceAutoCluster {
    private fun cosine(a: FloatArray, b: FloatArray): Float {
        if (a.isEmpty() || a.size != b.size) return -1f
        var dot = 0.0; var aa = 0.0; var bb = 0.0
        for (i in a.indices) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i] }
        val d = sqrt(aa * bb)
        return if (d < 1e-12) -1f else (dot / d).toFloat()
    }

    /** Conservative complete-group merging, not single-link chaining.
     * Thresholds are heuristics for current MobileFaceNet and should be calibrated on real photos.
     */
    fun suggestMerge(groups: List<FaceClusterGroup>, limit: Int = 1000): List<Pair<Long, Long>> {
        if (groups.size < 2) return emptyList()
        data class Combined(val primaryId: Long, var name: String, var center: FloatArray,
            val samples: MutableList<FloatArray>, val frames: MutableSet<String>, var size: Int)
        val state = groups.take(limit).map { g -> Combined(g.id, g.name,
            g.center, g.examples.take(8).toMutableList(), g.frames.toMutableSet(), 1) }.toMutableList()
        val merges = mutableListOf<Pair<Long, Long>>()
        while (true) {
            var bestI = -1; var bestJ = -1; var bestSimilarity = -1f
            for (i in state.indices) for (j in i + 1 until state.size) {
                val a = state[i]; val b = state[j]
                if (a.frames.any { it in b.frames }) continue
                if (a.name.isNotBlank() && b.name.isNotBlank() &&
                    !a.name.equals(b.name, ignoreCase = true)) continue
                val centroid = cosine(a.center, b.center)
                val threshold = if (a.size == 1 && b.size == 1) .77f else .73f
                if (centroid < threshold) continue
                // Reject candidates supported only by a weak centroid association.
                val exemplars = a.samples.maxOfOrNull { x -> b.samples.maxOfOrNull { y -> cosine(x, y) } ?: -1f } ?: -1f
                if (exemplars < .78f) continue
                val score = centroid + exemplars * .08f
                if (score > bestSimilarity) { bestSimilarity = score; bestI = i; bestJ = j }
            }
            if (bestI < 0) break
            val a = state[bestI]; val b = state[bestJ]
            // Prefer the named group; otherwise preserve the oldest stable album ID.
            val target = if (a.name.isNotBlank() && b.name.isBlank()) a else if (b.name.isNotBlank() && a.name.isBlank()) b
                else if (a.primaryId <= b.primaryId) a else b
            val source = if (target === a) b else a
            merges.add(target.primaryId to source.primaryId)
            // Parent ID is used only as a representative; group-level comparisons remain conservative.
            val nx = FloatArray(target.center.size) { k ->
                (target.center[k] * target.size + source.center[k] * source.size) / (target.size + source.size)
            }
            val norm = sqrt(nx.sumOf { (it * it).toDouble() }).toFloat()
            target.center = if (norm > 1e-9f) FloatArray(nx.size) { nx[it] / norm } else nx
            target.size += source.size
            target.frames.addAll(source.frames)
            target.samples.addAll(source.samples)
            if (target.samples.size > 12) {
                // Keep several views; use earliest and latest rather than every near-duplicate.
                val first = target.samples.take(6); val last = target.samples.takeLast(6)
                target.samples.clear(); target.samples.addAll(first + last)
            }
            if (target.name.isBlank()) target.name = source.name
            state.remove(source)
        }
        return merges
    }
}
