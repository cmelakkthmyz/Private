package cz.medialupa

import android.content.Context
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.ImageView
import kotlin.math.abs

/** Bounded bitmap preview with pinch, double-tap, pan and view-only rotation. */
// The app uses framework Activities and framework Material themes, not AppCompat.
@SuppressLint("AppCompatCustomView")
class ZoomImageView(context: Context) : ImageView(context) {
    private var zoom = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var angle = 0
    private var lastX = 0f
    private var lastY = 0f
    private val transform = Matrix()
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            changeZoom(detector.scaleFactor, detector.focusX, detector.focusY); return true
        }
    })
    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (zoom > 1.05f) fit() else changeZoom(2.5f, e.x, e.y)
            return true
        }
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { performClick(); return true }
    })
    init {
        scaleType = ScaleType.MATRIX
        contentDescription = "Náhled fotografie. Přiblížení dvěma prsty nebo dvojitým klepnutím."
    }
    fun showBitmap(bitmap: Bitmap) { setImageBitmap(bitmap); angle = 0; fit() }
    fun fit() { zoom = 1f; offsetX = 0f; offsetY = 0f; updateMatrix() }
    fun zoomBy(factor: Float) = changeZoom(factor, width / 2f, height / 2f)
    fun rotatePreview() { angle = (angle + 90) % 360; fit() }
    private fun changeZoom(factor: Float, focusX: Float, focusY: Float) {
        val previous = zoom
        zoom = (zoom * factor).coerceIn(1f, 8f)
        val ratio = zoom / previous
        offsetX = offsetX * ratio + (focusX - width / 2f) * (1 - ratio)
        offsetY = offsetY * ratio + (focusY - height / 2f) * (1 - ratio)
        updateMatrix()
    }
    private fun updateMatrix() {
        val image = drawable ?: return
        if (width <= 0 || height <= 0 || image.intrinsicWidth <= 0 || image.intrinsicHeight <= 0) return
        val imageWidth = image.intrinsicWidth.toFloat()
        val imageHeight = image.intrinsicHeight.toFloat()
        val rotatedWidth = if (angle % 180 == 0) imageWidth else imageHeight
        val rotatedHeight = if (angle % 180 == 0) imageHeight else imageWidth
        val scale = minOf(width / rotatedWidth, height / rotatedHeight) * zoom
        val maxX = ((rotatedWidth * scale - width) / 2).coerceAtLeast(0f)
        val maxY = ((rotatedHeight * scale - height) / 2).coerceAtLeast(0f)
        offsetX = offsetX.coerceIn(-maxX, maxX); offsetY = offsetY.coerceIn(-maxY, maxY)
        transform.reset()
        transform.postTranslate(-imageWidth / 2, -imageHeight / 2)
        transform.postRotate(angle.toFloat())
        transform.postScale(scale, scale)
        transform.postTranslate(width / 2f + offsetX, height / 2f + offsetY)
        imageMatrix = transform
    }
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) { super.onSizeChanged(w, h, oldw, oldh); updateMatrix() }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        scaleDetector.onTouchEvent(event); gestures.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = event.x; lastY = event.y }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1 && !scaleDetector.isInProgress && zoom > 1f) {
                    offsetX += event.x - lastX; offsetY += event.y - lastY; updateMatrix()
                }
                lastX = event.x; lastY = event.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val next = if (event.actionIndex == 0) 1 else 0
                if (next < event.pointerCount) { lastX = event.getX(next); lastY = event.getY(next) }
            }
        }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
