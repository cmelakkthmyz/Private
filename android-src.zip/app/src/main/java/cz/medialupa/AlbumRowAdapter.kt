package cz.medialupa

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.widget.*

class AlbumRowAdapter(private val context: Context) : BaseAdapter() {
    private val ui = Ui(context)
    private val loader = ThumbnailLoader(context)
    private var albums: List<Triple<String, Int, String?>> = emptyList()
    var tiled = true
    var people = false
    fun showTopics(data: List<TopicAlbum>) { people = false; albums = data.map { Triple(it.title, it.count, it.coverUri) }; notifyDataSetChanged() }
    fun showPeople(data: List<PersonAlbum>) { people = true; albums = data.map { Triple(it.name, it.count, it.coverUri) }; notifyDataSetChanged() }
    override fun getCount() = albums.size
    override fun getItem(position: Int) = albums[position]
    override fun getItemId(position: Int) = position.toLong()
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val (title, count, uri) = albums[position]
        val root = if (tiled) ui.column() else ui.row()
        root.background = ui.touch(ui.surface, ui.line); ui.pad(root, 8)
        val frame = FrameLayout(context).apply { background = ui.shape(ui.bg, 8); clipToOutline = true }
        frame.addView(ui.image(if (people) R.drawable.ic_users else R.drawable.ic_tags),
            FrameLayout.LayoutParams(ui.dp(32), ui.dp(32), Gravity.CENTER))
        val cover = ImageView(context).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        frame.addView(cover, FrameLayout.LayoutParams(-1, -1)); loader.load(cover, uri)
        val texts = ui.column()
        texts.addView(ui.label(title, 14f, bold = true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        texts.addView(ui.label(fileCount(count), 12f, ui.muted))
        if (tiled) {
            root.addView(frame, LinearLayout.LayoutParams(-1, ui.dp(116)))
            root.addView(texts, LinearLayout.LayoutParams(-1, ui.dp(52)).apply { topMargin = ui.dp(5) })
        } else {
            root.addView(frame, LinearLayout.LayoutParams(ui.dp(60), ui.dp(60)))
            root.addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(12) })
        }
        return root
    }
    fun shutdown() = loader.shutdown()
}
