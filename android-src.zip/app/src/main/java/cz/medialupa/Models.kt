package cz.medialupa

data class IndexedFile(
    val key: String, val uri: String, val name: String, val mime: String,
    val size: Long, val modified: Long, val folder: String,
    val source: String, val sourceLabel: String, val sha256: String? = null,
    val aiLabels: String = "", val analyzedVersion: Int = 0
)

enum class FileFilter { ALL, PHOTOS, VIDEOS, DOCUMENTS, DUPLICATES, AI }
enum class SortOrder { NEWEST, OLDEST, LARGEST, SMALLEST, NAME }

data class IndexStats(val photos: Int, val videos: Int, val others: Int, val analyzed: Int) {
    val total: Int get() = photos + videos + others
}


data class TopicAlbum(val id: String, val title: String, val count: Int, val coverUri: String?)
data class PersonAlbum(val id: Long, val name: String, val count: Int, val coverUri: String?)
data class FaceSample(val embedding: FloatArray, val frameTimeUs: Long, val centerX: Float, val centerY: Float)
