package cz.medialupa

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.*

class Ui(val context: Context) {
    val dark = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
    val bg = Color.parseColor(if (dark) "#111820" else "#F5F7FB")
    val surface = Color.parseColor(if (dark) "#1B2531" else "#FFFFFF")
    val text = Color.parseColor(if (dark) "#EDF3FA" else "#172B44")
    val muted = Color.parseColor(if (dark) "#B0BECE" else "#5C6E83")
    val line = Color.parseColor(if (dark) "#334353" else "#E0E7F0")
    val accent = Color.parseColor(if (dark) "#8AB5FF" else "#2161D6")
    val selected = Color.parseColor(if (dark) "#263D5D" else "#EAF1FF")
    val folder = Color.parseColor(if (dark) "#EDBE66" else "#BB8328")
    val viewer = Color.parseColor("#101823")
    fun dp(n: Int) = (n * context.resources.displayMetrics.density + .5f).toInt()
    fun column() = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    fun row() = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    fun label(value: String, size: Float = 14f, color: Int = text, bold: Boolean = false) = TextView(context).apply {
        this.text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        includeFontPadding = true
    }
    fun shape(color: Int, radius: Int = 12, border: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        border?.let { setStroke(dp(1), it) }
    }
    fun touch(color: Int = surface, border: Int? = null) = RippleDrawable(
        ColorStateList.valueOf(if (dark) 0x30FFFFFF else 0x16000000), shape(color, 10, border), null
    )
    fun icon(id: Int, tint: Int = text) = context.getDrawable(id)!!.mutate().apply {
        setTint(tint); setBounds(0, 0, dp(20), dp(20))
    }
    fun button(title: String, iconId: Int? = null, primary: Boolean = false, onClick: () -> Unit): Button =
        Button(context).apply {
            text = title; isAllCaps = false; textSize = 14f; minHeight = dp(48)
            minimumHeight = dp(48); minWidth = 0; minimumWidth = 0; gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5)); setTextColor(if (primary) Color.WHITE else this@Ui.text)
            background = touch(if (primary) Color.rgb(33,97,214) else surface)
            iconId?.let { setCompoundDrawablesRelative(icon(it, if (primary) Color.WHITE else accent), null, null, null); compoundDrawablePadding = dp(8) }
            setOnClickListener { onClick() }
        }
    fun iconButton(label: String, iconId: Int, onClick: () -> Unit) = ImageButton(context).apply {
        contentDescription = label; tooltipText = label
        setImageDrawable(icon(iconId)); scaleType = ImageView.ScaleType.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12)); background = touch()
        setOnClickListener { onClick() }
    }
    fun image(iconId: Int, color: Int = muted) = ImageView(context).apply { setImageDrawable(icon(iconId, color)) }
    fun divider() = View(context).apply { setBackgroundColor(line); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) }
    fun pad(view: View, all: Int) { view.setPadding(dp(all), dp(all), dp(all), dp(all)) }
    fun safeInsets(activity: Activity, root: View, viewerMode: Boolean = false) {
        if (Build.VERSION.SDK_INT >= 30) activity.window.setDecorFitsSystemWindows(false)
        activity.window.statusBarColor = if (viewerMode) viewer else surface
        activity.window.navigationBarColor = if (viewerMode) viewer else surface
        activity.window.decorView.systemUiVisibility =
            if (!dark && !viewerMode) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                v.setPadding(i.left, i.top, i.right, i.bottom)
            } else v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            insets
        }
        root.requestApplyInsets()
    }
}

fun LinearLayout.addWeighted(view: View, weight: Float = 1f, height: Int = -1) {
    addView(view, LinearLayout.LayoutParams(0, height, weight))
}

fun counted(number: Int, one: String, few: String, many: String): String =
    "$number " + when (number) { 1 -> one; 2, 3, 4 -> few; else -> many }
fun fileCount(number: Int) = counted(number, "soubor", "soubory", "souborů")
fun folderCount(number: Int) = counted(number, "složka", "složky", "složek")
fun albumCount(number: Int) = counted(number, "album", "alba", "alb")
