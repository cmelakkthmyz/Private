package cz.medialupa

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import java.util.ArrayDeque
import java.util.concurrent.CancellationException

data class ScanOutcome(val count: Int, val complete: Boolean)

/** Indexes metadata only; it never moves, deletes, copies or uploads files. */
class ContentIndexer(
    private val context: Context,
    private val db: IndexDatabase,
    // Injected for permission-specific regression tests; production always checks actual grants.
    private val hasFullCollectionAccess: (String) -> Boolean = { source ->
        val permission = when {
            Build.VERSION.SDK_INT < 33 -> Manifest.permission.READ_EXTERNAL_STORAGE
            source == "PHONE_IMAGES" -> Manifest.permission.READ_MEDIA_IMAGES
            else -> Manifest.permission.READ_MEDIA_VIDEO
        }
        context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
    }
) {
    private fun checkCancelled(cancelled: () -> Boolean) {
        if (cancelled()) throw CancellationException("Načítání pozastaveno. Další spuštění obnoví průchod.")
    }

    fun scanPhone(onProgress: (String) -> Unit, cancelled: () -> Boolean = { false }): ScanOutcome {
        var count = 0
        var complete = true
        // Android can grant video and photo access independently. One denied collection
        // must not prevent indexing the other or purge its previously stored metadata.
        val collections = listOf(
            Triple(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "PHONE_IMAGES", "Telefon · fotky"),
            Triple(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "PHONE_VIDEOS", "Telefon · videa")
        )
        for ((uri, source, label) in collections) {
            // Selected-photos access on Android 14+ is a filtered view, NOT a complete library.
            // Older entries, labels and named face albums must not be purged in this mode.
            val fullAccess = hasFullCollectionAccess(source)
            if (!fullAccess) complete = false
            try {
                count += scanMediaCollection(uri, source, label, onProgress, cancelled, fullAccess)
                if (!fullAccess) onProgress("$label: omezený přístup, dříve uložené záznamy zůstaly zachovány")
            } catch (e: SecurityException) {
                complete = false
                onProgress("$label: přístup není povolen")
            }
        }
        return ScanOutcome(count, complete)
    }

    private fun scanMediaCollection(
        collection: Uri, source: String, sourceLabel: String,
        onProgress: (String) -> Unit, cancelled: () -> Boolean, fullAccess: Boolean
    ): Int {
        checkCancelled(cancelled)
        onProgress("Procházím $sourceLabel…")
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.RELATIVE_PATH
        )
        // Only mark rows stale when the query was successfully opened.
        val cursor = context.contentResolver.query(collection, projection, null, null, null)
            ?: throw IllegalStateException("Zdroj $sourceLabel není dostupný")
        var count = 0
        cursor.use { c ->
            // Never mark existing records as missing when the OS only shows a subset.
            if (fullAccess) db.markUnseen(source)
            val batch = ArrayList<IndexedFile>(200)
            val idColumn = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameColumn = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val mimeColumn = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val sizeColumn = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val modifiedColumn = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
            val folderColumn = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
            while (c.moveToNext()) {
                checkCancelled(cancelled)
                val id = c.getLong(idColumn)
                val uri = ContentUris.withAppendedId(collection, id).toString()
                batch += IndexedFile(
                    key = uri,
                    uri = uri,
                    name = c.getString(nameColumn) ?: "Soubor $id",
                    mime = c.getString(mimeColumn) ?: "application/octet-stream",
                    size = if (c.isNull(sizeColumn)) 0L else c.getLong(sizeColumn),
                    modified = if (c.isNull(modifiedColumn)) 0L else c.getLong(modifiedColumn) * 1000L,
                    folder = c.getString(folderColumn) ?: "",
                    source = source,
                    sourceLabel = sourceLabel
                )
                count++
                if (batch.size == 200) {
                    db.addBatch(batch); batch.clear()
                    onProgress("$sourceLabel: $count položek…")
                }
            }
            db.addBatch(batch)
            checkCancelled(cancelled)
            if (fullAccess) db.dropUnseen(source)
        }
        return count
    }

    /** Iterates provider-supplied metadata; remote file bytes are not fetched. */
    fun scanTree(treeUri: Uri, onProgress: (String) -> Unit, maxFiles: Int = 10000,
        cancelled: () -> Boolean = { false }): ScanOutcome {
        require(maxFiles > 0)
        checkCancelled(cancelled)
        val source = "TREE:$treeUri"
        val authority = treeUri.authority ?: "externí úložiště"
        var sourceLabel = "Složka / $authority"
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)
        val queue = ArrayDeque<Pair<String, String>>()
        queue.add(rootId to "")
        val visited = HashSet<String>()
        val pending = ArrayList<IndexedFile>(200)
        var count = 0
        var complete = true
        // Mark rows stale only if the tree is accessible.
        context.contentResolver.query(
            DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId),
            arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null
        )?.use { cursor ->
            if (!cursor.moveToFirst()) throw IllegalStateException("Složku již nelze otevřít")
            sourceLabel = "Složka / " + (cursor.getString(1) ?: authority)
        } ?: throw IllegalStateException("Složku již nelze otevřít")
        db.markUnseen(source)
        while (queue.isNotEmpty()) {
            checkCancelled(cancelled)
            val (parentId, parentPath) = queue.removeFirst()
            if (!visited.add(parentId)) continue
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
            )
            val cursor = try {
                context.contentResolver.query(children, projection, null, null, null)
            } catch (e: Exception) {
                complete = false; continue
            }
            if (cursor == null) { complete = false; continue }
            cursor.use { c ->
                if (c.extras.getBoolean(DocumentsContract.EXTRA_LOADING, false) ||
                    c.extras.getString(DocumentsContract.EXTRA_ERROR) != null) complete = false
                val idIdx = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameIdx = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val typeIdx = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                val sizeIdx = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                val modIdx = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                while (c.moveToNext() && count < maxFiles) {
                    checkCancelled(cancelled)
                    val id = c.getString(idIdx) ?: continue
                    val name = c.getString(nameIdx) ?: id
                    val mime = c.getString(typeIdx) ?: "application/octet-stream"
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        queue.add(id to "$parentPath/$name")
                    } else {
                        val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id).toString()
                        pending += IndexedFile(
                            key = "TREE:$treeUri:$id", uri = uri, name = name, mime = mime,
                            size = if (c.isNull(sizeIdx)) 0L else c.getLong(sizeIdx),
                            modified = if (c.isNull(modIdx)) 0L else c.getLong(modIdx),
                            folder = parentPath.ifBlank { "/" },
                            source = source, sourceLabel = sourceLabel
                        )
                        count++
                        if (pending.size >= 200) {
                            db.addBatch(pending); pending.clear()
                            onProgress("$sourceLabel: $count souborů…")
                        }
                    }
                }
            }
            if (count >= maxFiles) { complete = false; break }
        }
        db.addBatch(pending)
        checkCancelled(cancelled)
        if (complete) db.dropUnseen(source)
        onProgress("$sourceLabel: $count souborů" + if (!complete) " (neúplný průchod)" else "")
        return ScanOutcome(count, complete)
    }
}
