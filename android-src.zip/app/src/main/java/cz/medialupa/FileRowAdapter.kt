package cz.medialupa

import android.content.Context
import android.graphics.Typeface
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FileRowAdapter(private val context: Context) : BaseAdapter() {
    private val ui = Ui(context)
    private val loader = ThumbnailLoader(context)
    private var entries: List<ExplorerEntry> = emptyList()
    var tiled = true
        set(value) { field = value; notifyDataSetChanged() }
    var selectedKey: String? = null
        set(value) { field = value; notifyDataSetChanged() }
    val files: List<IndexedFile> get() = entries.mapNotNull { (it as? ExplorerEntry.Media)?.file }
    fun replace(items: List<IndexedFile>, folders: List<FolderEntry> = emptyList()) {
        entries = folders.map { ExplorerEntry.Folder(it) } + items.map { ExplorerEntry.Media(it) }
        notifyDataSetChanged()
    }
    override fun getCount() = entries.size
    override fun getItem(position: Int) = entries[position]
    override fun getItemId(position: Int) = position.toLong()
    override fun getViewTypeCount() = 2
    override fun getItemViewType(position: Int) = if (tiled) 0 else 1
    private data class Holder(val tiled: Boolean, val image: ImageView, val placeholder: ImageView,
        val name: TextView, val detail: TextView, val badge: ImageView, val caption: TextView)
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val root: LinearLayout
        val holder: Holder
        if (convertView?.tag is Holder && (convertView.tag as Holder).tiled == tiled) {
            root = convertView as LinearLayout; holder = root.tag as Holder
        } else {
            root = if (tiled) ui.column() else ui.row()
            root.setPadding(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8))
            val frame = FrameLayout(context).apply { background = ui.shape(ui.bg, 8); clipToOutline = true }
            val placeholder = ui.image(R.drawable.ic_image)
            frame.addView(placeholder, FrameLayout.LayoutParams(ui.dp(32), ui.dp(32), Gravity.CENTER))
            val image = ImageView(context).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            frame.addView(image, FrameLayout.LayoutParams(-1, -1))
            val badge = ui.image(R.drawable.ic_play, android.graphics.Color.WHITE).apply {
                background = ui.shape(0xBB101823.toInt(), 6); ui.pad(this, 4)
            }
            frame.addView(badge, FrameLayout.LayoutParams(ui.dp(26), ui.dp(26), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(4))
            })
            val caption = ui.label("", 11f, Color.WHITE, true).apply {
                setBackgroundColor(0xCC13212E.toInt())
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(ui.dp(6), ui.dp(4), ui.dp(6), ui.dp(4))
            }
            frame.addView(caption, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
            val textBox = ui.column()
            val name = ui.label("", 13f, bold = true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }
            val detail = ui.label("", 12f, ui.muted).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
            textBox.addView(name); textBox.addView(detail)
            if (tiled) {
                root.addView(frame, LinearLayout.LayoutParams(-1, ui.dp(116)))
                root.addView(textBox, LinearLayout.LayoutParams(-1, ui.dp(52)).apply { topMargin = ui.dp(5) })
            } else {
                root.addView(frame, LinearLayout.LayoutParams(ui.dp(52), ui.dp(52)))
                root.addView(textBox, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(12) })
            }
            holder = Holder(tiled, image, placeholder, name, detail, badge, caption); root.tag = holder
        }
        when (val entry = getItem(position)) {
            is ExplorerEntry.Folder -> {
                val folder = entry.folder
                holder.name.text = folder.title
                holder.detail.text = fileCount(folder.count)
                holder.placeholder.setImageDrawable(ui.icon(R.drawable.ic_folder, ui.folder))
                holder.image.tag = null; holder.image.setImageDrawable(null); holder.badge.visibility = View.GONE
                holder.caption.visibility = View.GONE
                root.background = ui.touch(ui.surface, ui.line)
                root.contentDescription = "Složka ${folder.title}, ${folder.count} souborů"
            }
            is ExplorerEntry.Media -> {
                val file = entry.file
                holder.name.text = file.name
                holder.caption.text = MediaDescription.caption(file)
                holder.caption.visibility = if (tiled) View.VISIBLE else View.GONE
                holder.detail.text = (if (!tiled) MediaDescription.caption(file) + " · " else "") +
                    formatSize(file.size) + if (!tiled && file.modified > 0)
                    " · " + SimpleDateFormat("d. M. yyyy", Locale("cs", "CZ")).format(Date(file.modified)) else ""
                holder.placeholder.setImageDrawable(ui.icon(when {
                    file.mime.startsWith("video/") -> R.drawable.ic_video
                    file.mime.startsWith("image/") -> R.drawable.ic_image
                    else -> R.drawable.ic_file_text
                }, ui.muted))
                holder.badge.visibility = if (file.mime.startsWith("video/")) View.VISIBLE else View.GONE
                loader.load(holder.image, file.uri, file.modified)
                root.background = ui.touch(if (file.key == selectedKey) ui.selected else ui.surface,
                    if (file.key == selectedKey) ui.accent else ui.line)
                root.contentDescription = "${file.name}, ${holder.detail.text}"
            }
        }
        return root
    }
    fun shutdown() = loader.shutdown()
    companion object {
        fun formatSize(size: Long): String = when {
            size >= 1_073_741_824 -> "%.1f GB".format(Locale("cs", "CZ"), size / 1_073_741_824.0)
            size >= 1_048_576 -> "%.1f MB".format(Locale("cs", "CZ"), size / 1_048_576.0)
            size > 0 -> "%.0f kB".format(Locale("cs", "CZ"), size / 1024.0)
            else -> "Velikost neuvedena"
        }
    }
}
