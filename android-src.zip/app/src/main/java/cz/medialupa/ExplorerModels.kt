package cz.medialupa

/** Paths here are display paths within an indexed source, never filesystem access grants. */
data class FolderEntry(val source: String, val path: String, val title: String, val count: Int)
data class FolderLocation(val source: String, val sourceLabel: String, val path: String, val count: Int)
sealed class ExplorerEntry {
    data class Media(val file: IndexedFile) : ExplorerEntry()
    data class Folder(val folder: FolderEntry) : ExplorerEntry()
}

object FolderTree {
    fun normalize(path: String) = path.split('/').filter { it.isNotBlank() }.joinToString("/")
    fun parent(path: String): String = normalize(path).substringBeforeLast('/', "")
    fun build(locations: List<FolderLocation>): List<FolderEntry> {
        val totals = linkedMapOf<Pair<String, String>, Int>()
        val labels = linkedMapOf<String, String>()
        locations.forEach { item ->
            val source = if (item.source.startsWith("PHONE_")) "PHONE" else item.source
            labels[source] = if (source == "PHONE") "Telefon" else item.sourceLabel.removePrefix("Složka / ")
            val parts = normalize(item.path).split('/').filter { it.isNotBlank() }
            for (depth in 0..parts.size) {
                val key = source to parts.take(depth).joinToString("/")
                totals[key] = (totals[key] ?: 0) + item.count
            }
        }
        return totals.map { (key, count) ->
            FolderEntry(key.first, key.second,
                if (key.second.isEmpty()) labels[key.first] ?: "Připojená složka"
                else key.second.substringAfterLast('/'), count)
        }.sortedWith(compareBy<FolderEntry> { if (it.source == "PHONE") "" else it.source }.thenBy { it.path.lowercase() })
    }

    fun children(nodes: List<FolderEntry>, source: String?, path: String): List<FolderEntry> =
        nodes.filter { if (source == null) it.path.isEmpty() else
            it.source == source && it.path.isNotEmpty() && parent(it.path) == normalize(path) }
            .sortedBy { it.title.lowercase() }
}
