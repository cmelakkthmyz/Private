package cz.medialupa

import java.util.Locale

/** Short, cautious offline descriptions, built only from detected evidence. */
object MediaDescription {
    private val sceneGroups = linkedMapOf(
        "v lese" to setOf("les", "strom", "forest", "tree"),
        "v přírodě" to setOf("příroda", "krajina", "hory", "hora", "nature", "landscape", "mountain"),
        "u vody" to setOf("voda", "jezero", "rybník", "řeka", "moře", "pláž", "river", "lake", "beach", "water"),
        "v zahradě" to setOf("zahrada", "garden"),
        "v pokoji" to setOf("pokoj", "místnost", "interiér", "room", "indoor", "interior"),
        "v kuchyni" to setOf("kuchyně", "kitchen"),
        "na ulici" to setOf("ulice", "street"),
        "ve městě" to setOf("město", "city"),
        "na sněhu" to setOf("sníh", "snow")
    )
    private val subjects = linkedMapOf(
        "pes" to setOf("pes", "psi", "pejsek", "dog"),
        "kočka" to setOf("kočka", "kotě", "cat"),
        "kůň" to setOf("kůň", "horse"),
        "pták" to setOf("pták", "bird"),
        "auto" to setOf("auto", "vozidlo", "car", "vehicle"),
        "kolo" to setOf("kolo", "bicycle"),
        "květiny" to setOf("květina", "květiny", "flower"),
        "jídlo" to setOf("jídlo", "pokrm", "food", "meal"),
        "západ slunce" to setOf("západ slunce", "sunset")
    )
    private fun labels(text: String): Set<String> = text.lowercase(Locale.ROOT).split(',')
        .map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun caption(mime: String, aiLabels: String, faceCount: Int = 0,
        namedPeople: List<String> = emptyList(), analyzed: Boolean = true): String {
        val video = mime.startsWith("video/")
        val type = if (video) "Video" else "Fotografie"
        if (!analyzed) return "$type · obsah čeká na analýzu"
        val evidence = labels(aiLabels)
        val location = sceneGroups.entries.firstOrNull { (_, clues) -> evidence.any { it in clues } }?.key
        val subject = subjects.entries.firstOrNull { (_, clues) -> evidence.any { it in clues } }?.key
        val names = namedPeople.map { it.trim() }.filter { it.isNotBlank() }
            .distinct().take(3)
        val human = when {
            names.isNotEmpty() -> names.joinToString(", ")
            faceCount == 1 -> "jedna osoba"
            faceCount == 2 -> "dvě osoby"
            faceCount > 2 -> "${faceCount} osob"
            evidence.any { it in setOf("lidé", "osoba", "člověk", "people", "person") } -> "lidé"
            else -> null
        }
        val content = when {
            human != null && location != null -> "$human $location"
            human != null && subject != null -> "$human a $subject"
            human != null -> human
            subject != null && location != null -> "$subject $location"
            subject != null -> subject
            location != null -> location.removePrefix("v ").removePrefix("u ").replaceFirstChar { it.uppercase() }
            else -> "obsah nelze spolehlivě určit"
        }
        return "$type · $content"
    }
    fun caption(file: IndexedFile): String = caption(file.mime, file.aiLabels,
        file.faceCount, file.namedPeople, file.analyzedVersion == 1)
}
