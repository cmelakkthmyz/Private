package cz.medialupa

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Lokální databáze; migrace zachovává dosavadní index a hashe. */
class IndexDatabase(context: Context) : SQLiteOpenHelper(context, "media_index.db", null, 4) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE entries (
            key TEXT PRIMARY KEY NOT NULL, uri TEXT NOT NULL, name TEXT NOT NULL,
            mime TEXT NOT NULL, size INTEGER NOT NULL, modified INTEGER NOT NULL,
            folder TEXT NOT NULL, source TEXT NOT NULL, source_label TEXT NOT NULL,
            sha256 TEXT, seen INTEGER NOT NULL DEFAULT 1,
            ai_labels TEXT NOT NULL DEFAULT '', ai_search TEXT NOT NULL DEFAULT '',
            ocr_text TEXT NOT NULL DEFAULT '', analyzed_version INTEGER NOT NULL DEFAULT 0,
            ocr_completed INTEGER NOT NULL DEFAULT 0,
            search_normalized TEXT NOT NULL DEFAULT '', face_scanned_version INTEGER NOT NULL DEFAULT 0
        )""")
        db.execSQL("CREATE INDEX idx_entries_size ON entries (size)")
        db.execSQL("CREATE INDEX idx_entries_source ON entries (source)")
        db.execSQL("CREATE INDEX idx_entries_hash ON entries (sha256)")
        db.execSQL("CREATE INDEX idx_entries_ai ON entries (analyzed_version)")
        createFaceTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE entries ADD COLUMN ai_labels TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE entries ADD COLUMN ai_search TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE entries ADD COLUMN ocr_text TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE entries ADD COLUMN analyzed_version INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE entries ADD COLUMN ocr_completed INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE entries ADD COLUMN search_normalized TEXT NOT NULL DEFAULT ''")
            db.execSQL("CREATE INDEX idx_entries_ai ON entries (analyzed_version)")
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE entries ADD COLUMN face_scanned_version INTEGER NOT NULL DEFAULT 0")
            createFaceTables(db)
        }
        if (oldVersion < 4) {
            // Repair orphaned samples and outdated centroids left by 0.5 rescans.
            db.delete("face_samples", "NOT EXISTS (SELECT 1 FROM entries WHERE entries.key=face_samples.file_key)", null)
            val ids = db.rawQuery("SELECT id FROM face_people", null).use { c ->
                buildList { while (c.moveToNext()) add(c.getLong(0)) }
            }
            ids.forEach { recalculatePerson(db, it) }
        }
    }

    private fun createFaceTables(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS face_people (
            id INTEGER PRIMARY KEY AUTOINCREMENT, display_name TEXT NOT NULL DEFAULT '',
            center BLOB NOT NULL, sample_count INTEGER NOT NULL DEFAULT 0
        )""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS face_samples (
            id INTEGER PRIMARY KEY AUTOINCREMENT, file_key TEXT NOT NULL,
            person_id INTEGER NOT NULL, embedding BLOB NOT NULL, frame_us INTEGER NOT NULL,
            center_x REAL NOT NULL, center_y REAL NOT NULL
        )""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_faces_person ON face_samples(person_id,file_key)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_faces_file ON face_samples(file_key)")
    }

    fun markUnseen(source: String) = writableDatabase.execSQL("UPDATE entries SET seen=0 WHERE source=?", arrayOf(source))
    fun dropUnseen(source: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val people = db.rawQuery("""SELECT DISTINCT person_id FROM face_samples
                WHERE file_key IN (SELECT key FROM entries WHERE source=? AND seen=0)""",
                arrayOf(source)).use { c -> buildList { while (c.moveToNext()) add(c.getLong(0)) } }
            db.delete("face_samples", "file_key IN (SELECT key FROM entries WHERE source=? AND seen=0)", arrayOf(source))
            db.delete("entries", "source=? AND seen=0", arrayOf(source))
            people.forEach { recalculatePerson(db, it) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun addBatch(items: List<IndexedFile>) {
        if (items.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            val affectedPeople = mutableSetOf<Long>()
            for (item in items) {
                // Při opětovném indexování se AI výsledky zachovají, pokud se soubor nezměnil.
                val old = db.rawQuery(
                    "SELECT sha256, ai_labels, ai_search, ocr_text, analyzed_version, ocr_completed FROM entries WHERE key=? AND size=? AND modified=? AND mime=? AND uri=?",
                    arrayOf(item.key, item.size.toString(), item.modified.toString(), item.mime, item.uri)
                ).use { c ->
                    if (c.moveToFirst()) (0..5).map { i -> c.getString(i) } else emptyList()
                }
                val wasUnchanged = old.isNotEmpty()
                if (!wasUnchanged) {
                    db.rawQuery("SELECT DISTINCT person_id FROM face_samples WHERE file_key=?", arrayOf(item.key)).use { c ->
                        while (c.moveToNext()) affectedPeople.add(c.getLong(0))
                    }
                    db.delete("face_samples", "file_key=?", arrayOf(item.key))
                }
                val oldFaceVersion = if (wasUnchanged) db.rawQuery(
                    "SELECT face_scanned_version FROM entries WHERE key=?", arrayOf(item.key)
                ).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 } else 0
                val values = ContentValues().apply {
                    put("face_scanned_version", oldFaceVersion)
                    put("key", item.key); put("uri", item.uri); put("name", item.name)
                    put("mime", item.mime); put("size", item.size); put("modified", item.modified)
                    put("folder", item.folder); put("source", item.source)
                    put("source_label", item.sourceLabel); put("search_normalized", CzechSearch.normalized("${item.name} ${item.folder}"))
                    put("sha256", old.getOrNull(0)); put("ai_labels", old.getOrNull(1) ?: "")
                    put("ai_search", old.getOrNull(2) ?: "")
                    put("ocr_text", old.getOrNull(3) ?: "")
                    put("analyzed_version", old.getOrNull(4)?.toIntOrNull() ?: 0)
                    put("ocr_completed", old.getOrNull(5)?.toIntOrNull() ?: 0)
                    put("seen", 1)
                }
                db.insertWithOnConflict("entries", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            affectedPeople.forEach { recalculatePerson(db, it) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Retry only failed work; valid labels, hashes and named albums are retained. */
    fun retryFailedAnalysis(): Int {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val count = db.rawQuery("SELECT COUNT(*) FROM entries WHERE analyzed_version=-1 OR face_scanned_version=-1", null)
                .use { c -> c.moveToFirst(); c.getInt(0) }
            db.execSQL("UPDATE entries SET analyzed_version=0 WHERE analyzed_version=-1")
            db.execSQL("UPDATE entries SET face_scanned_version=0 WHERE face_scanned_version=-1")
            db.setTransactionSuccessful()
            return count
        } finally { db.endTransaction() }
    }

    fun setHash(key: String, hash: String) {
        val values = ContentValues().apply { put("sha256", hash) }
        writableDatabase.update("entries", values, "key=?", arrayOf(key))
    }

    fun saveAiResult(key: String, labelNames: List<String>, ocr: String, ocrDone: Boolean) {
        val display = CzechSearch.displayLabels(labelNames)
        val normalizedText = CzechSearch.normalized(ocr)
        val labelText = labelNames.joinToString(" ") { CzechSearch.indexedLabelText(it) }
        val values = ContentValues().apply {
            put("ai_labels", display)
            put("ai_search", (labelText + " " + normalizedText).take(30_000))
            put("ocr_text", ocr.take(20_000))
            put("analyzed_version", 1)
            put("ocr_completed", if (ocrDone) 1 else 0)
        }
        writableDatabase.update("entries", values, "key=?", arrayOf(key))
    }
    fun markAiUnreadable(key: String) {
        val values = ContentValues().apply { put("analyzed_version", -1) }
        writableDatabase.update("entries", values, "key=?", arrayOf(key))
    }

    fun mediaToAnalyze(limit: Int, withOcr: Boolean): List<IndexedFile> = readableDatabase.rawQuery(
        """SELECT key,uri,name,mime,size,modified,folder,source,source_label,sha256,ai_labels,analyzed_version
            FROM entries WHERE source LIKE 'PHONE_%' AND (mime LIKE 'image/%' OR mime LIKE 'video/%')
            AND (analyzed_version=0 ${if (withOcr) "OR (analyzed_version=1 AND ocr_completed=0)" else ""})
            ORDER BY modified DESC LIMIT ${limit.coerceIn(1,10000)}""", null
    ).use { c -> buildList { while (c.moveToNext()) add(c.toItem()) } }

    fun stats(): IndexStats = readableDatabase.rawQuery("""SELECT
        COALESCE(SUM(CASE WHEN mime LIKE 'image/%' THEN 1 ELSE 0 END),0),
        COALESCE(SUM(CASE WHEN mime LIKE 'video/%' THEN 1 ELSE 0 END),0),
        COALESCE(SUM(CASE WHEN mime NOT LIKE 'image/%' AND mime NOT LIKE 'video/%' THEN 1 ELSE 0 END),0),
        COALESCE(SUM(CASE WHEN analyzed_version=1 THEN 1 ELSE 0 END),0)
        FROM entries""", null).use { c ->
        if (c.moveToFirst()) IndexStats(c.getInt(0), c.getInt(1), c.getInt(2), c.getInt(3))
        else IndexStats(0, 0, 0, 0)
    }

    fun folderLocations(): List<FolderLocation> = readableDatabase.rawQuery(
        "SELECT source, source_label, folder, COUNT(*) FROM entries GROUP BY source, source_label, folder", null
    ).use { c -> buildList { while (c.moveToNext()) add(FolderLocation(c.getString(0), c.getString(1), c.getString(2), c.getInt(3))) } }

    fun search(text: String, filter: FileFilter, sort: SortOrder = SortOrder.NEWEST, limit: Int = 250,
        sourceGroup: String? = null, folderPath: String? = null, recursive: Boolean = false,
        topicId: String? = null, personId: Long? = null): List<IndexedFile> {
        val conditions = mutableListOf<String>()
        val args = mutableListOf<String>()
        if (sourceGroup == "PHONE") conditions += "source LIKE 'PHONE_%'"
        else if (sourceGroup != null) { conditions += "source=?"; args += sourceGroup }
        if (folderPath != null) {
            val path = FolderTree.normalize(folderPath)
            if (recursive && path.isNotEmpty()) {
                conditions += "(trim(folder,'/')=? OR instr(trim(folder,'/'),?)=1)"
                args += path; args += "$path/"
            } else if (!recursive) {
                conditions += "trim(folder,'/')=?"; args += path
            }
        }
        if (topicId != null) {
            val topic = TopicCatalog.all.firstOrNull { it.id == topicId } ?: return emptyList()
            conditions += "analyzed_version=1 AND (" + topicCondition(topic) + ")"
            args += topic.words
        }
        if (personId != null) {
            conditions += "EXISTS (SELECT 1 FROM face_samples f WHERE f.file_key=entries.key AND f.person_id=?)"
            args += personId.toString()
        }
        val tokens = CzechSearch.searchTokens(text)
        if (tokens.isNotEmpty()) for (token in tokens) {
            conditions += "(search_normalized LIKE ? OR ai_search LIKE ? OR ocr_text LIKE ? OR name LIKE ? OR folder LIKE ?)"
            repeat(5) { args += "%$token%" }
        }
        when (filter) {
            FileFilter.PHOTOS -> conditions += "mime LIKE 'image/%'"
            FileFilter.VIDEOS -> conditions += "mime LIKE 'video/%'"
            FileFilter.DOCUMENTS -> conditions += "mime NOT LIKE 'image/%' AND mime NOT LIKE 'video/%'"
            FileFilter.DUPLICATES -> conditions += "sha256 IS NOT NULL AND sha256 IN (SELECT sha256 FROM entries WHERE sha256 IS NOT NULL GROUP BY sha256 HAVING COUNT(*) > 1)"
            FileFilter.AI -> conditions += "analyzed_version=1"
            FileFilter.ALL -> Unit
        }
        val where = if (conditions.isEmpty()) "" else " WHERE " + conditions.joinToString(" AND ")
        val order = if (filter == FileFilter.DUPLICATES) "sha256, modified DESC" else when (sort) {
            SortOrder.NEWEST -> "modified DESC, name COLLATE NOCASE"
            SortOrder.OLDEST -> "modified ASC, name COLLATE NOCASE"
            SortOrder.LARGEST -> "size DESC, modified DESC"
            SortOrder.SMALLEST -> "size ASC, modified DESC"
            SortOrder.NAME -> "name COLLATE NOCASE ASC"
        }
        val sql = "SELECT key,uri,name,mime,size,modified,folder,source,source_label,sha256,ai_labels,analyzed_version FROM entries$where ORDER BY $order LIMIT ${limit.coerceIn(1,10000)}"
        return readableDatabase.rawQuery(sql, args.toTypedArray()).use { c ->
            buildList { while (c.moveToNext()) add(c.toItem()) }
        }
    }

    fun localHashCandidates(): List<IndexedFile> {
        val sql = """SELECT key,uri,name,mime,size,modified,folder,source,source_label,sha256,ai_labels,analyzed_version
            FROM entries WHERE source LIKE 'PHONE_%' AND size > 0
            AND size IN (SELECT size FROM entries WHERE source LIKE 'PHONE_%' AND size > 0
                GROUP BY size HAVING COUNT(*) > 1)
            ORDER BY size"""
        return readableDatabase.rawQuery(sql, null).use { c ->
            buildList { while (c.moveToNext()) add(c.toItem()) }
        }
    }

    /** Offline tematicka alba: fotografie mohou byt ve vice kategoriich. */
    private fun topicCondition(topic: TopicCatalog.Topic): String = topic.words.joinToString(" OR ") {
        "instr(' ' || ai_search || ' ', ' ' || ? || ' ') > 0"
    }

    fun topicAlbums(): List<TopicAlbum> {
        val db = readableDatabase
        return TopicCatalog.all.map { topic ->
            val args = topic.words.toTypedArray()
            val sql = """SELECT COUNT(*), MIN(uri) FROM entries
                WHERE (mime LIKE 'image/%' OR mime LIKE 'video/%')
                AND analyzed_version=1 AND (${topicCondition(topic)})"""
            db.rawQuery(sql, args).use { c ->
                if (c.moveToFirst()) TopicAlbum(topic.id, topic.title, c.getInt(0), c.getString(1))
                else TopicAlbum(topic.id, topic.title, 0, null)
            }
        }.filter { it.count > 0 }
    }

    fun topicFiles(topicId: String, sort: SortOrder): List<IndexedFile> {
        val topic = TopicCatalog.all.firstOrNull { it.id == topicId } ?: return emptyList()
        val order = when (sort) {
            SortOrder.NEWEST -> "modified DESC"; SortOrder.OLDEST -> "modified ASC"
            SortOrder.LARGEST -> "size DESC"; SortOrder.SMALLEST -> "size ASC"
            SortOrder.NAME -> "name COLLATE NOCASE"
        }
        return readableDatabase.rawQuery("""SELECT key,uri,name,mime,size,modified,folder,source,
            source_label,sha256,ai_labels,analyzed_version FROM entries
            WHERE analyzed_version=1 AND (${topicCondition(topic)})
            ORDER BY $order LIMIT 1000""",topic.words.toTypedArray()).use { c ->
            buildList { while (c.moveToNext()) add(c.toItem()) }
        }
    }

    fun mediaToScanFaces(limit: Int): List<IndexedFile> = readableDatabase.rawQuery("""
        SELECT key,uri,name,mime,size,modified,folder,source,source_label,sha256,ai_labels,analyzed_version
        FROM entries WHERE source LIKE 'PHONE_%' AND
        (mime LIKE 'image/%' OR mime LIKE 'video/%') AND face_scanned_version=0
        ORDER BY modified DESC LIMIT ${limit.coerceIn(1,500)}""",null).use { c ->
        buildList { while (c.moveToNext()) add(c.toItem()) }
    }

    fun markFacesScanned(fileKey: String, success: Boolean) {
        writableDatabase.execSQL("UPDATE entries SET face_scanned_version=? WHERE key=?",
            arrayOf(if (success) 1 else -1, fileKey))
    }

    /** Lokalne vektory, nikoliv snimky obliceje. Model nema schopnost urcit jmeno sam. */
    fun saveFaceSamples(fileKey: String, samples: List<FaceSample>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val previousPeople = db.rawQuery("SELECT DISTINCT person_id FROM face_samples WHERE file_key=?", arrayOf(fileKey))
                .use { c -> buildList { while (c.moveToNext()) add(c.getLong(0)) } }
            db.delete("face_samples", "file_key=?", arrayOf(fileKey))
            for (sample in samples) {
                if (sample.embedding.isEmpty()) continue
                val personId = findOrCreatePerson(db, sample.embedding)
                db.insertOrThrow("face_samples", null, ContentValues().apply {
                    put("file_key", fileKey); put("person_id", personId)
                    put("embedding", faceBytes(sample.embedding)); put("frame_us", sample.frameTimeUs)
                    put("center_x", sample.centerX); put("center_y", sample.centerY)
                })
            }
            previousPeople.forEach { recalculatePerson(db, it) }
            db.execSQL("UPDATE entries SET face_scanned_version=1 WHERE key=?",arrayOf(fileKey))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun findOrCreatePerson(db: SQLiteDatabase, embedding: FloatArray): Long {
        val vector = unit(embedding)
        var best = 0.82f // Konzervativni navrh skupin, uzivatel je muze opravit.
        var match: Long? = null
        var oldMean: FloatArray? = null
        var count = 0
        db.rawQuery("SELECT id,center,sample_count FROM face_people",null).use { cursor ->
            while (cursor.moveToNext()) {
                val other = fromBytes(cursor.getBlob(1))
                if (other.size != vector.size) continue
                val similarity = vector.indices.sumOf { (vector[it] * other[it]).toDouble() }.toFloat()
                if (similarity > best) {
                    best=similarity; match=cursor.getLong(0);oldMean=other;count=cursor.getInt(2)
                }
            }
        }
        val chosen = match
        if (chosen != null) {
            // Velke fotoalbum nezatizujeme neomezene rostoucim poctem vzorku.
            val n = count.coerceIn(0, 20)
            val previous = oldMean!!
            val merged = unit(FloatArray(vector.size) { (previous[it]*n+vector[it])/(n+1) })
            db.update("face_people", ContentValues().apply {
                put("center",faceBytes(merged));put("sample_count",count+1)
            },"id=?",arrayOf(chosen.toString()))
            return chosen
        }
        return db.insertOrThrow("face_people",null,ContentValues().apply {
            put("display_name", "");put("center",faceBytes(vector));put("sample_count",1)
        })
    }

    fun personAlbums(): List<PersonAlbum> = readableDatabase.rawQuery("""SELECT p.id,p.display_name,
        COUNT(DISTINCT f.file_key),MIN(e.uri) FROM face_people p
        JOIN face_samples f ON f.person_id=p.id
        JOIN entries e ON e.key=f.file_key
        GROUP BY p.id ORDER BY LOWER(p.display_name),p.id""", null).use { c ->
        buildList { while(c.moveToNext()) add(PersonAlbum(c.getLong(0),
            c.getString(1).takeIf { it.isNotBlank() } ?: "Osoba ${c.getLong(0)}",
            c.getInt(2),c.getString(3))) }
    }

    fun personFiles(personId: Long, sort: SortOrder): List<IndexedFile> {
        val order = when(sort) {
            SortOrder.NEWEST -> "modified DESC"; SortOrder.OLDEST -> "modified ASC"
            SortOrder.LARGEST -> "size DESC"; SortOrder.SMALLEST -> "size ASC"
            SortOrder.NAME -> "name COLLATE NOCASE"
        }
        return readableDatabase.rawQuery("""SELECT e.key,e.uri,e.name,e.mime,e.size,e.modified,
            e.folder,e.source,e.source_label,e.sha256,e.ai_labels,e.analyzed_version
            FROM entries e WHERE EXISTS (SELECT 1 FROM face_samples f
                WHERE f.file_key=e.key AND f.person_id=?) ORDER BY $order LIMIT 1000""",
            arrayOf(personId.toString())).use { c -> buildList { while(c.moveToNext()) add(c.toItem()) } }
    }

    fun renamePerson(personId: Long, newName: String) = writableDatabase.update("face_people",
        ContentValues().apply { put("display_name",newName.take(80).trim()) },"id=?",arrayOf(personId.toString()))

    fun mergePeople(targetId: Long, sourceId: Long) {
        if (targetId == sourceId) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            val exists = db.rawQuery("SELECT COUNT(*) FROM face_people WHERE id IN (?,?)",
                arrayOf(targetId.toString(), sourceId.toString())).use { c -> c.moveToFirst(); c.getInt(0) == 2 }
            require(exists) { "Album již neexistuje. Obnov seznam osob." }
            db.execSQL("UPDATE face_samples SET person_id=? WHERE person_id=?",arrayOf(targetId,sourceId))
            db.delete("face_people","id=?",arrayOf(sourceId.toString()))
            recalculatePerson(db,targetId)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Ulozena identita se od snimku odlouci a vytvori novou skupinu. */
    fun splitFileFromPerson(fileKey: String, personId: Long) {
        val db=writableDatabase
        db.beginTransaction()
        try {
            val faceIds=mutableListOf<Pair<Long,FloatArray>>()
            db.rawQuery("SELECT id,embedding FROM face_samples WHERE file_key=? AND person_id=?",
                arrayOf(fileKey,personId.toString())).use { c ->
                while(c.moveToNext()) faceIds+=c.getLong(0) to fromBytes(c.getBlob(1))
            }
            for((id,emb) in faceIds) {
                val group=db.insertOrThrow("face_people",null,ContentValues().apply {
                    put("display_name","");put("center",faceBytes(unit(emb)));put("sample_count",1)
                })
                db.execSQL("UPDATE face_samples SET person_id=? WHERE id=?",arrayOf(group,id))
            }
            recalculatePerson(db,personId)
            db.setTransactionSuccessful()
        } finally {db.endTransaction()}
    }

    private fun recalculatePerson(db: SQLiteDatabase, personId: Long) {
        var total:FloatArray?=null
        var count=0
        db.rawQuery("SELECT embedding FROM face_samples WHERE person_id=?",
            arrayOf(personId.toString())).use { c ->
            while(c.moveToNext()) {
                val v=fromBytes(c.getBlob(0)); if(v.isEmpty())continue
                if(total==null)total=FloatArray(v.size)
                if(total!!.size!=v.size)continue
                for(i in v.indices)total!![i]+=v[i]
                count++
            }
        }
        if(count==0) db.delete("face_people","id=?",arrayOf(personId.toString()))
        else db.update("face_people",ContentValues().apply {
            put("center",faceBytes(unit(total!!)));put("sample_count",count)
        },"id=?",arrayOf(personId.toString()))
    }

    /** Removes only this album's biometric templates and name; originals remain untouched. */
    fun removePerson(personId: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("face_samples", "person_id=?", arrayOf(personId.toString()))
            db.delete("face_people", "id=?", arrayOf(personId.toString()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun removeAllFaces() {
        val db=writableDatabase
        db.beginTransaction()
        try {
            db.delete("face_samples",null,null);db.delete("face_people",null,null)
            db.execSQL("UPDATE entries SET face_scanned_version=0")
            db.setTransactionSuccessful()
        }finally {db.endTransaction()}
    }

    private fun faceBytes(a:FloatArray): ByteArray = java.nio.ByteBuffer.allocate(a.size*4)
        .order(java.nio.ByteOrder.LITTLE_ENDIAN).apply{a.forEach { putFloat(it) }}.array()
    private fun fromBytes(bytes:ByteArray):FloatArray = FloatArray(bytes.size/4).also { a ->
        val b=java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        for(i in a.indices)a[i]=b.float
    }
    private fun unit(a:FloatArray):FloatArray {
        val size=kotlin.math.sqrt(a.sumOf { (it*it).toDouble() }).toFloat()
        return if(size<1e-7f)a.copyOf() else FloatArray(a.size){a[it]/size}
    }

    private fun Cursor.toItem(): IndexedFile = IndexedFile(
        key = getString(0), uri = getString(1), name = getString(2), mime = getString(3),
        size = getLong(4), modified = getLong(5), folder = getString(6),
        source = getString(7), sourceLabel = getString(8), sha256 = getString(9),
        aiLabels = getString(10) ?: "", analyzedVersion = getInt(11)
    )
}
