package cz.medialupa

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import android.widget.ImageView
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

class ThumbnailLoader(context: Context) {
    private val app = context.applicationContext
    private val executor = Executors.newFixedThreadPool(2)
    private val handler = Handler(Looper.getMainLooper())
    private val cache = object : LruCache<String, Bitmap>(16 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }
    @Volatile private var closed = false
    fun load(target: ImageView, uri: String?, stamp: Long = 0) {
        val key = "$uri:$stamp"
        target.tag = key; target.setImageDrawable(null)
        if (uri == null || closed) return
        val parsed = Uri.parse(uri)
        // Providers can live in the cloud. Do not fetch their file bytes for automatic thumbnails.
        if (parsed.authority != "media" && parsed.authority != "com.android.externalstorage.documents") return
        cache.get(key)?.let { target.setImageBitmap(it); return }
        try { executor.execute {
            val image = try { app.contentResolver.loadThumbnail(parsed, Size(320, 320), null) }
                catch (_: Exception) { null } catch (_: OutOfMemoryError) { null }
            if (image != null && !closed) {
                cache.put(key, image)
                handler.post { if (!closed && target.tag == key) target.setImageBitmap(image) }
            }
        } } catch (_: RejectedExecutionException) { }
    }
    fun shutdown() { closed = true; executor.shutdownNow(); cache.evictAll(); handler.removeCallbacksAndMessages(null) }

    companion object {
        fun preview(context: Context, uri: Uri, mime: String, maxSide: Int = 2048): Bitmap? =
            if (mime.startsWith("video/")) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, uri)
                    retriever.getScaledFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, maxSide, maxSide)
                } finally { retriever.release() }
            } else ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri)) { decoder, info, _ ->
                val largest = maxOf(info.size.width, info.size.height)
                if (largest > maxSide) {
                    val ratio = maxSide.toFloat() / largest
                    decoder.setTargetSize(maxOf(1, (info.size.width * ratio).toInt()), maxOf(1, (info.size.height * ratio).toInt()))
                }
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
    }
}
