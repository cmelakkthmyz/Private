package cz.medialupa

import android.content.ContentResolver
import android.net.Uri
import java.security.MessageDigest
import java.util.concurrent.CancellationException

class DuplicateFinder(private val resolver: ContentResolver, private val database: IndexDatabase) {
    /** Only hashes equal-size, nonempty local files to avoid unnecessary reads. */
    fun find(onProgress: (String) -> Unit, cancelled: () -> Boolean = { false }): Pair<Int, Int> {
        val candidates = database.localHashCandidates()
        var hashed = 0
        var failed = 0
        for ((index, item) in candidates.withIndex()) {
            if (cancelled()) break
            if (item.sha256 != null) continue
            try {
                val digest = sha256(Uri.parse(item.uri), cancelled)
                database.setHash(item.key, digest)
                hashed++
            } catch (e: CancellationException) {
                break
            } catch (e: Exception) {
                // Permission, disconnected media, or an unreadable file.
                failed++
            }
            if (index % 10 == 0 || index == candidates.lastIndex) {
                onProgress("Kontroluji shody: ${index + 1}/${candidates.size}…")
            }
        }
        return hashed to failed
    }

    private fun sha256(uri: Uri, cancelled: () -> Boolean): String {
        val md = MessageDigest.getInstance("SHA-256")
        val input = resolver.openInputStream(uri) ?: error("Soubor se nepodařilo otevřít")
        input.use { stream ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                if (cancelled()) throw CancellationException()
                val count = stream.read(buffer)
                if (count < 0) break
                if (count > 0) md.update(buffer, 0, count)
            }
        }
        return md.digest().joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    }
}
