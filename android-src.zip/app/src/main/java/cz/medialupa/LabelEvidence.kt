package cz.medialupa

import java.util.Locale

/** Multi-view evidence: crop-only guesses need stronger confidence than full-photo predictions. */
data class LabelVote(val label: String, val confidence: Float, val fullFrame: Boolean, val frame: Int)

object LabelEvidence {
    private val generic = setOf(
        "photography", "image", "picture", "photo caption", "snapshot", "stock photography",
        "stock photo", "picture frame", "font", "text", "art", "graphics", "illustration"
    )

    fun bestLabels(votes: List<LabelVote>, limit: Int = 12): List<String> = votes
        .filter { it.confidence.isFinite() && it.confidence in 0.4f..1f }
        .groupBy { it.label.lowercase(Locale.ROOT).trim() }
        .filterKeys { it.isNotBlank() && it !in generic }
        .mapNotNull { (_, examples) ->
            val full = examples.filter { it.fullFrame }.maxOfOrNull { it.confidence } ?: 0f
            val crop = examples.filterNot { it.fullFrame }.maxOfOrNull { it.confidence } ?: 0f
            val differentFrames = examples.map { it.frame }.distinct().size
            val strong = full >= 0.66f || crop >= 0.83f ||
                (differentFrames >= 2 && full >= 0.55f) ||
                (differentFrames >= 2 && crop >= 0.73f)
            if (!strong) null else {
                val evidence = maxOf(full, crop * .88f) + (differentFrames - 1).coerceAtMost(4) * .05f
                examples.first().label to evidence
            }
        }
        .sortedByDescending { it.second }
        .take(limit.coerceIn(1, 50))
        .map { it.first }
}
