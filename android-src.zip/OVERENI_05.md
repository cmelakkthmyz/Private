# Ověření MediaLupy 0.5

Datum: 3. listopadu 2026

- assembleDebug: úspěch.
- 6 automatických testů: úspěch, 0 chyb.
- Android Lint: 0 chyb; upozornění zejména na lokalizaci, převzaté zdroje, API a starší závislosti.
- Ověřen podpis výsledného APK.
- Ověřeno: balíček cz.medialupa.explorer, minimum API 29, target API 35, compile API 36.
- Výsledný manifest nemá oprávnění INTERNET.
- Rozložení a ovládání byly ověřeny v Robolectric na API 35 pro telefon i širokou obrazovku. Testovací adaptéry převádějí hostitelské načítání obrázků na datové proudy; nejsou součástí APK. Ukázkové obrázky jsou procedurální testovací data, nejde o uživatelské fotografie.
- Video bylo ověřeno z hlediska přechodu do přehrávače a ovládání obrazovky; skutečné kodeky a zvuk vyžadují zkoušku na fyzickém telefonu.
- Přebíraný TensorFlow Lite 2.14 obsahuje knihovny bez zarovnání pro 16KB stránky. Kompatibilita analýzy obličejů na telefonech používajících 16KB stránky není potvrzena. Pro veřejné vydání je potřeba modernizovat a otestovat tuto závislost.
- Test na fyzickém telefonu zde neproběhl.

SHA-256 APK: 72b2627d4226118ba826eeb7352438425303786d962fb45222a610527946728c
