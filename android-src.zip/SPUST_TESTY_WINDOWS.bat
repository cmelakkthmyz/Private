@echo off
cd /d "%~dp0"
echo === Unit tests MediaLupa ===
call gradlew.bat :app:testDebugUnitTest
if errorlevel 1 exit /b 1
echo === Sestaveni Android APK ===
call gradlew.bat :app:assembleDebug
if errorlevel 1 exit /b 1
echo === Hotovo: app\build\outputs\apk\debug ===
pause
