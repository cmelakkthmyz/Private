# MediaLupa 0.7 – instalace vedle 0.6.1

Z důvodu nekompatibilního dočasného podpisového klíče je tato varianta vydána pod samostatným Android ID `cz.medialupa.explorer.v07`. Lze ji instalovat vedle staré verze bez odinstalace. Index vnitřní databáze obou aplikací je nezávislý; v nové aplikaci znovu načti fotografie a videa a spusť analýzu. Původní soubory se nemažou.

V této verzi: jen média v katalogu, kontinuální AI a rozpoznávání obličejů, více výřezů/časových snímků, operace se složkami podle oprávnění Androidu a adaptivnější rozhraní. Mazání skutečných složek může smazat i jiné soubory, které MediaLupa neindexuje; vždy se zobrazuje potvrzení.
