# MediaLupa 0.6

Testovatelná Android aktualizace 0.5, zaměřená na spolehlivost a soukromí.
Obsahuje bezpečné zastavení načítání a hashování, opakování neúspěšné analýzy,
opravy biometrického indexu včetně migrace, smazání jednoho profilu, kontrolu
neúplných SAF průchodů a přesnější překlad štítků. Zůstává původní grafické rozhraní.

Podrobný popis: README.md. Skutečný stav a další kroky: STAV_A_DALSI_VYVOJ_06.md.
Výsledky ověření a kontrolní součet APK: OVERENI_06.md.
