# MediaLupa 0.4 TEST – nová offline alba

Záložka **Témata**: automatická česká alba z ML Kit štítků. Jedna fotografie může být ve více albech bez kopírování souboru. Podporují se také vybrané snímky z videí. Před otevřením témat je nutné nejdříve použít **Indexovat telefon** a **Analyzovat fotky a videa** (případně více dávek).

Záložka **Osoby**: po výslovném potvrzení proběhne offline indexace fotografií a až tří snímků z videa. Detektor ML Kit najde obličeje, síť MobileFaceNet vygeneruje číselné vektory a místní SQLite je předběžně seskupí. Výsledky nemusí být spolehlivé: model automaticky nezná jména, uživatel je zadává dlouhým podržením osoby. Stejně lze spojit dvě skupiny nebo v albu dlouhým podržením vyřadit chybně zařazený soubor.

**Smazat index osob** odstraní jména i biometrické vektory, ne fotografie nebo videa. Z aplikace je výslovně odstraněno oprávnění INTERNET, vypnutá záloha dat. Toto je funkce soukromého fotoalba, nikoli bezpečnostní identifikace osob.

Zkušební balíček má identifikátor aplikace `cz.medialupa.test`, a proto se instaluje vedle starší MediaLupy. Stávající index staré aplikace se nepřenáší.

Zdrojový archiv neobsahuje binární model obličeje; ten je během sestavení vložen sestavovacím postupem. Pro veřejnou distribuci je třeba ověřit práva k použitým vahám modelu a doladit prahové hodnoty na reálných datech.
