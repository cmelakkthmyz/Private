// MediaLupa – Android Gradle Plugin 9.x (Kotlin je integrován do AGP)
plugins {
    id("com.android.application") version "9.3.1" apply false
}
