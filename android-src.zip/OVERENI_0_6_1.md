# Ověření MediaLupa Android 0.6.1 (7. 11. 2026)

- Přijat archiv `mdlp.zip`, obsahuje původní Android 0.6, Android 0.5 a Windows 0.6.
- TFLite model zkontrolován proti očekávanému SHA-256 – **shodný**.
- Úspěšně parsováno všech 42 souborů XML Android resourců a manifestu.
- Samostatně zkompilován a spuštěn Kotlin smoke test `CzechSearch.kt` – **úspěšný**.
- Přidán Robolectric regresní test `limitedPhotoSelectionCannotDeletePreviouslyIndexedFaceAlbums`.
- **Android Robolectric testy a APK zde nebylo možné sestavit**:
  chybí Android SDK a Gradle distribuce, síťové stahování není dostupné.
- Původní výsledky `OVERENI_06.md` jsou z předchozí verze, neplatí automaticky pro 0.6.1.
- Workflow na GitHub Actions `medialupa-apk.yml` je připravené pro nezávislé sestavení.
