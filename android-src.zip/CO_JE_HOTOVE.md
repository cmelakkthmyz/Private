# MediaLupa 0.3 — rozsah a stav

## Implementováno ve zdrojových kódech
- Indexování obrázků a videí pomocí MediaStore; další složky systémovým výběrem (SAF).
- Lokální SQLite index a prohledávání v češtině podle názvu, štítků ML Kit a OCR.
- Rozpoznávání fotografií pomocí baleného modelu Google ML Kit Image Labeling.
- Rozpoznávání latinského textu pomocí baleného modelu ML Kit Text Recognition.
- Volba řazení, filtrů, náhledy, kontrola přesných duplicit SHA-256.
- Uživatelské rozhraní v češtině. Internet není požadované oprávnění.

## Omezení
- Není implementovaný konverzační jazykový model Gemma ani volitelné modelové balíčky.
- Velké galerie se zpracovávají po dávkách podle schopností zařízení.
- Vyhledávání přirozenou češtinou je slovníkové, nikoliv generativní.
- Dokončení kompilace a testů na skutečném Android telefonu jsou oddělené kroky.
- OCR podporuje podle použitého modelu latinku, nemusí rozpoznat každý text.
- Cloudové dokumenty připojené přes systémový výběr nejsou automaticky stahovány ani analyzovány.
- Aplikace bez potvrzení uživatele soubory nepřesouvá ani nemaže.

## Reprodukovatelné sestavení
Viz `.github/workflows/medialupa-apk.yml`. Android SDK 36, JDK 17, Gradle 9.6.1 a `gradle :app:assembleDebug`.
Debug APK slouží pro testování. Pro Google Play je potřeba podepsaný release a další kontroly.
