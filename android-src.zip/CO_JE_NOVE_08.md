# MediaLupa 0.8 – chytrá alba osob a srozumitelné popisy

- Offline MobileFaceNet dále ukládá normalizované obličejové otisky, nikoli fotografie obličejů.
- Po hledání osob se nyní automaticky shlukují skupiny s podobnými otisky. V Nástrojích je také volba **Automaticky seskupit stejné osoby** pro starý katalog; nevyžaduje znovu zpracovat fotografie.
- Pojmenované skupiny s různými jmény se nikdy automaticky neslučují. Tváře detekované ve stejném snímku zůstávají oddělené. Nejednoznačné shody zůstávají zvlášť a lze je sloučit ručně.
- U fotografií a videí se v náhledu, přehrávači a přímo na kartách nahoře zobrazuje jeden krátký český popis místo seznamu AI štítků.
- Popis kombinuje už potvrzená jména, počet rozpoznaných osob a spolehlivější klíčová slova z existující ML Kit analýzy. Rodinné vztahy neodhaduje.
- Je to pravidlové shrnutí, nikoli generativní popis libovolné scény. Pro opravdu detailní věty by bylo nutné zapojit a kalibrovat plnohodnotný vision-language model; samotný ML Kit obrazový klasifikátor má omezenou slovní zásobu.
- Verze 0.8 používá samostatné ID aplikace (`cz.medialupa.explorer.v08`), aby nenahrazovala instalovanou 0.7 a nezničila její osobní data. Má vlastní databázi.
- Shlukovací prahy nejsou ověřené na uživatelových fotografiích; mohou vyžadovat doladění. Žádné biometrické vzory se neposílají na server.
