# Stav MediaLupy 0.6 a další vývoj

„Funguje“ níže znamená ověřeno automatickými testy nebo kontrolou výsledného APK,
nikoli potvrzení všech vlastností na fyzickém zařízení.

| Část | Stav | Doložení / omezení |
|---|---|---|
| Průzkumník, cesty, oddělení zdrojů, hledání ve složkách | funguje | Robolectric: úzká i široká obrazovka a hranice sourozeneckých cest |
| Prohlížeč fotografií a přechod na video | funguje | Automatický UI test; skutečné kodeky ověřit na telefonu |
| Přerušení načítání a opětovné spuštění | funguje | Test přerušeného průchodu přes 200 položek, zachování starého katalogu a následné dokončení |
| Oprávnění fotek/videí odděleně | funguje | Test odmítnutých fotek při povoleném videu; skutečný systémový dialog ověřit na telefonu |
| Zachování štítků, OCR, SHA-256 a jmen při nezměněných médiích | funguje | Regresní testy databáze |
| Oprava osiřelých vzorů a aktualizace databáze z 0.5 | funguje | Migrační test a testy změny/odebrání souboru |
| Smazání jedné osoby, odmítnutí chybného sloučení | funguje | Databázové testy zachování souborů a ostatních profilů |
| Neúplný/nepřístupný SAF průchod | funguje | Test nedostupných potomků; katalog se neprořezává |
| Přesné duplicity | funguje | Test skutečného čtení testovacích souborů, SHA-256, přerušení uvnitř souboru a opětovného použití hashe |
| Překlad štítků | funguje | Test českého dotazu a chybných částečných shod slov |
| Offline ML Kit štítky a OCR, MobileFaceNet inference | ověřit na telefonu | Modely jsou přiložené; testy negarantují jejich přesnost ani skutečnou inferenci na telefonu |
| Kvalita alb osob a citlivost prahu | ověřit na telefonu | Experimentální návrhy, ruční opravy zůstávají nutné; žádný nový benchmark přesnosti |
| Cloud přes SAF | ověřit na telefonu | Závisí na konkrétním poskytovateli; AI a hashování připojených médií se automaticky nespouští |
| Výkon na velké knihovně a slabším telefonu | ověřit na telefonu | Metadata se zapisují po 200, zobrazení po 250; skutečný výkon na 100 000 médiích nebyl měřen |
| Univerzální multimodální vyhledávání větou | chybí | Zůstávají štítky a slovník; další krok vybrat licencovaný offline model a změřit rychlost/velikost |
| Přibližné duplicity a vizuální hledání podle fotografie | chybí | Nutné vektory a kalibrace prahů; bez mazání originálů |
| Trvalé úlohy na pozadí a automatické sledování změn | chybí | Aktuálně běží dávky v otevřené aplikaci; další krok WorkManager se stavem úloh |
| Obnovení SAF přesně od poslední pozice a více než 10 000 souborů na strom | chybí | Po zastavení se průchod spouští od začátku; limitem se neprořezává katalog |
| Samostatné označení nejistých shod skórem | chybí | UI označuje alba jako návrhy, skóre jednotlivých přiřazení zatím neukládá |
| OCR celých PDF, mapa, časová osa a pravidla třídění | chybí | Tato verze je neimplementuje |

## Doporučený test na telefonu

1. Aktualizuj 0.5 bez odinstalace. Ověř zachování jmen osob a přístupů ke složkám.
2. Načti knihovnu, zastav ji a spusť znovu. Do dokončení nesmí zmizet staré položky.
3. Vyzkoušej oprávnění jen k fotografiím, jen k videím a pouze k vybraným médiím.
4. Spusť rozpoznávání/OCR a osoby na malé testovací knihovně. Ověř stav po zastavení videa.
5. Podrž album, změň jméno, sluč dvě testovací skupiny, odděl chybně přiřazený soubor
   a smaž jeden testovací profil. Ostatní alba a originály musí zůstat.
6. Vyhledej přesné kopie dvou testovacích souborů, zastav a obnov kontrolu.
7. Připoj testovací složku přes SAF a vyzkoušej i ztrátu připojení poskytovatele.

Nepřidávat automatické zápisy do uživatelských souborů. Pro další vývoj postupovat
podle AGENTS.md a aktuálního README. Původní 0.5 ověření je historický záznam.
